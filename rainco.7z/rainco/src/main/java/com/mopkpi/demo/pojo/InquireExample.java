package com.mopkpi.demo.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InquireExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public InquireExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAemIdIsNull() {
            addCriterion("aem_id is null");
            return (Criteria) this;
        }

        public Criteria andAemIdIsNotNull() {
            addCriterion("aem_id is not null");
            return (Criteria) this;
        }

        public Criteria andAemIdEqualTo(Integer value) {
            addCriterion("aem_id =", value, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdNotEqualTo(Integer value) {
            addCriterion("aem_id <>", value, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdGreaterThan(Integer value) {
            addCriterion("aem_id >", value, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("aem_id >=", value, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdLessThan(Integer value) {
            addCriterion("aem_id <", value, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdLessThanOrEqualTo(Integer value) {
            addCriterion("aem_id <=", value, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdIn(List<Integer> values) {
            addCriterion("aem_id in", values, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdNotIn(List<Integer> values) {
            addCriterion("aem_id not in", values, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdBetween(Integer value1, Integer value2) {
            addCriterion("aem_id between", value1, value2, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemIdNotBetween(Integer value1, Integer value2) {
            addCriterion("aem_id not between", value1, value2, "aemId");
            return (Criteria) this;
        }

        public Criteria andAemProjectIsNull() {
            addCriterion("aem_project is null");
            return (Criteria) this;
        }

        public Criteria andAemProjectIsNotNull() {
            addCriterion("aem_project is not null");
            return (Criteria) this;
        }

        public Criteria andAemProjectEqualTo(String value) {
            addCriterion("aem_project =", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectNotEqualTo(String value) {
            addCriterion("aem_project <>", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectGreaterThan(String value) {
            addCriterion("aem_project >", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectGreaterThanOrEqualTo(String value) {
            addCriterion("aem_project >=", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectLessThan(String value) {
            addCriterion("aem_project <", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectLessThanOrEqualTo(String value) {
            addCriterion("aem_project <=", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectLike(String value) {
            addCriterion("aem_project like", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectNotLike(String value) {
            addCriterion("aem_project not like", value, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectIn(List<String> values) {
            addCriterion("aem_project in", values, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectNotIn(List<String> values) {
            addCriterion("aem_project not in", values, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectBetween(String value1, String value2) {
            addCriterion("aem_project between", value1, value2, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemProjectNotBetween(String value1, String value2) {
            addCriterion("aem_project not between", value1, value2, "aemProject");
            return (Criteria) this;
        }

        public Criteria andAemOneIsNull() {
            addCriterion("aem_one is null");
            return (Criteria) this;
        }

        public Criteria andAemOneIsNotNull() {
            addCriterion("aem_one is not null");
            return (Criteria) this;
        }

        public Criteria andAemOneEqualTo(String value) {
            addCriterion("aem_one =", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneNotEqualTo(String value) {
            addCriterion("aem_one <>", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneGreaterThan(String value) {
            addCriterion("aem_one >", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneGreaterThanOrEqualTo(String value) {
            addCriterion("aem_one >=", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneLessThan(String value) {
            addCriterion("aem_one <", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneLessThanOrEqualTo(String value) {
            addCriterion("aem_one <=", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneLike(String value) {
            addCriterion("aem_one like", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneNotLike(String value) {
            addCriterion("aem_one not like", value, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneIn(List<String> values) {
            addCriterion("aem_one in", values, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneNotIn(List<String> values) {
            addCriterion("aem_one not in", values, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneBetween(String value1, String value2) {
            addCriterion("aem_one between", value1, value2, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemOneNotBetween(String value1, String value2) {
            addCriterion("aem_one not between", value1, value2, "aemOne");
            return (Criteria) this;
        }

        public Criteria andAemTwoIsNull() {
            addCriterion("aem_two is null");
            return (Criteria) this;
        }

        public Criteria andAemTwoIsNotNull() {
            addCriterion("aem_two is not null");
            return (Criteria) this;
        }

        public Criteria andAemTwoEqualTo(String value) {
            addCriterion("aem_two =", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoNotEqualTo(String value) {
            addCriterion("aem_two <>", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoGreaterThan(String value) {
            addCriterion("aem_two >", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoGreaterThanOrEqualTo(String value) {
            addCriterion("aem_two >=", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoLessThan(String value) {
            addCriterion("aem_two <", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoLessThanOrEqualTo(String value) {
            addCriterion("aem_two <=", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoLike(String value) {
            addCriterion("aem_two like", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoNotLike(String value) {
            addCriterion("aem_two not like", value, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoIn(List<String> values) {
            addCriterion("aem_two in", values, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoNotIn(List<String> values) {
            addCriterion("aem_two not in", values, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoBetween(String value1, String value2) {
            addCriterion("aem_two between", value1, value2, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemTwoNotBetween(String value1, String value2) {
            addCriterion("aem_two not between", value1, value2, "aemTwo");
            return (Criteria) this;
        }

        public Criteria andAemStandardIsNull() {
            addCriterion("aem_standard is null");
            return (Criteria) this;
        }

        public Criteria andAemStandardIsNotNull() {
            addCriterion("aem_standard is not null");
            return (Criteria) this;
        }

        public Criteria andAemStandardEqualTo(String value) {
            addCriterion("aem_standard =", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardNotEqualTo(String value) {
            addCriterion("aem_standard <>", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardGreaterThan(String value) {
            addCriterion("aem_standard >", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardGreaterThanOrEqualTo(String value) {
            addCriterion("aem_standard >=", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardLessThan(String value) {
            addCriterion("aem_standard <", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardLessThanOrEqualTo(String value) {
            addCriterion("aem_standard <=", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardLike(String value) {
            addCriterion("aem_standard like", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardNotLike(String value) {
            addCriterion("aem_standard not like", value, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardIn(List<String> values) {
            addCriterion("aem_standard in", values, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardNotIn(List<String> values) {
            addCriterion("aem_standard not in", values, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardBetween(String value1, String value2) {
            addCriterion("aem_standard between", value1, value2, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemStandardNotBetween(String value1, String value2) {
            addCriterion("aem_standard not between", value1, value2, "aemStandard");
            return (Criteria) this;
        }

        public Criteria andAemDeptIsNull() {
            addCriterion("aem_dept is null");
            return (Criteria) this;
        }

        public Criteria andAemDeptIsNotNull() {
            addCriterion("aem_dept is not null");
            return (Criteria) this;
        }

        public Criteria andAemDeptEqualTo(String value) {
            addCriterion("aem_dept =", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptNotEqualTo(String value) {
            addCriterion("aem_dept <>", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptGreaterThan(String value) {
            addCriterion("aem_dept >", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptGreaterThanOrEqualTo(String value) {
            addCriterion("aem_dept >=", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptLessThan(String value) {
            addCriterion("aem_dept <", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptLessThanOrEqualTo(String value) {
            addCriterion("aem_dept <=", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptLike(String value) {
            addCriterion("aem_dept like", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptNotLike(String value) {
            addCriterion("aem_dept not like", value, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptIn(List<String> values) {
            addCriterion("aem_dept in", values, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptNotIn(List<String> values) {
            addCriterion("aem_dept not in", values, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptBetween(String value1, String value2) {
            addCriterion("aem_dept between", value1, value2, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemDeptNotBetween(String value1, String value2) {
            addCriterion("aem_dept not between", value1, value2, "aemDept");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainIsNull() {
            addCriterion("aem_standard_explain is null");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainIsNotNull() {
            addCriterion("aem_standard_explain is not null");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainEqualTo(String value) {
            addCriterion("aem_standard_explain =", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainNotEqualTo(String value) {
            addCriterion("aem_standard_explain <>", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainGreaterThan(String value) {
            addCriterion("aem_standard_explain >", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainGreaterThanOrEqualTo(String value) {
            addCriterion("aem_standard_explain >=", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainLessThan(String value) {
            addCriterion("aem_standard_explain <", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainLessThanOrEqualTo(String value) {
            addCriterion("aem_standard_explain <=", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainLike(String value) {
            addCriterion("aem_standard_explain like", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainNotLike(String value) {
            addCriterion("aem_standard_explain not like", value, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainIn(List<String> values) {
            addCriterion("aem_standard_explain in", values, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainNotIn(List<String> values) {
            addCriterion("aem_standard_explain not in", values, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainBetween(String value1, String value2) {
            addCriterion("aem_standard_explain between", value1, value2, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemStandardExplainNotBetween(String value1, String value2) {
            addCriterion("aem_standard_explain not between", value1, value2, "aemStandardExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainIsNull() {
            addCriterion("aem_explain is null");
            return (Criteria) this;
        }

        public Criteria andAemExplainIsNotNull() {
            addCriterion("aem_explain is not null");
            return (Criteria) this;
        }

        public Criteria andAemExplainEqualTo(String value) {
            addCriterion("aem_explain =", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainNotEqualTo(String value) {
            addCriterion("aem_explain <>", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainGreaterThan(String value) {
            addCriterion("aem_explain >", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainGreaterThanOrEqualTo(String value) {
            addCriterion("aem_explain >=", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainLessThan(String value) {
            addCriterion("aem_explain <", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainLessThanOrEqualTo(String value) {
            addCriterion("aem_explain <=", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainLike(String value) {
            addCriterion("aem_explain like", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainNotLike(String value) {
            addCriterion("aem_explain not like", value, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainIn(List<String> values) {
            addCriterion("aem_explain in", values, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainNotIn(List<String> values) {
            addCriterion("aem_explain not in", values, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainBetween(String value1, String value2) {
            addCriterion("aem_explain between", value1, value2, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemExplainNotBetween(String value1, String value2) {
            addCriterion("aem_explain not between", value1, value2, "aemExplain");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkIsNull() {
            addCriterion("aem_full_mark is null");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkIsNotNull() {
            addCriterion("aem_full_mark is not null");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkEqualTo(Double value) {
            addCriterion("aem_full_mark =", value, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkNotEqualTo(Double value) {
            addCriterion("aem_full_mark <>", value, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkGreaterThan(Double value) {
            addCriterion("aem_full_mark >", value, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkGreaterThanOrEqualTo(Double value) {
            addCriterion("aem_full_mark >=", value, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkLessThan(Double value) {
            addCriterion("aem_full_mark <", value, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkLessThanOrEqualTo(Double value) {
            addCriterion("aem_full_mark <=", value, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkIn(List<Double> values) {
            addCriterion("aem_full_mark in", values, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkNotIn(List<Double> values) {
            addCriterion("aem_full_mark not in", values, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkBetween(Double value1, Double value2) {
            addCriterion("aem_full_mark between", value1, value2, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemFullMarkNotBetween(Double value1, Double value2) {
            addCriterion("aem_full_mark not between", value1, value2, "aemFullMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkIsNull() {
            addCriterion("aem_mark is null");
            return (Criteria) this;
        }

        public Criteria andAemMarkIsNotNull() {
            addCriterion("aem_mark is not null");
            return (Criteria) this;
        }

        public Criteria andAemMarkEqualTo(String value) {
            addCriterion("aem_mark =", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkNotEqualTo(String value) {
            addCriterion("aem_mark <>", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkGreaterThan(String value) {
            addCriterion("aem_mark >", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkGreaterThanOrEqualTo(String value) {
            addCriterion("aem_mark >=", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkLessThan(String value) {
            addCriterion("aem_mark <", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkLessThanOrEqualTo(String value) {
            addCriterion("aem_mark <=", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkLike(String value) {
            addCriterion("aem_mark like", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkNotLike(String value) {
            addCriterion("aem_mark not like", value, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkIn(List<String> values) {
            addCriterion("aem_mark in", values, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkNotIn(List<String> values) {
            addCriterion("aem_mark not in", values, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkBetween(String value1, String value2) {
            addCriterion("aem_mark between", value1, value2, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemMarkNotBetween(String value1, String value2) {
            addCriterion("aem_mark not between", value1, value2, "aemMark");
            return (Criteria) this;
        }

        public Criteria andAemCreateByIsNull() {
            addCriterion("aem_create_by is null");
            return (Criteria) this;
        }

        public Criteria andAemCreateByIsNotNull() {
            addCriterion("aem_create_by is not null");
            return (Criteria) this;
        }

        public Criteria andAemCreateByEqualTo(String value) {
            addCriterion("aem_create_by =", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByNotEqualTo(String value) {
            addCriterion("aem_create_by <>", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByGreaterThan(String value) {
            addCriterion("aem_create_by >", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByGreaterThanOrEqualTo(String value) {
            addCriterion("aem_create_by >=", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByLessThan(String value) {
            addCriterion("aem_create_by <", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByLessThanOrEqualTo(String value) {
            addCriterion("aem_create_by <=", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByLike(String value) {
            addCriterion("aem_create_by like", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByNotLike(String value) {
            addCriterion("aem_create_by not like", value, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByIn(List<String> values) {
            addCriterion("aem_create_by in", values, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByNotIn(List<String> values) {
            addCriterion("aem_create_by not in", values, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByBetween(String value1, String value2) {
            addCriterion("aem_create_by between", value1, value2, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateByNotBetween(String value1, String value2) {
            addCriterion("aem_create_by not between", value1, value2, "aemCreateBy");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeIsNull() {
            addCriterion("aem_create_time is null");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeIsNotNull() {
            addCriterion("aem_create_time is not null");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeEqualTo(Date value) {
            addCriterion("aem_create_time =", value, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeNotEqualTo(Date value) {
            addCriterion("aem_create_time <>", value, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeGreaterThan(Date value) {
            addCriterion("aem_create_time >", value, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("aem_create_time >=", value, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeLessThan(Date value) {
            addCriterion("aem_create_time <", value, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("aem_create_time <=", value, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeIn(List<Date> values) {
            addCriterion("aem_create_time in", values, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeNotIn(List<Date> values) {
            addCriterion("aem_create_time not in", values, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeBetween(Date value1, Date value2) {
            addCriterion("aem_create_time between", value1, value2, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("aem_create_time not between", value1, value2, "aemCreateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByIsNull() {
            addCriterion("aem_update_by is null");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByIsNotNull() {
            addCriterion("aem_update_by is not null");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByEqualTo(String value) {
            addCriterion("aem_update_by =", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByNotEqualTo(String value) {
            addCriterion("aem_update_by <>", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByGreaterThan(String value) {
            addCriterion("aem_update_by >", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByGreaterThanOrEqualTo(String value) {
            addCriterion("aem_update_by >=", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByLessThan(String value) {
            addCriterion("aem_update_by <", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByLessThanOrEqualTo(String value) {
            addCriterion("aem_update_by <=", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByLike(String value) {
            addCriterion("aem_update_by like", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByNotLike(String value) {
            addCriterion("aem_update_by not like", value, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByIn(List<String> values) {
            addCriterion("aem_update_by in", values, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByNotIn(List<String> values) {
            addCriterion("aem_update_by not in", values, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByBetween(String value1, String value2) {
            addCriterion("aem_update_by between", value1, value2, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateByNotBetween(String value1, String value2) {
            addCriterion("aem_update_by not between", value1, value2, "aemUpdateBy");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeIsNull() {
            addCriterion("aem_update_time is null");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeIsNotNull() {
            addCriterion("aem_update_time is not null");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeEqualTo(Date value) {
            addCriterion("aem_update_time =", value, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeNotEqualTo(Date value) {
            addCriterion("aem_update_time <>", value, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeGreaterThan(Date value) {
            addCriterion("aem_update_time >", value, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("aem_update_time >=", value, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeLessThan(Date value) {
            addCriterion("aem_update_time <", value, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("aem_update_time <=", value, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeIn(List<Date> values) {
            addCriterion("aem_update_time in", values, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeNotIn(List<Date> values) {
            addCriterion("aem_update_time not in", values, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("aem_update_time between", value1, value2, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("aem_update_time not between", value1, value2, "aemUpdateTime");
            return (Criteria) this;
        }

        public Criteria andAemRemarkIsNull() {
            addCriterion("aem_remark is null");
            return (Criteria) this;
        }

        public Criteria andAemRemarkIsNotNull() {
            addCriterion("aem_remark is not null");
            return (Criteria) this;
        }

        public Criteria andAemRemarkEqualTo(String value) {
            addCriterion("aem_remark =", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkNotEqualTo(String value) {
            addCriterion("aem_remark <>", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkGreaterThan(String value) {
            addCriterion("aem_remark >", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("aem_remark >=", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkLessThan(String value) {
            addCriterion("aem_remark <", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkLessThanOrEqualTo(String value) {
            addCriterion("aem_remark <=", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkLike(String value) {
            addCriterion("aem_remark like", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkNotLike(String value) {
            addCriterion("aem_remark not like", value, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkIn(List<String> values) {
            addCriterion("aem_remark in", values, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkNotIn(List<String> values) {
            addCriterion("aem_remark not in", values, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkBetween(String value1, String value2) {
            addCriterion("aem_remark between", value1, value2, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemRemarkNotBetween(String value1, String value2) {
            addCriterion("aem_remark not between", value1, value2, "aemRemark");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeIsNull() {
            addCriterion("aem_start_time is null");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeIsNotNull() {
            addCriterion("aem_start_time is not null");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeEqualTo(String value) {
            addCriterion("aem_start_time =", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeNotEqualTo(String value) {
            addCriterion("aem_start_time <>", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeGreaterThan(String value) {
            addCriterion("aem_start_time >", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeGreaterThanOrEqualTo(String value) {
            addCriterion("aem_start_time >=", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeLessThan(String value) {
            addCriterion("aem_start_time <", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeLessThanOrEqualTo(String value) {
            addCriterion("aem_start_time <=", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeLike(String value) {
            addCriterion("aem_start_time like", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeNotLike(String value) {
            addCriterion("aem_start_time not like", value, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeIn(List<String> values) {
            addCriterion("aem_start_time in", values, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeNotIn(List<String> values) {
            addCriterion("aem_start_time not in", values, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeBetween(String value1, String value2) {
            addCriterion("aem_start_time between", value1, value2, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemStartTimeNotBetween(String value1, String value2) {
            addCriterion("aem_start_time not between", value1, value2, "aemStartTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeIsNull() {
            addCriterion("aem_end_time is null");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeIsNotNull() {
            addCriterion("aem_end_time is not null");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeEqualTo(String value) {
            addCriterion("aem_end_time =", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeNotEqualTo(String value) {
            addCriterion("aem_end_time <>", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeGreaterThan(String value) {
            addCriterion("aem_end_time >", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeGreaterThanOrEqualTo(String value) {
            addCriterion("aem_end_time >=", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeLessThan(String value) {
            addCriterion("aem_end_time <", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeLessThanOrEqualTo(String value) {
            addCriterion("aem_end_time <=", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeLike(String value) {
            addCriterion("aem_end_time like", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeNotLike(String value) {
            addCriterion("aem_end_time not like", value, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeIn(List<String> values) {
            addCriterion("aem_end_time in", values, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeNotIn(List<String> values) {
            addCriterion("aem_end_time not in", values, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeBetween(String value1, String value2) {
            addCriterion("aem_end_time between", value1, value2, "aemEndTime");
            return (Criteria) this;
        }

        public Criteria andAemEndTimeNotBetween(String value1, String value2) {
            addCriterion("aem_end_time not between", value1, value2, "aemEndTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}