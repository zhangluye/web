package com.mopkpi.demo.service;

import com.mopkpi.demo.pojo.Inquire;
import com.mopkpi.demo.pojo.Teacher;


import java.util.List;
import java.util.Map;

public interface UserService {
     List<Teacher> getAll(Map<String, Object> map);
//    List<Inquire> selectAll(Map <String,Object> maps);
    }



