package com.mopkpi.demo.mapper;

import com.mopkpi.demo.pojo.Inquire;
import com.mopkpi.demo.pojo.InquireExample;
import java.util.List;
import java.util.Map;

import com.mopkpi.demo.pojo.Teacher;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface InquireMapper {
    long countByExample(InquireExample example);

    int deleteByExample(InquireExample example);

    int deleteByPrimaryKey(Integer aemId);

    int insert(Inquire record);

    int insertSelective(Inquire record);

    List<Inquire> selectByExample(InquireExample example);

    Inquire selectByPrimaryKey(Integer aemId);

    int updateByExampleSelective(@Param("record") Inquire record, @Param("example") InquireExample example);

    int updateByExample(@Param("record") Inquire record, @Param("example") InquireExample example);

    int updateByPrimaryKeySelective(Inquire record);

    int updateByPrimaryKey(Inquire record);

    List<Inquire> selectAll (Map<String ,Object > map) ;

}