package com.mopkpi.demo.service;

import com.mopkpi.demo.mapper.InquireMapper;
import com.mopkpi.demo.mapper.TeacherMapper;
import com.mopkpi.demo.pojo.Inquire;
import com.mopkpi.demo.pojo.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public class UserServiceImpl implements UserService {
    //查询教师信息
    @Autowired
    private TeacherMapper teacherMapper;

    public List<Teacher> getAll(Map<String,Object>map){
        return teacherMapper.getAll(map);
    }

    //查询历史考核
    @Autowired
    private InquireMapper inquireMapper;
    public List<Inquire> selectAll(Map<String,Object>map){
        return inquireMapper.selectAll(map);
    }



}
