package com.mopkpi.demo.controller;

import com.mopkpi.demo.dto.ResultDTO;
import com.mopkpi.demo.enums.ResultCodeEnum;
import com.mopkpi.demo.mapper.InquireMapper;
import com.mopkpi.demo.pojo.Inquire;
import com.mopkpi.demo.pojo.Teacher;
import com.mopkpi.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RequestMapping("teacher")
@RestController
public class InquireController {


    /*
    查询历史考核
    * */
    @Autowired
    public InquireMapper inquireMapper;
    @Autowired
    private UserService userService;

    @PostMapping("inquire")
    public String  Inquire(@RequestBody Inquire inquire){
        Inquire select = new Inquire();

        //先查出全部的考核项目



    }
}
