package com.mopkpi.demo.enums;
//枚举类
public enum ResultCodeEnum {

    REGISTER_SUCCESS(100,"填写成功"),
    REGISTER_ERROR(101,"填写失败"),
    REGISTER_NULL(102,"填写未完整"),
    SELECT_SUCCESS(103,"查询成功")

    ;
    ResultCodeEnum(int code,String msg){

        this.code=code;
        this.msg= msg;
    }
    private int code;//code编码 404 500
    private String msg;//内容信息提示





    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
