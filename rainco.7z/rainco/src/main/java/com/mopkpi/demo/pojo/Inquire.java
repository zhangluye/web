package com.mopkpi.demo.pojo;

import java.util.Date;

public class Inquire {
    private Integer aemId;

    private String aemProject;

    private String aemOne;

    private String aemTwo;

    private String aemStandard;

    private String aemDept;

    private String aemStandardExplain;

    private String aemExplain;

    private Double aemFullMark;

    private String aemMark;

    private String aemCreateBy;

    private Date aemCreateTime;

    private String aemUpdateBy;

    private Date aemUpdateTime;

    private String aemRemark;

    private String aemStartTime;

    private String aemEndTime;

    public Integer getAemId() {
        return aemId;
    }

    public void setAemId(Integer aemId) {
        this.aemId = aemId;
    }

    public String getAemProject() {
        return aemProject;
    }

    public void setAemProject(String aemProject) {
        this.aemProject = aemProject == null ? null : aemProject.trim();
    }

    public String getAemOne() {
        return aemOne;
    }

    public void setAemOne(String aemOne) {
        this.aemOne = aemOne == null ? null : aemOne.trim();
    }

    public String getAemTwo() {
        return aemTwo;
    }

    public void setAemTwo(String aemTwo) {
        this.aemTwo = aemTwo == null ? null : aemTwo.trim();
    }

    public String getAemStandard() {
        return aemStandard;
    }

    public void setAemStandard(String aemStandard) {
        this.aemStandard = aemStandard == null ? null : aemStandard.trim();
    }

    public String getAemDept() {
        return aemDept;
    }

    public void setAemDept(String aemDept) {
        this.aemDept = aemDept == null ? null : aemDept.trim();
    }

    public String getAemStandardExplain() {
        return aemStandardExplain;
    }

    public void setAemStandardExplain(String aemStandardExplain) {
        this.aemStandardExplain = aemStandardExplain == null ? null : aemStandardExplain.trim();
    }

    public String getAemExplain() {
        return aemExplain;
    }

    public void setAemExplain(String aemExplain) {
        this.aemExplain = aemExplain == null ? null : aemExplain.trim();
    }

    public Double getAemFullMark() {
        return aemFullMark;
    }

    public void setAemFullMark(Double aemFullMark) {
        this.aemFullMark = aemFullMark;
    }

    public String getAemMark() {
        return aemMark;
    }

    public void setAemMark(String aemMark) {
        this.aemMark = aemMark == null ? null : aemMark.trim();
    }

    public String getAemCreateBy() {
        return aemCreateBy;
    }

    public void setAemCreateBy(String aemCreateBy) {
        this.aemCreateBy = aemCreateBy == null ? null : aemCreateBy.trim();
    }

    public Date getAemCreateTime() {
        return aemCreateTime;
    }

    public void setAemCreateTime(Date aemCreateTime) {
        this.aemCreateTime = aemCreateTime;
    }

    public String getAemUpdateBy() {
        return aemUpdateBy;
    }

    public void setAemUpdateBy(String aemUpdateBy) {
        this.aemUpdateBy = aemUpdateBy == null ? null : aemUpdateBy.trim();
    }

    public Date getAemUpdateTime() {
        return aemUpdateTime;
    }

    public void setAemUpdateTime(Date aemUpdateTime) {
        this.aemUpdateTime = aemUpdateTime;
    }

    public String getAemRemark() {
        return aemRemark;
    }

    public void setAemRemark(String aemRemark) {
        this.aemRemark = aemRemark == null ? null : aemRemark.trim();
    }

    public String getAemStartTime() {
        return aemStartTime;
    }

    public void setAemStartTime(String aemStartTime) {
        this.aemStartTime = aemStartTime == null ? null : aemStartTime.trim();
    }

    public String getAemEndTime() {
        return aemEndTime;
    }

    public void setAemEndTime(String aemEndTime) {
        this.aemEndTime = aemEndTime == null ? null : aemEndTime.trim();
    }
}