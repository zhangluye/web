package com.mopkpi.demo.controller;

import com.mopkpi.demo.dto.ResultDTO;
import com.mopkpi.demo.enums.ResultCodeEnum;
import com.mopkpi.demo.mapper.TeacherMapper;
import com.mopkpi.demo.pojo.Teacher;
import com.mopkpi.demo.pojo.TeacherExample;
import com.mopkpi.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;



import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RequestMapping("teacher")
@RestController
public class TeacherController {
/*
用户注册信息:
姓名  密码 两者之一为非空
电话  工号 不作处理
* */
   @Autowired
   private TeacherMapper teacherMapper;//解决爆红原因 ：在teacherMapper里面添加@mapper或@Repository注解
   @Autowired
    private UserService userService;

    @PostMapping("register")
    public ResultDTO Register(@RequestBody Teacher teacher) {

        Teacher info = new Teacher();
        //判断信息是否填写完整
        if (teacher.getPassword() == null || teacher.getUserName().isEmpty()) {
            return new ResultDTO(ResultCodeEnum.REGISTER_NULL);//102 填写未完整
        }

        info.setUserName(teacher.getUserName());
        info.setPassword(teacher.getPassword());
        info.setPhonenumber(teacher.getPhonenumber());
        info.setUserId(teacher.getUserId());

        teacherMapper.insert(info);//信息保存到数据库中

        //判断数据是否成功保存到数据库中
        TeacherExample teacherExample = new TeacherExample();
        teacherExample.createCriteria().andUserIdEqualTo(teacher.getUserId());
        List<Teacher> teachers = teacherMapper.selectByExample(teacherExample);
        if (teachers.isEmpty()) {
            return new ResultDTO(ResultCodeEnum.REGISTER_ERROR);
        }
        return new ResultDTO(ResultCodeEnum.REGISTER_SUCCESS);
    }

    /*
     查询并展示
    用户注册信息
    * */
    @GetMapping("message")
    public List<Teacher> get(HttpServletRequest request){
        Map<String, Object> result = new HashMap<>();

        List<Teacher> list = userService.getAll(result);
        request.getSession().setAttribute("LIST",list);
        return list;

    }



}
