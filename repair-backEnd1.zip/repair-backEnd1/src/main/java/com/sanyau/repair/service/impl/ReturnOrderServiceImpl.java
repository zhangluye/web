package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.*;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.ReturnOrderMapper;
import com.sanyau.repair.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.utils.IDUtils;
import com.sanyau.repair.utils.StaticCode;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class ReturnOrderServiceImpl extends ServiceImpl<ReturnOrderMapper, ReturnOrder> implements IReturnOrderService {

    @Autowired
    private IReturnOrderService returnOrderService;

    @Autowired
    private IReturnMaterialInfoService returnMaterialInfoService;

    @Autowired
    private IMasterInfoService masterInfoService;

    @Autowired
    private IMaterialInfoService materialInfoService;

    @Autowired
    private IRepositoryService repositoryService;

    @Autowired
    private IMaterialGroupService materialGroupService;

    @Autowired
    private IRepositoryMaterialService repositoryMaterialService;
    @Override
    public Map<String, Object> selectAllReturnOrder(Long current, Long limit, SelectDeliveryOrderAccept selectDeliveryOrderAccept) {
        Map<String,Object> map = new HashMap<>();

        QueryWrapper<ReturnOrder> queryWrapper = new QueryWrapper<>();
        if(selectDeliveryOrderAccept==null){
            List<ReturnOrder> deliveryOrders = returnOrderService.list();
            map.put("DeliveryOrders",deliveryOrders);
            return map;
        }
        if(selectDeliveryOrderAccept.getDeliveryOrderId()!=null&&!selectDeliveryOrderAccept.getDeliveryOrderId().equals("")){
            queryWrapper.eq("delivery_order_id",selectDeliveryOrderAccept.getDeliveryOrderId());
        }
        if(selectDeliveryOrderAccept.getDeliveryOrderState()!=null&&!selectDeliveryOrderAccept.getDeliveryOrderState().equals("")){
            queryWrapper.eq("delivery_order_state",selectDeliveryOrderAccept.getDeliveryOrderState());
        }
        if(selectDeliveryOrderAccept.getCreateTime()!=null){
            queryWrapper.between("create_time",new Date(selectDeliveryOrderAccept.getCreateTime()[0]),new Date(selectDeliveryOrderAccept.getCreateTime()[1]));
        }
        if(selectDeliveryOrderAccept.getMasterAccount()!=null&&!selectDeliveryOrderAccept.getMasterAccount().equals("")){
            queryWrapper.eq("master_account",selectDeliveryOrderAccept.getMasterAccount());
        }
        Page<ReturnOrder> returnOrderPage = new Page<ReturnOrder>(current,limit);
        returnOrderService.page(returnOrderPage, queryWrapper.orderByDesc("create_time"));
        List<ReturnOrder> returnOrders = returnOrderPage.getRecords();
        List<ReturnOrder2Accept> returnOrderList = new ArrayList<>();
        for (ReturnOrder returnOrder: returnOrders) {
            ReturnOrder2Accept returnOrder2Accept = new ReturnOrder2Accept();
            BeanUtils.copyProperties(returnOrder,returnOrder2Accept);
            returnOrder2Accept.setReturnOrderState(StaticCode.ToOrderState1(returnOrder.getReturnOrderState()));
            returnOrderList.add(returnOrder2Accept);
        }
        map.put("returnOrders", returnOrderList);
        return map;
    }

    @Override
    public boolean deleteReturnOrder(String orderId) {
        boolean remove = returnOrderService.remove(new QueryWrapper<ReturnOrder>().eq("return_order_id", orderId));
        boolean remove1 = returnMaterialInfoService.remove(new QueryWrapper<ReturnMaterialInfo>().eq("return_order_id", orderId));
        if(remove&&remove1){
            return true;
        }else {
            return false;
        }

    }

    @Override
    public Map<String, Object> selectOneReturnOrder(String orderId) {
        ReturnOrder returnOrder = returnOrderService.getOne(new QueryWrapper<ReturnOrder>().eq("return_order_id", orderId));
        ReturnOrder2Accept returnOrder2Accept = new ReturnOrder2Accept();
        BeanUtils.copyProperties(returnOrder,returnOrder2Accept);
        returnOrder2Accept.setReturnOrderState(StaticCode.ToOrderState1(returnOrder.getReturnOrderState()));
        List<ReturnMaterialInfo> returnMaterialInfos = returnMaterialInfoService.list(new QueryWrapper<ReturnMaterialInfo>().eq("return_order_id", orderId));
        List<ReturnMaterialInfoAccept> returnMaterialInfoAccepts=new ArrayList<>();
        for(ReturnMaterialInfo returnMaterialInfo :returnMaterialInfos){
            ReturnMaterialInfoAccept returnMaterialInfoAccept = new ReturnMaterialInfoAccept();
            BeanUtils.copyProperties(returnMaterialInfo,returnMaterialInfoAccept);
            MaterialGroup id = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("id", returnMaterialInfo.getMaterialType()));
            returnMaterialInfoAccept.setMaterialType(id.getMaterialGroupName());
            returnMaterialInfoAccepts.add(returnMaterialInfoAccept);
        }
        ReturnMasterAccept masterAccept = masterInfoService.selectOneMaster(returnOrder.getMasterAccount());
        Map<String,Object> map = new HashMap<>();
        map.put("returnOrder",returnOrder2Accept);
        map.put("returnMaterialInfos",returnMaterialInfoAccepts);
        map.put("masterAccept",masterAccept);
        return map;
    }

    @Override
    public boolean updateReturnOrder(String orderId, String opinion) {
        ReturnOrder returnOrder = returnOrderService.getOne(new QueryWrapper<ReturnOrder>().eq("return_order_id", orderId));
        List<ReturnMaterialInfo> returnMaterialInfoList = returnMaterialInfoService.list(new QueryWrapper<ReturnMaterialInfo>().eq("return_order_id", orderId));
        ReturnMaterialInfo returnMaterialInfo = new ReturnMaterialInfo();
        MaterialInfo materialInfo = new MaterialInfo();
        if(opinion.equals("true")){
            returnOrder.setReturnOrderState(3);
            for (ReturnMaterialInfo info : returnMaterialInfoList) {
                MaterialInfo materialId = materialInfoService.getOne(new QueryWrapper<MaterialInfo>().eq("material_id", info.getMaterialId()));
                if (materialId != null) {
                    materialInfo.setId(materialId.getId());
                    materialInfo.setMaterialTotal(materialId.getMaterialTotal() + Long.parseLong(info.getReturnAmount()));
                    materialInfo.setMaterialReturnAmount(materialId.getMaterialReturnAmount() + Long.parseLong(info.getReturnAmount()));
                    materialInfoService.updateById(materialInfo);
                }
                returnMaterialInfo.setId(info.getId());
                returnMaterialInfo.setReturnOrderState(3);
                returnMaterialInfoService.updateById(returnMaterialInfo);
            }
            returnOrderService.updateById(returnOrder);
            return true;
        }
        if(opinion.equals("false")){
            for (ReturnMaterialInfo info : returnMaterialInfoList) {
                RepositoryMaterial material_id = repositoryMaterialService.getOne(new QueryWrapper<RepositoryMaterial>().eq("material_id", info.getMaterialId()));
                material_id.setMaterialAmount(material_id.getMaterialAmount()+Long.parseLong(info.getReturnAmount()));
                material_id.setReturnMaterialAmout(material_id.getReturnMaterialAmout()-Long.parseLong(info.getReturnAmount()));
                returnMaterialInfo.setId(info.getId());
                returnMaterialInfo.setReturnOrderState(2);
                repositoryMaterialService.updateById(material_id);
                returnMaterialInfoService.updateById(returnMaterialInfo);
            }
            returnOrder.setReturnOrderState(2);
            return true;
        }
        return false;
    }

    @Override
    public Map<String, Object> deleteReturnOrders(List<String> materialInfos) {
        int success = 0;
        int error = 0;
        if(materialInfos.size()!=0){
            for(String returnOrder:materialInfos){
                boolean b = returnOrderService.deleteReturnOrder(returnOrder);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public boolean insertReturnOrder(InsertReturnOrderAccept insertReturnOrderAccept) {
        ReturnOrder returnOrder = new ReturnOrder();
        returnOrder.setId(null);
        returnOrder.setReturnOrderId(IDUtils.getId());
        returnOrder.setReturnOrderState(1);
        Long total  =0L;
        returnOrder.setCreateTime(new Date());
        returnOrder.setMasterAccount(insertReturnOrderAccept.getAccount());
        if(insertReturnOrderAccept.getMaterialInfos().size()!=0){
            ReturnMaterialInfo returnMaterialInfo = new ReturnMaterialInfo();
            for(RepositoryMaterial repositoryMaterial: insertReturnOrderAccept.getMaterialInfos()){
                returnMaterialInfo.setId(null);
                returnMaterialInfo.setMaterialId(repositoryMaterial.getMaterialId());
                returnMaterialInfo.setMaterialName(repositoryMaterial.getMaterialName());
                returnMaterialInfo.setReturnAmount(String.valueOf(repositoryMaterial.getReturnMaterialAmout()));
                returnMaterialInfo.setReturnOrderId(returnOrder.getReturnOrderId());
                returnMaterialInfo.setMaterialMetric(repositoryMaterial.getMaterialMetric());
                returnMaterialInfo.setMaterialType(repositoryMaterial.getMaterialType());
                returnMaterialInfo.setMaterialBrand(repositoryMaterial.getMaterialBrand());
                returnMaterialInfo.setMaterialUnitPrice(repositoryMaterial.getMaterialPrice());
                returnMaterialInfo.setReturnOrderState(1);
                RepositoryMaterial material_id = repositoryMaterialService.getOne(new QueryWrapper<RepositoryMaterial>().eq("material_id", repositoryMaterial.getMaterialId()));
                material_id.setMaterialAmount(material_id.getMaterialAmount()-repositoryMaterial.getReturnMaterialAmout());
                material_id.setReturnMaterialAmout(material_id.getReturnMaterialAmout()+repositoryMaterial.getReturnMaterialAmout());
                MaterialInfo material_id1 = materialInfoService.getOne(new QueryWrapper<MaterialInfo>().eq("material_id", repositoryMaterial.getMaterialId()));
                material_id1.setMaterialReturnAmount(material_id1.getMaterialReturnAmount()+repositoryMaterial.getMaterialAmount());
                total=total+repositoryMaterial.getReturnMaterialAmout();
                boolean b = materialInfoService.updateById(material_id1);
                //更新仓库材料数量
                boolean updateById = repositoryMaterialService.updateById(material_id);
                //在返库材料信息表添加材料信息
                boolean save = returnMaterialInfoService.save(returnMaterialInfo);
            }
        }
        returnOrder.setReturnTotal(total);
        return returnOrderService.save(returnOrder);
    }
}
