package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.MaterialGroup;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialGroupService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/material-group")
public class MasMaterialGroupController {



    @Autowired
    public IMaterialGroupService iMaterialGroupService;

    @ApiOperation(value = "展示材料小类")
    @PostMapping("showMaterialGroup")
    public Result ShowMaterial(@RequestBody JSONObject jsonObject){
        Integer materialType = jsonObject.getInteger("materialType");
        QueryWrapper<MaterialGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("material_type", materialType);
        List<MaterialGroup> materialGroups = iMaterialGroupService.list(queryWrapper);
        return Result.ok().data("材料详情", materialGroups);
    }
    /**
     * 功能写错地方了
     */
    /*
    @ApiOperation(value = "根据材料类型筛选材料")
    @PostMapping("selectMaterialByType")
    public Result selectMaterialByType(@RequestBody JSONObject jsonObject){
        Integer materialType = jsonObject.getInteger("materialType");
        QueryWrapper<MaterialGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("material_type", materialType);
        List<MaterialGroup> materialGroups = iMaterialGroupService.list(queryWrapper);
        return Result.ok().data("查询的材料", materialGroups);
    }

    @ApiOperation(value = "根据材料名字筛选材料")
    @PostMapping("selectMaterialByName")
    public Result selectMaterialByName(@RequestBody JSONObject jsonObject){
        Integer materialName = jsonObject.getInteger("materialName");
        QueryWrapper<MaterialGroup> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("material_group_name", materialName);
        List<MaterialGroup> materialGroups = iMaterialGroupService.list(queryWrapper);
        return Result.ok();
    }
    */

}

