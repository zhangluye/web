package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class UpdateMaterialTypeAccept {

    private String materialType;

    private String materialGroup;

    private Integer MaterialTypeId;

    private Integer MaterialGroupId;
}
