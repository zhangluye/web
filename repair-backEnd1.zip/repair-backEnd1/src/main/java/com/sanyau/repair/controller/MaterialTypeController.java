package com.sanyau.repair.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.MaterialTypeAccept;
import com.sanyau.repair.accept.UpdateMaterialTypeAccept;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialGroupService;
import com.sanyau.repair.service.IMaterialTypeService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/material-type")
public class MaterialTypeController {
    @Autowired
    private IMaterialTypeService materialTypeService;
    @Autowired
    private IMaterialGroupService materialGroupService;
    @ApiOperation("查询材料类型")
    @PostMapping("/selectMaterialType")
    public Result selectMaterialType(){
        return Result.ok().data(materialTypeService.selectMaterialType());
    }

    @ApiOperation("插入材料类型")
    @PostMapping("/insetMaterialType")
    public Result insertMaterialType(@RequestBody MaterialTypeAccept materialTypeAccept){
        boolean b = materialTypeService.insertMaterialType(materialTypeAccept);
        if (b){
            return Result.ok().message("添加材料成功");
        }else {
            return Result.error("添加材料失败");
        }
    }

    @ApiOperation("删除材料类型")
    @PostMapping("/deleteMaterialType")
    public Result deleteMaterialType(@RequestBody MaterialTypeAccept materialTypeAccept){
        boolean b = materialTypeService.deleteMaterialType(materialTypeAccept);
        if (b){
            return Result.ok().message("删除材料成功");
        }else {
            return Result.error("删除材料失败");
        }
    }
    @ApiOperation("修改材料类型")
    @PostMapping("/updateMaterialType")
    public Result updateMaterialType(@RequestBody UpdateMaterialTypeAccept materialTypeAccept){
        boolean b = materialTypeService.updateMaterialType(materialTypeAccept);
        if (b){
            return Result.ok().message("更新材料成功");
        }else {
            return Result.error("更新材料失败");
        }
    }
    @ApiOperation("展示材料大类")
    @PostMapping("/showMaterialType")
    public Result showMaterialType(@RequestParam("level") int level,@RequestParam("id") String id){
        if(level==0){
            List<MaterialType> list = materialTypeService.list(new QueryWrapper<MaterialType>());
            return Result.ok().data(list);
        }
        if (level==1){
            List<MaterialGroup> materialGroups = showMaterialType(id);
            return Result.ok().data(materialGroups);
        }
        return Result.error("数据异常");
    }

    public List<MaterialGroup> showMaterialType(@RequestParam("typeId") String typeId){
        return materialGroupService.list(new QueryWrapper<MaterialGroup>().eq("material_type", typeId));
    }

}

