package com.sanyau.repair.utils;

import java.util.HashMap;
import java.util.Map;

public class StaticCode {
    public static Map<Integer,String> getMap(){
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"派单中");
        map.put(2,"已接工单");
        map.put(3,"待评价工单");
        map.put(4,"完成工单");
        return map;
    }
    public static Map<Integer,String> getPayMap(){
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"付费订单");
        map.put(2,"免费订单");
        return map;
    }
    public static Map<Integer,String> getHandleMap(){
        Map<Integer,String> map = new HashMap<>();
        map.put(0,"已退回");
        map.put(1,"已取消");
        return map;
    }

    public static Map<Integer,String> getOrderState(){
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"正在出库");
        map.put(2,"拒绝出库");
        map.put(3,"完成出库");
        return map;
    }

    public static Map<Integer,String> getOrderState1(){
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"正在返库");
        map.put(2,"拒绝返库");
        map.put(3,"完成返库");
        return map;
    }

    public static Map<Integer,String> getPayStateMap(){
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"已支付");
        map.put(2,"未支付");
        return map;
    }

    public static String ToPayState(int state){
        for(int i=0;i<getPayStateMap().size()+2;i++){
            if(state==i){
                String test = getPayStateMap().get(i);
                return getPayStateMap().get(i);
            }
        }
        return "";
    }
    public static String ToReturnOrderState(int state){
        for(int i=0;i<getMap().size()+2;i++){
            if(state==i){
                String test = getMap().get(i);
                return getMap().get(i);
            }
        }
        return "";
    }

    public static String ToOrderState(int state){
        for(int i=0;i<getOrderState().size()+2;i++){
            if(state==i){
                String test = getOrderState().get(i);
                return getOrderState().get(i);
            }
        }
        return "";
    }

    public static String ToOrderState1(int state){
        for(int i=0;i<getOrderState1().size()+2;i++){
            if(state==i){
                String test = getOrderState1().get(i);
                return getOrderState1().get(i);
            }
        }
        return "";
    }
    public static String stateToString(String state){
        for(int i=0;i<getMap().size()+2;i++){
            if(state.equals(String.valueOf(i))){
                String test = getMap().get(i);
                return getMap().get(i);
            }
        }
        return "";
    }
    public static String state1ToString(String state){
        for(int i=0;i<getPayMap().size()+3;i++){
            if(state.equals(String.valueOf(i))){
                return getPayMap().get(i);
            }
        }
        return "";
    }
    public static String state1ToString2(String state){
        for(int i=0;i<getHandleMap().size()+3;i++){
            if(state.equals(String.valueOf(i))){
                return getHandleMap().get(i);
            }
        }
        return "";
    }
}
