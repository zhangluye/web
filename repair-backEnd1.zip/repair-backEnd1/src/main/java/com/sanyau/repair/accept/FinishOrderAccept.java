package com.sanyau.repair.accept;

import com.sanyau.repair.entity.RepositoryMaterial;
import lombok.Data;

import java.util.List;

@Data
public class FinishOrderAccept {

    private String account;

    private String orderId;

    private List<RepositoryMaterial> materialId;

    private List<String> pictures;

    private int charge;

}
