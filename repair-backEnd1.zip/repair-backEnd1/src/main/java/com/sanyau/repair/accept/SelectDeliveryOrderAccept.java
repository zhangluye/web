package com.sanyau.repair.accept;

import lombok.Data;

import java.util.Date;
@Data
public class SelectDeliveryOrderAccept {

    private String masterAccount;

    private String DeliveryOrderId;

    private Long[] createTime;

    private String DeliveryOrderState;
}
