package com.sanyau.repair.accept;

import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.entity.RepositoryMaterial;
import lombok.Data;

import java.util.List;

@Data
public class InsertReturnOrderAccept {

    private String account;

    private List<RepositoryMaterial> materialInfos;

    private Long total;
}
