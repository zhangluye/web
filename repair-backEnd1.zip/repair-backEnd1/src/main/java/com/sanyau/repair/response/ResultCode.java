package com.sanyau.repair.response;

public enum  ResultCode implements CustomizeResultCode{
    SUCCESS(20000,"成功"),
    ERROR(20001,"失败"),
    USER_NOT_LOGIN(2001, "用户未登录"),
    USER_ACCOUNT_EXPIRED(2002, "账号已过期"),
    USER_CREDENTIALS_ACCOUNT_ERROR(2003, "账号或密码错误"),
    USER_CREDENTIALS_EXPIRED(2004, "密码过期"),
    USER_ACCOUNT_DISABLE(2005, "账号不可用"),
    USER_ACCOUNT_LOCKED(2006, "账号被锁定"),
    USER_ACCOUNT_NOT_EXIST(2007, "账号不存在"),
    /* 默认失败 */
    COMMON_FAIL(999, "失败"),
    USER_ACCOUNT_ALREADY_EXIST(2008, "账号已存在"),
    NO_PERMISSION(4001, "没有权限"),
    USER_SESSION_INVALID(2010,"登录超时"),
    USER_ACCOUNT_USE_BY_OTHERS(2009, "您的登录已经超时或者已经在另一台机器登录，您被迫下线");

    private Integer code;

    private String message;

    ResultCode(Integer code,String message){
        this.code = code;
        this.message = message;
    }

    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
