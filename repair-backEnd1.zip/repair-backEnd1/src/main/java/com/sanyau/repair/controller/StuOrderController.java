package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.AbnormalOrderMapper;
import com.sanyau.repair.mapper.BuildingMapper;
import com.sanyau.repair.mapper.DetailsMapper;
import com.sanyau.repair.mapper.OrderMapper;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.*;
import com.sanyau.repair.service.impl.OrderServiceImpl;
import com.sanyau.repair.service.impl.StudentInfoServiceImpl;

import com.sanyau.repair.utils.AbnormalUtils;
import com.sanyau.repair.utils.OrderUtils;
import com.sanyau.repair.utils.qiniuyun.QiniuUpload;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/stu/repair/order")
public class StuOrderController {

    @Autowired
    private OrderServiceImpl orderService;

    @Autowired
    private StudentInfoServiceImpl studentInfoService;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private AbnormalOrderMapper abnormalOrderMapper;

    @Autowired
    private ICommunityService iCommunityService;
    @Autowired
    private IRegionService iRegionService;
    @Autowired
    private IBuildingService iBuildingService;
    @Autowired
    private ITypeService iTypeService;

    @Autowired
    private DetailsMapper detailsMapper;
    @Autowired
    private BuildingMapper buildingMapper;

    @ApiOperation("获取所有报修单列表")
    @RequestMapping("/all.select")
    public Result getAllOrder(){
        List<Order> orderList = orderMapper.selectList(null);
        if (orderList.isEmpty()){
            return Result.error().data("error","订单结果为空");
        }
        return Result.ok().data("orderList",orderList);
    }

    /*订单查询-根据状态查询*/
    @ApiOperation(value = "根据状态查找订单")
    @PostMapping("findByOrder_state")
    public Result findByState(@RequestParam("order_state") String order_state,
                              @RequestParam("user_id") String user_id) {

        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", user_id).eq("order_state",order_state);
        List<Order> orders = orderMapper.selectList(wrapper);
        if(orders.size()==0)
        {
            return Result.error().data("info","null");
        }
        //得到区域和类型
        int m = orders.size();
        //类型
        for (int i = 0; i < m; i++) {
            orders.get(i).setRepairType(changeRepairDetails(orders.get(i).getRepairType()));
        }
        //区域
        for (int i = 0; i < m; i++) {
            orders.get(i).setUserCommunity(changeRepairType(orders.get(i).getUserCommunity()));
        }

        return Result.ok().data("info", orders);
    }
    /*异常订单查询-根据student_id*/
    @ApiOperation(value = "根据studentId查找异常订单")
    @PostMapping("findByUserId_abnormal_student")
    public Result findByStudentId_abnormal(@RequestParam("user_id") String user_id) {

        QueryWrapper<AbnormalOrder> wrapper = new QueryWrapper<>();

        wrapper.eq("student_id", user_id);
        List<AbnormalOrder> abnormalOrders = abnormalOrderMapper.selectList(wrapper);
        if (abnormalOrders.size() == 0) {
            return Result.error().data("false","查询信息为空");
        }
//得到区域和类型
        int m = abnormalOrders.size();
        for (int i = 0; i < m; i++) {
            abnormalOrders.get(i).setRequestAddress(changeRepairType(abnormalOrders.get(i).getRequestAddress()));
        }
        for (int i = 0; i < m; i++) {
            abnormalOrders.get(i).setAbnType(changeRepairDetails(abnormalOrders.get(i).getAbnType()));
        }

        return Result.ok().data("info", abnormalOrders);
    }
//    /*异常订单查询-根据openid*/
//    @ApiOperation(value = "根据UserId查找异常订单")
//    @PostMapping("findByUserId_abnormal_worker")
//    public Result findByOpenid_abnormal(@RequestParam("user_id") String user_id) {
//
//        QueryWrapper<AbnormalOrder> wrapper = new QueryWrapper<>();
//
//        wrapper.eq("user_id", user_id);
//        List<AbnormalOrder> abnormalOrders = abnormalOrderMapper.selectList(wrapper);
//        if (abnormalOrders.size() != 1) {
//            return Result.error();
//        }
//        AbnormalOrder info = abnormalOrders.get(0);
//        return Result.ok().data("info", info);
//    }

    /*提交表单-生成一份订单*/
    @PostMapping("/Order/dataForm")
    @ApiOperation(value = "提交订单")

    public  Result StudentOrder (@RequestBody Order order,
                                 @RequestParam("studentId") String student_id
//            , @RequestParam("file") MultipartFile file
    ){
        System.out.println(order);
        //订单id
        String orderId = OrderUtils.getId();
        //订单金额
        BigDecimal order_money = new BigDecimal("0");
        //订单创建时间
        Date date =new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = formatter.format(date);
//        order.setOpenId(openId);
        order.setUserId(student_id);
        order.setOrderCreateTime(date);
        order.setOrderId(orderId);      // 订单id
        order.setOrderState(1);//订单状态
        order.setOrderMoney(order_money);//订单金额
        order.setPayState(2);//订单支付状态
        order.setOrderType("1");
        order.setOrderPrice(BigDecimal.valueOf(0));
        order.setGrade(0);
        boolean save = orderService.save(order);
        if(save){
            return Result.ok().data("inset","提交订单成功");
        }
        else {
            return Result.error().data("insert","提交订单错误");
        }
    }

    /*分页查询*/
    @ApiOperation("获取分页报修单列表")
    @GetMapping("order/selectPage")
    public Result getOrderByPage(@ApiParam(name = "current",value = "当前页",required = true) @RequestParam("current") Long current,
                                 @ApiParam(name = "limit",value = "页面大小",required = true)@RequestParam("limit") Long limit){
        Page<Order> page = new Page<>(current,limit);
        Page<Order> orderPage = orderMapper.selectPage(page, null);
        long total = orderPage.getTotal();
        List<Order> orderList = orderPage.getRecords();
        if (orderList.isEmpty()){
            return Result.error().data("error","订单结果为空");
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("total",total);
        map.put("rows",orderList);
        return Result.ok().data(map);
    }


    /*修改订单评分*/
    @PostMapping("/order/updateOrderGrade")
    @ResponseBody
    public Result updateOrderGrade(@RequestParam("orderId") Long order_id,
                                   @RequestParam("grade") int grade) {
        if (0 > grade || grade > 5) {
            return Result.error().data("error","订单评分超出范围");
        }

        QueryWrapper<Order> wrapper = new QueryWrapper<>();

        wrapper.eq("order_id", order_id);
        List<Order> order = orderService.list(wrapper);

        if (order.size() == 0) {//若订单为空，返回 无此订单
            return Result.error().data("error","无此订单");
        }
        if (order.size() != 1) {//若订单不唯一，返回 订单查询异常
            return  Result.error().data("error","订单查询异常");
        }

        /*查找到对应的orderId的订单*/
        Order orders = order.get(0);
        orders.setGrade(grade);
        orders.setOrderState(4);

        int row = orderMapper.update(orders,wrapper);
        if (row != 1) {
            return Result.error().data("error","订单评分行为异常");
        }
        return Result.ok().data("ok","订单评分成功");
    }

    /*上传图片*/
    @RequestMapping(value = "/upload",method = RequestMethod.POST)
    @ResponseBody
    public Result uploadFile(@RequestParam("file") MultipartFile file){
//        上传文件
        System.out.println("-----------");

        return Result.error();
    }


    /*撤回订单*/
    @PostMapping("/order/updateOrderState")
    @ResponseBody
    public Result updateOrderState(@RequestParam("order_id") Long order_id,
                                   @RequestBody Order order){
        QueryWrapper<Order> wrapper = new QueryWrapper<>();

        wrapper.eq("order_id", order_id);
        System.out.println(order_id);
        List<Order> orders = orderService.list(wrapper);

        /*查找到对应的orderId的订单*/
        Order order1 = orders.get(0);

//        String userId = order.getUserId();
//        order.setUserId(userId);//设置学生的Id

        AbnormalOrder abnormalOrder = new AbnormalOrder();
        abnormalOrder.setOrderId(order.getOrderId());
        AbnormalUtils.setOrderParam(abnormalOrder,order1);
        int resultCount = 0;
        try {
            resultCount = abnormalOrderMapper.insert(abnormalOrder);//插入
        }finally {
            if(resultCount != 1){//若影响行数不为1，则说明插入失败
                return Result.error().data("error","撤回订单失败");
            }
        }

        System.out.println(order1);
        int result = orderMapper.deleteById(order1.getId());
        if(result <1){
            System.out.println(result);
            return Result.error().data("error","撤回订单失败");
        }
        return Result.ok().data("ok","撤回订单成功");
    }

    /*类型筛选*/

    @ApiOperation("展示订单类型")
    @RequestMapping(value = "/showType",method = RequestMethod.POST)
    @ResponseBody
    public Result showType(){
        List<Type> types = iTypeService.list();
        return Result.ok().data("所有类型",types);
    }

    /*材料筛选*/
    @Autowired
    private IDetailsService iDetailsService;
    @ApiOperation("展示材料类型")
    @RequestMapping(value = "/showDetails",method = RequestMethod.POST)
    @ResponseBody
    public Result selectDetails(@RequestParam("repair_type") String repair_type){
//        Integer repairType = jsonObject.getInteger("repairType");
        QueryWrapper<Details> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("repair_type",repair_type);
        List<Details> details = iDetailsService.list(queryWrapper);
        return Result.ok().data("筛选材料",details);
    }


    @ApiOperation(value = "展示社区")
    @RequestMapping(value = "/showCommunity",method = RequestMethod.POST)
    @ResponseBody
    public Result showCommunity(){
        List<Community> communities = iCommunityService.list();
        return Result.ok().data("所有社区", communities);
    }

    @ApiOperation(value = "筛选区域")
    @RequestMapping(value = "/selectRegion",method = RequestMethod.POST)
    @ResponseBody
    public Result selectRegion(@RequestParam("communityType") Integer communityType){
//        Integer communityType = jsonObject.getInteger("communityType");
        QueryWrapper<Region> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("community_type", communityType);
        List<Region> regions = iRegionService.list(queryWrapper);
        return Result.ok().data("筛选区域", regions);
    }

    @ApiOperation(value = "筛选楼名")
    @RequestMapping(value = "/selectBuilding",method = RequestMethod.POST)
    @ResponseBody
    public Result selectBuilding(@RequestParam("regionType") Integer regionType){
//        Integer regionType = jsonObject.getInteger("regionType");
        QueryWrapper<Building> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("region_type", regionType);
        List<Building> buildings = iBuildingService.list(queryWrapper);
        return Result.ok().data("筛选楼名", buildings);
    }
    public String changeRepairDetails(String order){//类型
        Details id = iDetailsService.getOne(new QueryWrapper<Details>().eq("id", order));
        return id.getRepairDetails();
    }
    public String changeRepairType(String order){//区域
        Building id = iBuildingService.getOne(new QueryWrapper<Building>().eq("id", order));
        return id.getBuildingName();
    }

}

