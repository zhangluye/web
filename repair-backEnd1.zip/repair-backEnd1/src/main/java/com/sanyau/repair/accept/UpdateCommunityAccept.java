package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class UpdateCommunityAccept {
    String community;

    String building;

    String region;

    Integer CommunityId;

    Integer BuildingId;

    Integer RegionId;
}
