package com.sanyau.repair.service;

import com.sanyau.repair.accept.InsertReturnOrderAccept;
import com.sanyau.repair.accept.SelectDeliveryOrderAccept;
import com.sanyau.repair.entity.ReturnOrder;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IReturnOrderService extends IService<ReturnOrder> {

    /**
     * 查看全部返库订单
     * @return
     */
    Map<String, Object> selectAllReturnOrder(Long current, Long limit, SelectDeliveryOrderAccept selectDeliveryOrderAccept);

    /**
     * 删除出库订单
     * @param orderId
     * @return
     */
    boolean deleteReturnOrder(String orderId);

    Map<String,Object> selectOneReturnOrder(String orderId);

    boolean updateReturnOrder(String orderId,String opinion);

    Map<String, Object> deleteReturnOrders(List<String> materialInfos);

    /**
     * 师傅端返库
     */
    boolean insertReturnOrder(InsertReturnOrderAccept insertReturnOrderAccept);

}
