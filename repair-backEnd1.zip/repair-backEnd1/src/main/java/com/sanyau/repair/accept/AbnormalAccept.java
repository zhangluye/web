package com.sanyau.repair.accept;

import lombok.Data;

import java.util.Date;

@Data
public class AbnormalAccept {
    private String repairType;


    private Long[] createTime;

    private Long[] finishTime;

    private String orderId;

    private String repairCommunity;

    private String masterAccount;

    private String studentName;

}
