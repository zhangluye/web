package com.sanyau.repair.service;

import com.sanyau.repair.entity.Region;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IRegionService extends IService<Region> {

}
