package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.Details;
import com.sanyau.repair.entity.MasterInfo;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMasterInfoService;
import com.sanyau.repair.utils.ReturnMasterInfo;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.RouteMatcher;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/master-info")
public class MasMasterInfoController {

    @Autowired
    public IMasterInfoService iMasterInfoService;

    @ApiOperation(value = "展示师傅信息")
    @PostMapping("showInfo")
    public Result showInfo(@RequestBody JSONObject jsonObject){
        //获取前端填写数据
        String account = jsonObject.getString("account");
        //查询师傅的数据
        QueryWrapper<MasterInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("account", account);
        MasterInfo masterInfo = iMasterInfoService.getOne(queryWrapper);
        ReturnMasterInfo returnMasterInfo = new ReturnMasterInfo();
        returnMasterInfo.setMasterName(masterInfo.getMasterName());
        returnMasterInfo.setMasterPhone(masterInfo.getMasterPhone());
        return Result.ok().data("师傅信息", returnMasterInfo);
    }

    @ApiOperation(value = "完善师傅信息")
    @PostMapping("perfectInfo")
    public Result perfectInfo(@RequestBody JSONObject jsonObject){
        //获取前端填写数据
        String account = jsonObject.getString("account");
        String masterName = jsonObject.getString("masterName");
        String masterPhone = jsonObject.getString("masterPhone");
        //查询需要更新的数据
        QueryWrapper<MasterInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("account", account);
        MasterInfo masterInfo = iMasterInfoService.getOne(queryWrapper);
        //加入更新的值
        if (masterInfo != null){
            masterInfo.setMasterName(masterName);
        }
        if (masterPhone != null) {
            masterInfo.setMasterPhone(masterPhone);
        }
        //重新更新数据
        iMasterInfoService.updateById(masterInfo);

        return Result.ok().message("完善信息完成");
    }

    @ApiOperation(value = "更新师傅信息")
    @PostMapping("updateInfo")
    public Result updateInfo(@RequestBody JSONObject jsonObject) {
        String account = jsonObject.getString("account");
        String masterName = jsonObject.getString("masterName");
        String masterPhone = jsonObject.getString("masterPhone");
        //查询需要更新的数据
        QueryWrapper<MasterInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("account", account);
        MasterInfo masterInfo = iMasterInfoService.getOne(queryWrapper);
        //加入更新的值
        if (masterInfo != null){
            masterInfo.setMasterName(masterName);
        }
        if (masterPhone != null) {
            masterInfo.setMasterPhone(masterPhone);
        }
        //重新更新数据
        iMasterInfoService.updateById(masterInfo);

        return Result.ok().message("更新信息完成");

    }

    @ApiOperation(value = "展示师傅维修区域")
    @PostMapping("showBuilding")
    public Result showBuilding(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        List<Building> buildings = iMasterInfoService.selectBuilding(account);
        return Result.ok().data("师傅维修区域", buildings);
    }

    @ApiOperation(value = "展示师傅维修类型")
    @PostMapping("show")
    public Result showDetails(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        List<Details> details = iMasterInfoService.selectDetails(account);
        return Result.ok().data("师傅维修类型", details);
    }
}

