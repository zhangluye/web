package com.sanyau.repair.service;

import com.sanyau.repair.accept.DetailsAccept;
import com.sanyau.repair.accept.UpdateDetailsAccept;
import com.sanyau.repair.entity.Details;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
public interface IDetailsService extends IService<Details> {
    /**
     * 添加维修类型
     *
     * @return
     */
    boolean insertDetails(DetailsAccept detailsAccept);

    /**
     * 更新维修类型
     * @return
     */
    boolean updateDetails(UpdateDetailsAccept detailsAccept);

    /**
     * 删除维修类型
     * @return
     */
    boolean deleteDetails(Integer ids);

    /**
     * 展示全部维修类型
     * @return
     */
    Map<String,Object> selectDetails();
}
