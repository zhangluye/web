package com.sanyau.repair.utils;

import com.sanyau.repair.accept.SelectOrderAccept;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.service.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;

public class selectOrderUtils {
    @Autowired
    private IOrderService orderService;


}
