package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialInfoService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/material-info")
public class MasMaterialInfoController {

    @Autowired
    public IMaterialInfoService iMaterialInfoService;

    @ApiOperation(value = "展示材料详情")
    @PostMapping("showMaterial")
    public Result ShowMaterial(@RequestBody JSONObject jsonObject){
        String materialId = jsonObject.getString("materialId");
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("material_id", materialId);
        MaterialInfo materialInfo = iMaterialInfoService.getOne(queryWrapper);
        return Result.ok().data("材料详情", materialInfo);
    }

    @ApiOperation(value = "根据材料名字筛选材料")
    @PostMapping("selectMaterialByName")
    public Result selectMaterialByName(@RequestBody JSONObject jsonObject){
        String materialName = jsonObject.getString("materialName");
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("material_name", materialName);
        List<MaterialInfo> materialGroups = iMaterialInfoService.list(queryWrapper);
        return Result.ok().data("查询的材料", materialGroups);
    }

    @ApiOperation(value = "根据材料类型筛选材料")
    @PostMapping("selectMaterialByType")
    public Result selectMaterialByType(@RequestBody JSONObject jsonObject){
        Integer materialType = jsonObject.getInteger("materialType");
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("material_type", materialType);
        List<MaterialInfo> materialGroups = iMaterialInfoService.list(queryWrapper);
        return Result.ok().data("查询的材料", materialGroups);
    }
}

