package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class SelectAdminAccept {
    private String account;

    private String name;

    private Long[] createTime;

    private String department;

    private String phone;
}
