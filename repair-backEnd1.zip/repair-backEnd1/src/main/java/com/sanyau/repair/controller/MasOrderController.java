package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.CancelOrderAccept;
import com.sanyau.repair.accept.FinishOrderAccept;
import com.sanyau.repair.accept.SelectTaskQueryAccept;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.entity.RepositoryMaterial;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.IDetailsService;
import com.sanyau.repair.service.IOrderService;
import com.sanyau.repair.service.IRepositoryMaterialService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/order")
public class MasOrderController {

    @Autowired
    private IOrderService orderService;
    @Autowired
    public IOrderService iRepairOrderService;
    @Autowired
    private IRepositoryMaterialService repositoryMaterialService;



    @ApiOperation("获取报修单列表")
    @PostMapping("selectOrder")
    public Result getOrderByPage(@ApiParam(name = "current",value = "当前页",required = true) @RequestParam("current") long current,
                                 @ApiParam(name = "limit",value = "页面大小",required = true)@RequestParam("limit") long limit){
        Map<String, Object> orderMap = orderService.getOrder(current, limit);
        if (orderMap.isEmpty()){
            return Result.error("订单结果为空");
        }
        return Result.ok().data(orderMap);
    }



    @ApiOperation("展示师傅未接单的报修单列表")
    @PostMapping("/selectUnAcceptOrder")
    public Result getUnAcceptedOrder(@ApiParam(name = "current",value = "当前页",required = true) @RequestParam("current") long current,
                                     @ApiParam(name = "limit",value = "页面大小",required = true)@RequestParam("limit") long limit){
        Map<String, Object> orderMap = orderService.selectUnAcceptOrder(current, limit);
        if (orderMap.isEmpty()){
            return Result.error("报修单结果为空");
        }
        return Result.ok().data(orderMap);
    }


    @ApiOperation("分页展示师傅已接单的报修单列表")
    @PostMapping("/selectMasterPageOrder")
    public Result getAcceptedOrder(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") long current,
                                   @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") long limit){
        Map<String, Object> orderMap = orderService.selectAcceptOrder(current, limit);
//        List<Order> orderList = (List<Order>) orderMap.get("records");
        if (orderMap.isEmpty()){
            return Result.error("报修单结果为空");
        }
        return Result.ok().data(orderMap);
    }

    @ApiOperation("返回去重的所有订单社区号")
    @PostMapping("/selectAllCommunity")
    public Result selectAllCommunity(){
        return Result.ok().message("社区号").data("communityList",orderService.getAllCommunity());
    }

    @ApiOperation("返回去重已接单号")
    @PostMapping("/selectAcceptCommunity")
    public Result selectAcceptCommunity(){
        return Result.ok().message("已接单社区号").data("communityList",orderService.getAcceptCommunity());
    }

    @ApiOperation("返回去重未接单号")
    @PostMapping("/selectUnAcceptCommunity")
    public Result selectUnAcceptCommunity(){
        return Result.ok().message("未接单社区号").data("communityList",orderService.getUnAcceptCommunity());
    }

    /**
     * suixin
     */
    @ApiOperation("/展示师傅负责区域")
    @PostMapping("/showMasterCommunity")
    public Result showMasterCommunity(@RequestParam("account") String account){
        Map<String, Object> map = orderService.showMasterCommunity(account);
        return Result.ok().data(map);
    }
    /**
     * suixin
     */
    @ApiOperation("根据楼号筛选订单")
    @PostMapping("/orderScreeningToBuildingS")
    public Result orderScreeningToBuildingS(@RequestParam("id") int id,@RequestParam("state") int state){
        Map<String, Object> map = orderService.orderScreeningToBuildingS(id, state);
        return Result.ok().data(map);
    }
    /**
     * suixin
     */
    @ApiOperation("初始化正在派单以及正在维修页面")
    @PostMapping("/showMasterOrder")
    public Result showMasterOrder(@RequestParam("account") String account,@RequestParam("state") String state){
        Map<String, Object> map = orderService.showMasterOrder(account, state);
        return Result.ok().data(map);
    }
    /**
     * suixin
     */
    @ApiOperation("/取消订单")
    @PostMapping("/cancelOrder")
    public Result cancelOrder(@RequestBody CancelOrderAccept cancelOrderAccept){
        boolean b = orderService.cancelOrder(cancelOrderAccept);
        if(b){
            return Result.ok().data("取消订单成功");
        }else {
            return Result.error("取消订单失败");
        }
    }
    /**
     * suixin
     */
    @ApiOperation("/完成工单")
    @PostMapping("/finishOrder")
    public Result finishOrder(@RequestBody FinishOrderAccept finishOrderAccept){
        boolean b = orderService.finishOrder(finishOrderAccept);
        if(b){
            return Result.ok().data("订单完成");
        }else {
            return Result.error("完成订单错误");
        }
    }
    /**
     * suixin
     */
    @ApiOperation("/任务查询模块")
    @PostMapping("/selectTask")
    public Result selectTask(@RequestBody SelectTaskQueryAccept selectTaskQueryAccept){
        Map<String, Object> map = orderService.TaskQuery(selectTaskQueryAccept);
        if(map==null){
            return Result.error("请输入查询条件");
        }else {
            return Result.ok().data(map);
        }
    }
    /**
     * suixin
     */
    @ApiOperation("展示师傅负责的维修类型")
    @PostMapping("/showMasterRepairType")
    public Result showMasterRepairType(@RequestParam("account") String account){
        Map<String, Object> map = orderService.showMasterRepairType(account);
        return Result.ok().data(map);
    }
    /**
     * suixin
     */
    @ApiOperation("展示对应师傅的异常订单")
    @PostMapping("/showAbnormalOrder")
    public Result showAbnormalOrder(@RequestParam("account") String account){
        Map<String, Object> map = orderService.showAbnormalOrder(account);
        return Result.ok().data(map);
    }
    /**
     * suixin
     */
    @ApiOperation("根据楼号筛选异常订单")
    @PostMapping("/showAbnormalOrderByBuilding")
    public Result showAbnormalOrderByBuilding(@RequestParam("account") String account,@RequestParam("community") String community){
        Map<String, Object> map = orderService.showAbnormalOrderByBuilding(account, community);
        return Result.ok().data(map);
    }
    /**
     * suixin
     */
    @ApiOperation("展示单个异常订单")
    @PostMapping("/showOneAbnormalOrder")
    public Result showOneAbnormalOrder(@RequestParam("orderId") String orderId){
        Map<String, Object> map = orderService.showOneAbnormalOrder(orderId);
        return Result.ok().data(map);

    }
    /**
     * suixin
     */
    @ApiOperation("查看订单对应材料")
    @PostMapping("/selectByOrder")
    public Result selectByOrder(@RequestParam("orderId")String orderId){
        Map<String, Object> map = orderService.selectByOrder(orderId);
        return Result.ok().data(map);
    }
}

