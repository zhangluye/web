package com.sanyau.repair.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="AbnormalOrder对象", description="")
public class AbnormalOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty(value = "异常订单ID")
    private String orderId;

    @ApiModelProperty(value = "异常订单创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;

    @ApiModelProperty(value = "异常订单退回时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date returnTime;

    @ApiModelProperty(value = "退回订单人")
    private String returnName;

    @ApiModelProperty(value = "报修人")
    private String requestName;

    @ApiModelProperty(value = "问题")
    private String reason;

    @ApiModelProperty(value = "图片")
    private String image;

    @ApiModelProperty(value = "异常订单类型")
    private String abnType;

    @ApiModelProperty(value = "学生报修照片")
    private String pictureStu;

    @ApiModelProperty(value = "异常订单状态")
    private String state;

    @ApiModelProperty(value = "师傅手机号")
    private String returnPhone;

    @ApiModelProperty(value = "报修人手机号")
    private String requestPhone;

    @ApiModelProperty(value = "报修人地址")
    private String requestAddress;

    @ApiModelProperty(value = "学号")
    private String studentId;

    private String stuDesc;


}
