package com.sanyau.repair.utils.qiniuyun;

import lombok.Data;

@Data
public class StudentFilePicture {
    private int id;
    private String name;
    private String age;
    private String sex;
    private String imageUrl;
}
