package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.DeliveryMaterialInfoAccept;
import com.sanyau.repair.accept.DeliveryOrderAccept;
import com.sanyau.repair.accept.InsertDeliveryOrderAccept;
import com.sanyau.repair.accept.SelectDeliveryOrderAccept;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.DeliveryOrderMapper;
import com.sanyau.repair.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.utils.IDUtils;
import com.sanyau.repair.utils.StaticCode;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class DeliveryOrderServiceImpl extends ServiceImpl<DeliveryOrderMapper, DeliveryOrder> implements IDeliveryOrderService {

    @Autowired
    private IDeliveryOrderService deliveryOrderService;

    @Autowired
    private IDeliveryMaterialInfoService deliveryMaterialInfoService;

    @Autowired
    private IMaterialInfoService materialInfoService;

    @Autowired
    private IRepositoryService repositoryService;

    @Autowired
    private IRepositoryMaterialService repositoryMaterialService;

    @Autowired
    private IDetailsService iDetailsService;

    @Override
    public Map<String, Object> selectAllDeliveryOrder(Long current, Long limit,SelectDeliveryOrderAccept selectDeliveryOrderAccept) {
        Map<String,Object> map = new HashMap<>();
        QueryWrapper<DeliveryOrder> queryWrapper = new QueryWrapper<>();
        if(selectDeliveryOrderAccept==null){
            List<DeliveryOrder> deliveryOrders = deliveryOrderService.list();
            map.put("DeliveryOrders",deliveryOrders);
            return map;
        }
        if(selectDeliveryOrderAccept.getDeliveryOrderId()!=null&&!selectDeliveryOrderAccept.getDeliveryOrderId().equals("")){
            queryWrapper.eq("delivery_order_id",selectDeliveryOrderAccept.getDeliveryOrderId());
        }
        if(selectDeliveryOrderAccept.getDeliveryOrderState()!=null&&!selectDeliveryOrderAccept.getDeliveryOrderState().equals("")){
            if(selectDeliveryOrderAccept.getDeliveryOrderState().equals("正在出库")){
                queryWrapper.eq("delivery_order_state",1);
            }
            if(selectDeliveryOrderAccept.getDeliveryOrderState().equals("拒绝出库")){
                queryWrapper.eq("delivery_order_state",2);
            }
            if(selectDeliveryOrderAccept.getDeliveryOrderState().equals("完成出库")){
                queryWrapper.eq("delivery_order_state",3);
            }

        }
        if(selectDeliveryOrderAccept.getCreateTime()!=null){
            queryWrapper.between("create_time",new Date(selectDeliveryOrderAccept.getCreateTime()[0]),new Date(selectDeliveryOrderAccept.getCreateTime()[1]));
        }
        if(selectDeliveryOrderAccept.getMasterAccount()!=null&&!selectDeliveryOrderAccept.getMasterAccount().equals("")){
            queryWrapper.eq("master_account",selectDeliveryOrderAccept.getMasterAccount());
        }
        Page<DeliveryOrder> deliveryOrderPage = new Page<>(current,limit);
        deliveryOrderService.page(deliveryOrderPage, queryWrapper.orderByDesc("create_time"));
        long orderPageTotal = deliveryOrderPage.getTotal();
        List<DeliveryOrder> deliveryOrders = deliveryOrderPage.getRecords();
        List<DeliveryOrderAccept> list = new ArrayList<>();
        for(DeliveryOrder deliveryOrder:deliveryOrders){
            DeliveryOrderAccept deliveryOrderAccept = new DeliveryOrderAccept();
            BeanUtils.copyProperties(deliveryOrder,deliveryOrderAccept);
            deliveryOrderAccept.setDeliveryOrderState(StaticCode.ToOrderState(deliveryOrder.getDeliveryOrderState()));
            list.add(deliveryOrderAccept);
        }
        map.put("DeliveryOrders", list);
        map.put("orderPageTotal", orderPageTotal);
        return map;
    }

    @Override
    public boolean updateDeliveryOrder(String orderId,String opinion) {
        boolean b=false;
        boolean b1 = false;
        DeliveryOrder deliveryOrder = deliveryOrderService.getOne(new QueryWrapper<DeliveryOrder>().eq("delivery_order_id", orderId));
        List<DeliveryMaterialInfo> delivery_order_id = deliveryMaterialInfoService.list(new QueryWrapper<DeliveryMaterialInfo>().eq("delivery_order_id", orderId));
        if(opinion.equals("同意")){
            deliveryOrder.setDeliveryOrderState(3);
            for(DeliveryMaterialInfo deliveryMaterialInfo :delivery_order_id){
//                MaterialInfo material_id = materialInfoService.getOne(new QueryWrapper<MaterialInfo>().eq("material_id", deliveryMaterialInfo.getMaterialId()));
//                material_id.setMaterialTotal(material_id.getMaterialTotal()-deliveryMaterialInfo.getDeliveryAmount());
//                material_id.setMaterialDeliveryAmount(material_id.getMaterialDeliveryAmount()+deliveryMaterialInfo.getDeliveryAmount());
                DeliveryMaterialInfo one = deliveryMaterialInfoService.getOne(new QueryWrapper<DeliveryMaterialInfo>().eq("material_id", deliveryMaterialInfo.getMaterialId()).eq("delivery_order_id", deliveryOrder.getDeliveryOrderId()));
                one.setDeliveryOrderState(3);
                b1 = deliveryMaterialInfoService.updateById(one);
                Repository repository = repositoryService.getOne(new QueryWrapper<Repository>().eq("master_account", deliveryOrder.getMasterAccount()));
                RepositoryMaterial repositoryMaterial = repositoryMaterialService.getOne(new QueryWrapper<RepositoryMaterial>().eq("material_id", deliveryMaterialInfo.getMaterialId()).eq("repo_id",repository.getRepoId()));
                if(repositoryMaterial==null){
                    RepositoryMaterial repositoryMaterial1 = new RepositoryMaterial();
                    repositoryMaterial1.setId(null);
                    repositoryMaterial1.setRepoId(repository.getRepoId());
                    repositoryMaterial1.setMaterialId(deliveryMaterialInfo.getMaterialId());
                    repositoryMaterial1.setMaterialName(deliveryMaterialInfo.getMaterialName());
                    repositoryMaterial1.setMaterialPrice(deliveryMaterialInfo.getMaterialUnitPrice());
                    repositoryMaterial1.setMaterialAmount(Long.valueOf(deliveryMaterialInfo.getDeliveryAmount()));
                    repositoryMaterial1.setMaterialMetric(deliveryMaterialInfo.getMaterialMetric());
                    repositoryMaterial1.setMaterialBrand(deliveryMaterialInfo.getMaterialBrand());
                    repositoryMaterial1.setMaterialType(deliveryMaterialInfo.getMaterialType());
                    repositoryMaterial1.setRepoMaterialTotal(Long.valueOf(deliveryMaterialInfo.getDeliveryAmount()));
                    repositoryMaterial1.setReturnMaterialAmout(Long.valueOf(deliveryMaterialInfo.getDeliveryAmount()));

                    b = repositoryMaterialService.save(repositoryMaterial1);
                }else {
                    repositoryMaterial.setRepoMaterialTotal(repositoryMaterial.getRepoMaterialTotal()+deliveryMaterialInfo.getDeliveryAmount());
                    repositoryMaterial.setMaterialAmount(Long.valueOf(deliveryMaterialInfo.getDeliveryAmount())+repositoryMaterial.getMaterialAmount());
                    one = deliveryMaterialInfoService.getOne(new QueryWrapper<DeliveryMaterialInfo>().eq("material_id", deliveryMaterialInfo.getDeliveryOrderId()).eq("delivery_order_id", deliveryOrder.getDeliveryOrderId()));
                    one.setDeliveryOrderState(2);
                    b = deliveryMaterialInfoService.updateById(one);
                    b1 = repositoryMaterialService.updateById(repositoryMaterial);
                }
            }
        }
        if(opinion.equals("不同意")){

            deliveryOrder.setDeliveryOrderState(2);
            for(DeliveryMaterialInfo deliveryMaterialInfo :delivery_order_id){
                deliveryMaterialInfo.setDeliveryOrderState(2);
                MaterialInfo material_id = materialInfoService.getOne(new QueryWrapper<MaterialInfo>().eq("material_id", deliveryMaterialInfo.getMaterialId()));
                material_id.setMaterialTotal(material_id.getMaterialTotal()+deliveryMaterialInfo.getDeliveryAmount());
                material_id.setMaterialDeliveryAmount(material_id.getMaterialDeliveryAmount()-deliveryMaterialInfo.getDeliveryAmount());
                b = materialInfoService.updateById(material_id);
                b1 = deliveryMaterialInfoService.updateById(deliveryMaterialInfo);
            }
        }
        return deliveryOrderService.updateById(deliveryOrder)&&b&&b1;
    }

    @Override
    public boolean deleteDeliveryOrder(String deliveryOrderId) {
        boolean remove1 = deliveryMaterialInfoService.remove(new QueryWrapper<DeliveryMaterialInfo>().eq("delivery_order_id", deliveryOrderId));
        if(remove1){
            boolean remove = deliveryOrderService.remove(new QueryWrapper<DeliveryOrder>().eq("delivery_order_id", deliveryOrderId));
            return remove;
        }else {
            return false;
        }
    }

    @Override
    public Map<String,Object> selectMaterial(String orderId) {
        Map<String,Object> map = new HashMap<>();
        List<DeliveryMaterialInfo> deliveryMaterialInfos = deliveryMaterialInfoService.list(new QueryWrapper<DeliveryMaterialInfo>().eq("delivery_order_id", orderId));
        List<DeliveryMaterialInfoAccept> deliveryMaterialInfoAcceptList = new ArrayList<>();
        for(DeliveryMaterialInfo deliveryMaterialInfo:deliveryMaterialInfos){
            DeliveryMaterialInfoAccept deliveryMaterialInfoAccept = new DeliveryMaterialInfoAccept();
            BeanUtils.copyProperties(deliveryMaterialInfo,deliveryMaterialInfoAccept);
            Details id = iDetailsService.getOne(new QueryWrapper<Details>().eq("id", deliveryMaterialInfo.getMaterialType()));
            deliveryMaterialInfoAccept.setMaterialType(id.getRepairDetails());
            deliveryMaterialInfoAcceptList.add(deliveryMaterialInfoAccept);
        }
        DeliveryOrder deliveryOrder = deliveryOrderService.getOne(new QueryWrapper<DeliveryOrder>().eq("delivery_order_id", orderId));
        DeliveryOrderAccept deliveryOrderAccept = new DeliveryOrderAccept();
        BeanUtils.copyProperties(deliveryOrder,deliveryOrderAccept);
        deliveryOrderAccept.setDeliveryOrderState(StaticCode.ToOrderState(deliveryOrder.getDeliveryOrderState()));
        map.put("materials",deliveryMaterialInfoAcceptList);
        map.put("deliveryOrder",deliveryOrderAccept);
        return map;
    }

    @Override
    public Map<String, Object> deleteDeliveryOrders(List<String> deliveryOrders) {
        int success = 0;
        int error = 0;
        if(deliveryOrders.size()!=0){
            for(String deliveryOrder:deliveryOrders){
                boolean b = deliveryOrderService.deleteDeliveryOrder(deliveryOrder);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public boolean insertDeliverOrder(InsertDeliveryOrderAccept insertDeliveryOrderAccept) {
        DeliveryOrder deliveryOrder = new DeliveryOrder();
        deliveryOrder.setId(null);
        deliveryOrder.setDeliveryOrderId(IDUtils.getId());
        deliveryOrder.setDeliveryOrderState(1);
        Long total = 0L;
        deliveryOrder.setCreateTime(new Date());
        deliveryOrder.setMasterAccount(insertDeliveryOrderAccept.getAccount());
        if(insertDeliveryOrderAccept.getMaterialInfos().size()!=0){
            DeliveryMaterialInfo deliveryMaterialInfo = new DeliveryMaterialInfo();
            for(MaterialInfo materialInfo: insertDeliveryOrderAccept.getMaterialInfos()){
                deliveryMaterialInfo.setId(null);
                deliveryMaterialInfo.setMaterialId(materialInfo.getMaterialId());
                deliveryMaterialInfo.setMaterialName(materialInfo.getMaterialName());
                deliveryMaterialInfo.setDeliveryAmount(Math.toIntExact(materialInfo.getMaterialReturnAmount()));
                deliveryMaterialInfo.setDeliveryOrderId(deliveryOrder.getDeliveryOrderId());
                deliveryMaterialInfo.setMaterialMetric(materialInfo.getMaterialMetric());
                total=total+materialInfo.getMaterialReturnAmount();
                deliveryMaterialInfo.setMaterialType(materialInfo.getMaterialType());
                deliveryMaterialInfo.setMaterialBrand(materialInfo.getMaterialBrand());
                deliveryMaterialInfo.setMaterialUnitPrice(materialInfo.getMaterialPrice());
                deliveryMaterialInfo.setDeliveryOrderState(1);
                MaterialInfo material_id = materialInfoService.getOne(new QueryWrapper<MaterialInfo>().eq("material_id", materialInfo.getMaterialId()));
                material_id.setMaterialDeliveryAmount(material_id.getMaterialDeliveryAmount()+materialInfo.getMaterialReturnAmount());
                material_id.setMaterialTotal(material_id.getMaterialTotal()-materialInfo.getMaterialReturnAmount());
                boolean updateById = materialInfoService.updateById(material_id);
                //在返库材料信息表添加材料信息
                boolean save = deliveryMaterialInfoService.save(deliveryMaterialInfo);
            }
        }
        deliveryOrder.setDeliveryTotal(total);
        return deliveryOrderService.save(deliveryOrder);
    }
}
