package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class SelectTaskQueryAccept {

    private String userName;

    private String repairType;

    private String UserCommunity;

    private String orderState;

    private String UserApartment;

    private String orderCreateTimeStart;

    private String orderCreateTimeEnd;

    private String orderFinishTimeStart;

    private String orderFinishTimeEnd;

    private String account;
}
