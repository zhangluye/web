package com.sanyau.repair.accept;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateMasterAccept {

    private String account;

    private String masterName;

    private String masterPhone;
}
