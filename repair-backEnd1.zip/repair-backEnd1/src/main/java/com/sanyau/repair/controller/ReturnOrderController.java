package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.SelectDeliveryOrderAccept;
import com.sanyau.repair.accept.SelectMasterAccept;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.entity.ReturnOrder;
import com.sanyau.repair.mapper.OrderMapper;
import com.sanyau.repair.mapper.ReturnOrderMapper;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IReturnOrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/return-order")
public class ReturnOrderController {

    @Autowired
    private IReturnOrderService returnOrderService;
    @Autowired
    private ReturnOrderMapper returnOrderMapper;
    @Autowired
    private OrderMapper orderMapper;

    @ApiOperation("/查看全部返库订单")
    @PostMapping("/selectAllReturnOrder")
    public Result selectAllReturnOrder(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                       @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                       @RequestBody SelectDeliveryOrderAccept selectDeliveryOrderAccept){
        Map<String, Object> stringObjectMap = returnOrderService.selectAllReturnOrder(current, limit, selectDeliveryOrderAccept);
        return Result.ok().data(stringObjectMap);
    }

    @ApiOperation("/查看单个返库订单")
    @PostMapping("/selectOneReturnOrder")
    public Result selectOneReturnOrder(@RequestParam("orderId") String orderId){
        Map<String, Object> stringObjectMap = returnOrderService.selectOneReturnOrder(orderId);
        return Result.ok().data(stringObjectMap);
    }

    @ApiOperation("/审批订单")
    @PostMapping("/updateReturnOrder")
    public Result updateReturnOrder(@RequestParam("orderId") String orderId,
                                    @RequestParam("opinion") String opinion){
        boolean b = returnOrderService.updateReturnOrder(orderId, opinion);
        if (b){
            return Result.ok();
        }else {
            return Result.error("审批失败");
        }
    }
    @ApiOperation("/删除出库订单")
    @PostMapping("/deleteReturnOrder")
    public Result deleteReturnOrder(@RequestParam("id") String id){
        boolean b = returnOrderService.deleteReturnOrder(id);
        if (b){
            return Result.ok();
        }else {
            return Result.error("删除失败");
        }
    }

    @ApiOperation("批量删除订单")
    @PostMapping("/deleteReturnOrders")
    public Result deleteReturnOrders(@RequestBody List<String> orders){
        Map<String, Object> map = returnOrderService.deleteReturnOrders(orders);
        return Result.ok().data(map);
    }
}

