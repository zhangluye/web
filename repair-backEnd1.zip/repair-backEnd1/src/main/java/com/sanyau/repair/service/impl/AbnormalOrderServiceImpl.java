package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.AbnormalAccept;
import com.sanyau.repair.accept.ReturnOrderAccept;
import com.sanyau.repair.accept.SelectOrderAccept;
import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.MasterInfo;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.mapper.AbnormalOrderMapper;
import com.sanyau.repair.service.IAbnormalOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.service.IMasterInfoService;
import com.sanyau.repair.utils.IDUtils;
import com.sanyau.repair.utils.StaticCode;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class AbnormalOrderServiceImpl extends ServiceImpl<AbnormalOrderMapper, AbnormalOrder> implements IAbnormalOrderService {

    @Autowired
    private IAbnormalOrderService abnormalOrderService;
    @Autowired
    private IMasterInfoService masterInfoService;
    @Override
    public Map<String, Object> selectAllAbnormal(Long current, Long limit, AbnormalAccept abnormalAccept) {
        Page<AbnormalOrder> abnormalOrderPage = new Page<>(current,limit);
        QueryWrapper<AbnormalOrder> queryWrapper = selectOrder(abnormalAccept);
        abnormalOrderService.page(abnormalOrderPage,queryWrapper.orderByDesc("create_time"));
        long abnormalOrderTotal = abnormalOrderPage.getTotal();
        List<AbnormalOrder> records = abnormalOrderPage.getRecords();//数据list集合
        List<AbnormalOrder> list = new ArrayList<>();
        for(int i=0;i<records.size();i++){
            AbnormalOrder abnormalOrder = new AbnormalOrder();
            BeanUtils.copyProperties(records.get(i),abnormalOrder);
            abnormalOrder.setAbnType(StaticCode.state1ToString2(records.get(i).getAbnType()));
            abnormalOrder.setState(StaticCode.state1ToString2(records.get(i).getState()));
            list.add(abnormalOrder);
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", abnormalOrderTotal);
        map.put("abnormal", list);
        return map;
    }

    @Override
    public Map<String,Object> selectOneAbnormal(String orderId) {
        AbnormalOrder order_id = abnormalOrderService.getOne(new QueryWrapper<AbnormalOrder>().eq("order_id", orderId));
        MasterInfo masterInfo = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", order_id.getReturnName()));
        Map<String,Object> map = new HashMap<>();
        map.put("order",order_id);
        map.put("master",masterInfo);
        return map;
    }

    public final QueryWrapper<AbnormalOrder> selectOrder(AbnormalAccept abnormalAccept) {
        QueryWrapper<AbnormalOrder> queryWrapper = new QueryWrapper<AbnormalOrder>();
        if(abnormalAccept!=null){
            if(abnormalAccept.getCreateTime()!=null){
                queryWrapper.between("create_time",abnormalAccept.getCreateTime()[0],abnormalAccept.getCreateTime()[1]);
            }
            if(abnormalAccept.getMasterAccount()!=null&&!abnormalAccept.getMasterAccount().equals("")){
                queryWrapper.eq("master_account",abnormalAccept.getMasterAccount());
            }
            if(abnormalAccept.getOrderId()!=null&&!abnormalAccept.getOrderId().equals("")){
                queryWrapper.eq("order_id",abnormalAccept.getOrderId());
            }
            if(abnormalAccept.getRepairCommunity()!=null&&!abnormalAccept.getRepairCommunity().equals("")){
                queryWrapper.eq("user_community",abnormalAccept.getRepairCommunity());
            }
            if(abnormalAccept.getFinishTime()!=null){
                queryWrapper.between("order_create_time",abnormalAccept.getFinishTime()[0],abnormalAccept.getFinishTime()[1]);
            }
            if(abnormalAccept.getRepairType()!=null&&!abnormalAccept.getRepairType().equals("")){
                queryWrapper.eq("repair_type",abnormalAccept.getRepairType());
            }
            if(abnormalAccept.getStudentName()!=null&&!abnormalAccept.getStudentName().equals("")){
                queryWrapper.eq("user_name",abnormalAccept.getStudentName());
            }
        }
        return queryWrapper;
    }
    @Override
    public Map<String,Object> deleteAbnormalOrders(List<String> abnormalOrders){
        int success = 0;
        int error = 0;
        if(abnormalOrders.size()!=0){
            for(String abnormalOrder:abnormalOrders){
                boolean b = deleteAbnormalOrder(abnormalOrder);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public boolean deleteAbnormalOrder(String id) {
        return abnormalOrderService.remove(new QueryWrapper<AbnormalOrder>().eq("order_id", id));
    }
}
