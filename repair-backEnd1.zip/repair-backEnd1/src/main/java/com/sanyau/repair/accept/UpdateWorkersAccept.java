package com.sanyau.repair.accept;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UpdateWorkersAccept {

    private Integer id;

    private String workersName;

    private String workersPhone;

    private String workersApartment;
}
