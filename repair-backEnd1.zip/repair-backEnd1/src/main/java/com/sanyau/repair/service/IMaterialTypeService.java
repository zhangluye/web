package com.sanyau.repair.service;

import com.sanyau.repair.accept.MaterialTypeAccept;
import com.sanyau.repair.accept.UpdateMaterialTypeAccept;
import com.sanyau.repair.entity.MaterialType;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IMaterialTypeService extends IService<MaterialType> {
    /**
     * 增加材料类型
     */
    boolean insertMaterialType(MaterialTypeAccept materialTypeAccept);

    /**
     * 删除材料类型
     */
    boolean deleteMaterialType(MaterialTypeAccept materialTypeAccept);
    /**
     * 查材料类型
     */
    Map<String,Object> selectMaterialType();

    /**
     * 更新材料类型
     */
    boolean updateMaterialType(UpdateMaterialTypeAccept materialAccept);
}
