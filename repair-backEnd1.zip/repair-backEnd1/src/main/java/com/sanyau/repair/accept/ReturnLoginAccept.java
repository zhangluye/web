package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class ReturnLoginAccept {
    private String[] roles;
    private String name;
    private String account;
    private String mobile;
    private String department;
}
