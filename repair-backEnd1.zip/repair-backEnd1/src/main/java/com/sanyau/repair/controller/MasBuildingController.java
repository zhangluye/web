package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.Region;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IBuildingService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
@RestController
@RequestMapping("/mas/repair/building")
public class MasBuildingController {
    @Autowired
    private IBuildingService iBuildingService;

    @ApiOperation(value = "筛选楼名")
    @RequestMapping(value = "/selectBuilding",method = RequestMethod.GET)
    @ResponseBody
    public Result selectBuilding(@RequestBody JSONObject jsonObject){
        Integer regionType = jsonObject.getInteger("regionType");
        QueryWrapper<Building> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("region_type", regionType);
        List<Building> buildings = iBuildingService.list(queryWrapper);
        return Result.ok().data("筛选楼名", buildings);
    }

    @ApiOperation(value = "师傅负责的楼")
    @RequestMapping(value = "/masterBuilding",method = RequestMethod.GET)
    @ResponseBody
    public Result masterBuilding(@RequestBody JSONObject jsonObject){
        Integer masterAccount = jsonObject.getInteger("masterAccount");
        QueryWrapper<Building> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("master_account", masterAccount);
        List<Building> buildings = iBuildingService.list(queryWrapper);
        return Result.ok().data("师傅负责的楼", buildings);
    }
}

