package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class CommunityAccept {

    String community;

    String building;

    String region;

}
