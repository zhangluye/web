package com.sanyau.repair.accept;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class MaterialAccept {

    @ApiModelProperty(value = "材料名")
    private String materialName;

    @ApiModelProperty(value = "材料总数量")
    private Long materialTotal;

    @ApiModelProperty(value = "单位")
    private String materialMetric;

    @ApiModelProperty(value = "材料价格")
    private BigDecimal materialPrice;

    @ApiModelProperty(value = "材料品牌")
    private String materialBrand;

    @ApiModelProperty(value = "材料类型")
    private String materialType;

    private String remarks;

}
