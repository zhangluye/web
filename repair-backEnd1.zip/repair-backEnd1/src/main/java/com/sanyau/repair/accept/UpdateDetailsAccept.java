package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class UpdateDetailsAccept {

    private String repairType;

    private String repairDetails;

    private String repairId;

    private String detailsId;
}
