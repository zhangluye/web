package com.sanyau.repair.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
@RestController
@RequestMapping("/repair/building")
public class BuildingController {

}

