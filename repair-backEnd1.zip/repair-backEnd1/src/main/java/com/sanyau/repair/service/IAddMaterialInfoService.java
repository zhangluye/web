package com.sanyau.repair.service;

import com.sanyau.repair.entity.AddMaterialInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
public interface IAddMaterialInfoService extends IService<AddMaterialInfo> {

}
