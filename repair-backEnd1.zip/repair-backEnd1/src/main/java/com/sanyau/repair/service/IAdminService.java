package com.sanyau.repair.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.SelectAdminAccept;
import com.sanyau.repair.accept.SelectManyAccept;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sanyau.repair.accept.AdminAccept;
import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.response.Result;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
public interface IAdminService extends IService<Admin> {

    /**
     * 查询所有用户信息
     */
    Map<String,Object> selectAllAdmin(Long current, Long limit, SelectAdminAccept selectAdminAccept);

    /**
     * 增加管理员信息
     */
    Boolean insertAdmin(AdminAccept adminAccept);

    /**
     * 更新管理员信息
     */
    Boolean updateAdmin(AdminAccept adminAccept);

    /**
     * 删除管理员
     */
    Boolean deleteAdmin(String account);

    /**
     * 更新管理员权限
     */
    Boolean updatePower(String power,String account);

    /**
     * 查询单个管理员信息
     */
    Map<String,Object> selectOneAdmin(String account);

    /**
     * 查询多个管理员信息
     */
    Map<String,Object> selectManyAdmin(SelectManyAccept selectManyAccept);

    /**
     * 修改密码
     */
    boolean updatePassword(String password,String newPassword);
    /**
     * 登陆成功返回token
     * @param username
     * @param password
     * @param httpServletRequest
     * @return
     */
    Result login(String username, String password, HttpServletRequest httpServletRequest);

    /**
     * 根据用户名获取用户
     * @param username
     * @return
     */
    Admin getAdminByUserName(String username);

    QueryWrapper<Admin> selectAdmins(SelectAdminAccept selectAdminAccept);

    Map<String, Object> deleteAdmins(List<String> admins);

    Map<String,Object> selectPower();
}
