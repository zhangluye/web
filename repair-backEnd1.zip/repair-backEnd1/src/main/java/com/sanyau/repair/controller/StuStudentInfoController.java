package com.sanyau.repair.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.Details;
import com.sanyau.repair.entity.StudentInfo;
import com.sanyau.repair.handler.mybatis.StudentInfoMetaObjectHandler;
import com.sanyau.repair.mapper.StudentInfoMapper;
import com.sanyau.repair.response.HttpRequest;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.impl.StudentInfoServiceImpl;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/stu/repair/student-info")
public class StuStudentInfoController {

    @Autowired
    StudentInfoServiceImpl studentInfoService;

    @Autowired
    private IBuildingService iBuildingService;


    @Autowired
    StudentInfoMapper studentInfoMapper;

    /*所有学生信息查询*/
    public static void main(String[] gars){
        System.out.println("hello");
    }
    @ApiOperation(value = "查询所有学生信息")
    @PostMapping("/selectAllStudent")
    public Result selectAllStudent() {
        List<StudentInfo> studentInfos = studentInfoMapper.selectList(null);
        if (studentInfos.isEmpty()) {
            return Result.error().data("error", "查询结果为空");
        }
        return Result.ok().data("workersList", studentInfos);
    }

    /*学员信息查询-根据学号查询*/
    @ApiOperation(value = "openId")
    @PostMapping("findByStudent_id")
    public Result findById(@RequestParam("openId") String openid) {
        /* 创建StudentInfo的条件查询类 */
        QueryWrapper<StudentInfo> wrapper = new QueryWrapper<>();
        /* column为数据库表的字段名,eq为equal的意思，即相等
         * wrapper更多的条件查询，请看Mybatis-plus官网：条件构造器
         * Address：https://mp.baomidou.com/guide/wrapper.html */
        wrapper.eq("openId", openid);
        List<StudentInfo> studentInfos = studentInfoMapper.selectList(wrapper);
        if (studentInfos.size() != 1) {
            return Result.error();
        }
        studentInfos.get(0).setStudentApartment(changeRepairType(studentInfos.get(0).getStudentApartment()));
        System.out.println(changeRepairType(studentInfos.get(0).getStudentApartment()));
        return Result.ok().data("info", studentInfos);
    }

    /*学员注册*/
    @ApiOperation(value = "添加学生")
    @PostMapping("inset")
    public Result StudentInsert(@RequestParam("code")  String code,
                                StudentInfo studentInfo
    ) {
        Map<String,Object> map = new HashMap<String,Object>();
        //登录凭证不能为空
        if (code == null || code.length() == 0) {
            map.put("status", 0);
            map.put("msg", "code 不能为空");
            System.out.println("map1:" + map);
            return Result.error().data("error","code不能为空");
        }

        //小程序唯一标识
        String wxspAppid = "wx6fd8e65ec59c2bc8";
        //小程序的 app secret
        String wxspSecret = "47cac153445502d4a9b16490b207dd02";
        //授权
        String grant_type = "authorization_code";
//      向微信服务器 使用登录凭证 code 获取 session_key 和 openid
        //请求参数
        String params = "appid=" + wxspAppid + "&secret=" + wxspSecret + "&js_code=" + code + "&grant_type=" + grant_type;
        //发送请求
        String sr = HttpRequest.sendGet("https://api.weixin.qq.com/sns/jscode2session", params);
        //解析相应内容（转换成json对象）
        JSONObject json = JSONObject.parseObject(sr);
        //获取会话密钥（session_key）
        String session_key = json.get("session_key").toString();
        //用户的唯一标识（openid）
        String openid = (String) json.get("openid");
        System.out.println("openid:" + openid);


        studentInfo.setOpenid(openid);
        System.out.println(studentInfo.toString());
        if (studentInfo.getStudentName() == null ||
                studentInfo.getStudentId() == null ||
                studentInfo.getStudentPhone() == null ||
                studentInfo.getStudentDormitoryId() == null ||
                studentInfo.getStudentClass() == null ||
                studentInfo.getStudentCollege() == null ||
                studentInfo.getStudentApartment() == null
        ) {
            return Result.error().data("info", "注册信息填充不完整");
        }

        boolean save = studentInfoService.save(studentInfo);
        if (save) {
            return Result.ok().data("inset", "注册成功");
        } else {
            return Result.error();
        }
    }


//    /*学员信息更改*/
//    @ApiOperation(value = "修改学生信息")
//    @PostMapping("update")
//    public Result StudentUpdate(@RequestParam(name = "studentName", required = false) String student_name,
////                                @RequestParam(name = "student_id", required = false) String student_id,
////                                @RequestParam(name = "student_phone", required = false) String student_phone,
//                                @RequestParam(name = "studentDormitoryId", required = false) String student_dormitory_id,
//                                @RequestParam(name = "studentClass", required = false) String student_class,
////                                @RequestParam(name = "student_college", required = false) String student_college,
//                                @RequestParam(name = "studentApartment", required = false) String student_apartment,
//                                @RequestParam("openId") String openid
//
//    ) {
//        QueryWrapper<StudentInfo> queryWrapper = new QueryWrapper<>();
//
//        queryWrapper.eq("openid", openid);
//        StudentInfo studentInfo = new StudentInfo();
//        studentInfo.setStudentName(student_name);
//        studentInfo.setStudentDormitoryId(student_dormitory_id);
//        studentInfo.setStudentClass(student_class);
//        studentInfo.setStudentApartment(student_apartment);
//        studentInfoMapper.update(studentInfo, queryWrapper);
//        return Result.ok().data("update", "更新成功");
//    }

    /*学员信息更改*/
    @ApiOperation(value = "修改学生信息")
    @PostMapping("update")
    public Result StudentUpdate(@RequestParam(name = "studentName", required = false) String student_name,
                                @RequestParam(name = "studentId", required = false) String student_id,
                                @RequestParam(name = "studentPhone", required = false) String student_phone,
                                @RequestParam(name = "studentDormitoryId", required = false) String student_dormitory_id,
                                @RequestParam(name = "studentClass", required = false) String student_class,
                                @RequestParam(name = "studentCollege", required = false) String student_college,
                                @RequestParam(name = "studentApartment", required = false) String student_apartment,
                                @RequestParam("openId") String openid

    ) {

        QueryWrapper<StudentInfo> queryWrapper = new QueryWrapper<>();

        queryWrapper.eq("openid", openid);
        StudentInfo studentInfo = new StudentInfo();
        studentInfo.setStudentName(student_name);
        studentInfo.setStudentDormitoryId(student_dormitory_id);
        studentInfo.setStudentClass(student_class);
        studentInfo.setStudentApartment(student_apartment);
        studentInfoMapper.update(studentInfo, queryWrapper);

        return Result.ok().data("update", "更新成功");
    }


    /*学生登录*/
    @ApiOperation(value = "学生登录")
    @PostMapping("/login")
    public Result StudentLogin(@RequestParam("code")  String code){

        Map<String,Object> map = new HashMap<String,Object>();
        //登录凭证不能为空
        if (code == null || code.length() == 0) {
            map.put("status", 0);
            map.put("msg", "code 不能为空");
            System.out.println("map1:" + map);
            return Result.error().data("error","code不能为空");
        }

        //小程序唯一标识
        String wxspAppid = "wx6fd8e65ec59c2bc8";
        //小程序的 app secret
        String wxspSecret = "47cac153445502d4a9b16490b207dd02";
        //授权
        String grant_type = "authorization_code";
//      向微信服务器 使用登录凭证 code 获取 session_key 和 openid
        //请求参数
        String params = "appid=" + wxspAppid + "&secret=" + wxspSecret + "&js_code=" + code + "&grant_type=" + grant_type;
        //发送请求
        String sr = HttpRequest.sendGet("https://api.weixin.qq.com/sns/jscode2session", params);
        //解析相应内容（转换成json对象）
        JSONObject json = JSONObject.parseObject(sr);
        //获取会话密钥（session_key）
        String session_key = json.get("session_key").toString();
        //用户的唯一标识（openid）
        String openid = (String) json.get("openid");
        System.out.println("openid:" + openid);
        StudentInfo studentInfo = new StudentInfo();
//        //生成token
//
//        String token = JwtUtils.getJwtToken(openid, studentInfo.getStudentName());
//
//        if(JwtUtils.checkToken(token)){
//            return  Result.ok();
//        }
//        else {
//            return Result.error();
//        }
        studentInfo.setOpenid(openid);
        System.out.println(openid);
        try{
            StudentInfo studentInfo1 = studentInfoService.getOne(new QueryWrapper<StudentInfo>()
                    .eq("openid", studentInfo.getOpenid()));
            if (studentInfo1==null){
                return Result.error().data("false", "登录失败");
            }
            System.out.println(studentInfo1);
            String student_id = studentInfo1.getStudentId();

            return Result.ok().data("true", openid).data("studentId",student_id);
        }catch (Exception e){
            e.printStackTrace();
            return Result.error();
        }
    }
    public String changeRepairType(String order){//区域
        Building id = iBuildingService.getOne(new QueryWrapper<Building>().eq("id", order));
        return id.getBuildingName();
    }

}

