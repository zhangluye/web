package com.sanyau.repair.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.CommunityAccept;
import com.sanyau.repair.accept.CommunityTypeAccept;
import com.sanyau.repair.accept.UpdateCommunityAccept;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.Community;
import com.sanyau.repair.entity.Region;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.ICommunityService;
import com.sanyau.repair.service.IRegionService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-11
 */
@RestController
@RequestMapping("/repair/community")
public class CommunityController {
    @Autowired
    private ICommunityService communityService;
    @Autowired
    private IBuildingService buildingService;
    @Autowired
    private IRegionService regionService;

    @ApiOperation("增加社区信息")
    @PostMapping("/insertCommunity")
    public Result insertCommunity(@RequestBody CommunityAccept communityAccept) {
        if (communityAccept == null) {
            return Result.error("请添加数据");
        }
        boolean insertCommunity = communityService.insertCommunity(communityAccept);
        if (insertCommunity) {
            return Result.ok().message("添加数据成功");
        }else{
            return Result.error("添加数据失败,请重试");
        }
    }

    @ApiOperation("修改社区数据")
    @PostMapping("/updateCommunity")
    public Result updateCommunity(@RequestBody UpdateCommunityAccept communityAccept){
        boolean updateCommunity = communityService.updateCommunity(communityAccept);
        if(updateCommunity){
            return Result.ok().message("修改成功");
        }else{
            return Result.error("修改社区失败");
        }
    }
    @ApiOperation("查看社区信息")
    @PostMapping("/selectCommunity")
    public Result selectCommunity(){
        Map<String, Object> map = communityService.selectCommunity();
        return Result.ok().data(map);
    }
    @ApiOperation("删除社区信息")
    @PostMapping("/deleteCommunity")
    public Result deleteCommunity(@RequestBody CommunityAccept communityAccept){
        boolean b = communityService.deleteCommunity(communityAccept);
        if(b){
            return Result.ok().message("删除社区成功");
        }else{
            return Result.error("删除社区失败");
        }
    }

    @ApiOperation("加载社区大类")
    @PostMapping("/showCommunity")
    public Result showCommunity(@RequestParam("level") int level,@RequestParam("id") String id){
        if(level==0){
            List<Community> list = communityService.list();
            List<CommunityTypeAccept> communityTypeAccepts = new ArrayList<>();
            for (Community community  :list){
                CommunityTypeAccept communityTypeAccept = new CommunityTypeAccept();
                communityTypeAccept.setId(community.getId());
                communityTypeAccept.setRegionName(community.getCommunityType());
                communityTypeAccepts.add(communityTypeAccept);
            }
            return Result.ok().data(communityTypeAccepts);
        }
        if (level==1){
            List<Region> regions = showRegion(id);
            return Result.ok().data(regions);
        }
        if (level==2){
            List<Building> buildings = showBuilding(id);
            List<Region> regions= new ArrayList<>();
            for(Building building:buildings){
                Region region = new Region();
                region.setRegionName(building.getBuildingName());
                region.setId(building.getId());
                regions.add(region);
            }
            return Result.ok().data(regions);
        }
        return Result.error("数据异常");
    }

    public List<Region> showRegion(String communityId) {
        return regionService.list(new QueryWrapper<Region>().eq("community_type", communityId));
    }

    public List<Building> showBuilding(String regionId){
        return buildingService.list(new QueryWrapper<Building>().eq("region_type", regionId));
    }

}

