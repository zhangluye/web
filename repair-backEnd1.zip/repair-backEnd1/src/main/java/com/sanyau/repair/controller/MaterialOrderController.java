package com.sanyau.repair.controller;

import com.sanyau.repair.entity.MaterialOrder;
import com.sanyau.repair.mapper.MaterialOrderMapper;
import com.sanyau.repair.response.Result;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
<<<<<<< HEAD
 * @since 2021-03-23
=======
 * @since 2021-03-21
>>>>>>> origin/master
 */
@RestController
@RequestMapping("/repair/material-order")
public class MaterialOrderController {
    @Autowired
    private MaterialOrderMapper materialOrderMapper;

    @ApiOperation("选材料/返回材料列表")
    @PostMapping("materialorder.all")
    public Result getMaterialOrder(){
        List<MaterialOrder> materialOrderList = materialOrderMapper.selectList(null);
        if (materialOrderList.isEmpty()){
            return Result.error("材料列表为空");
        }
        return Result.ok().data("materialOrderList",materialOrderList);
    }
}

