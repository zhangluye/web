package com.sanyau.repair.controller;


import com.sanyau.repair.accept.AbnormalAccept;
import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IAbnormalOrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/abnormal-order")
public class AbnormalOrderController {
    @Autowired
    private IAbnormalOrderService abnormalOrderService;

    @ApiOperation("查询全部订单")
    @PostMapping("/selectAllAbnormal")
    public Result selectAllAbnormal(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                    @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                    @RequestBody AbnormalAccept abnormalAccept) {
        Map<String, Object> map = abnormalOrderService.selectAllAbnormal(current, limit, abnormalAccept);
        return Result.ok().data(map);
    }

    @ApiOperation("查询单个订单")
    @PostMapping("/selectOneAbnormal")
    public Result selectOneAbnormal(@RequestParam("orderId") String orderId){
        Map<String, Object> map = abnormalOrderService.selectOneAbnormal(orderId);
        return Result.ok().data(map);
    }
    @ApiOperation("/批量删除订单")
    @PostMapping("/deleteAbnormalOrders")
    public Result deleteAbnormalOrders(@RequestBody List<String> abnormalOrders) {
        Map<String, Object> stringObjectMap = abnormalOrderService.deleteAbnormalOrders(abnormalOrders);
        return Result.ok().data(stringObjectMap);
    }
}

