package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.*;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.OrderMapper;
import com.sanyau.repair.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.utils.IDUtils;
import com.sanyau.repair.utils.StaticCode;
import com.sun.org.apache.xpath.internal.operations.Or;
import javafx.scene.paint.Material;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.dc.pr.PRError;

import java.math.BigDecimal;
import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-21
 */
@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements IOrderService {

    @Autowired
    private IOrderService orderService;

    @Autowired
    private IMaterialOrderService materialOrderService;
    @Autowired
    private IMasterInfoService masterInfoService;
    @Autowired
    private IDetailsService detailsService;
    @Autowired
    private IBuildingService buildingService;
    @Autowired
    private IAbnormalOrderService abnormalOrderService;
    @Autowired
    private IRepositoryMaterialService repositoryMaterialService;
    @Autowired
    private IRepositoryService repositoryService;
    @Override
    public Map<String, Object> selectAllOrder(Long current, Long limit, SelectOrderAccept selectOrderAccept,Integer sate) {
        Page<Order> orderPage = new Page<>(current,limit);
        QueryWrapper<Order> queryWrapper = selectOrder(selectOrderAccept, sate);
        orderService.page(orderPage,queryWrapper.orderByDesc("order_create_time"));
        long orderTotal = orderPage.getTotal();
        List<Order> allOrders = orderPage.getRecords();//数据list集合
        List<ReturnOrderAccept> returnOrderAccepts = getReturnOrderAccepts(allOrders);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", orderTotal);
        map.put("AllOrder", returnOrderAccepts);
        map.put("AllMoney",countAllMoney());
        map.put("payMoney",countPayMoney());
        return map;
    }

    @Override
    public Map<String, Object> selectAllOrderByE() {
        List<Order> list = orderService.list();
        List<ReturnOrderAccept> returnOrderAccepts = getReturnOrderAccepts(list);
        Map<String,Object> map = new HashMap<>();
        map.put("orders",returnOrderAccepts);
        return map;
    }

    @Override
    public boolean deleteOrder(String orderId) {
        List<MaterialOrder> materialOrders = materialOrderService.list(new QueryWrapper<MaterialOrder>().eq("order_id", orderId));
        boolean order_id = true;
        if (materialOrders.size()!=0){
            order_id = materialOrderService.remove(new QueryWrapper<MaterialOrder>().eq("order_id", orderId));
        }
        if (order_id) {
            orderService.remove(new QueryWrapper<Order>().eq("order_id", orderId));
            return true;
        }
        return false;
    }

    @Override
    public Map<String, Object> selectOrderMaterial(String orderId) {
        List<MaterialOrder> materials = materialOrderService.list(new QueryWrapper<MaterialOrder>().eq("order_id", orderId));
        if(materials.size()!=0){
            for(MaterialOrder materialOrder:materials){
                Details id = detailsService.getOne(new QueryWrapper<Details>().eq("id", materialOrder.getMaterialType()));
                materialOrder.setMaterialType(id.getRepairDetails());
            }
        }
        Order order = orderService.getOne(new QueryWrapper<Order>().eq("order_id", orderId));
        ReturnMasterAccept masterAccept = new ReturnMasterAccept();
        if(order.getMasterAccount()!=null){
            masterAccept = masterInfoService.selectOneMaster(order.getMasterAccount());
        }
        ReturnOrderAccept returnOrderAccept = new ReturnOrderAccept();
        BeanUtils.copyProperties(order,returnOrderAccept);
        returnOrderAccept.setOrderState(StaticCode.ToReturnOrderState(order.getOrderState()));
        returnOrderAccept.setOrderType(StaticCode.state1ToString(order.getOrderType()));
        returnOrderAccept.setPayState(StaticCode.ToPayState(order.getPayState()));
        Building id = buildingService.getOne(new QueryWrapper<Building>().eq("id", returnOrderAccept.getUserCommunity()));
        returnOrderAccept.setUserCommunity(id.getBuildingName());
        Map<String,Object> map = new HashMap<>();
        map.put("masterAccept",masterAccept);
        map.put("materials",materials);
        map.put("order",returnOrderAccept);
        return map;
    }

    @Override
    public Map<String, Object> deleteOrders(List<String> orders) {
        int success = 0;
        int error = 0;
        if(orders.size()!=0){
            for(String order:orders){
                boolean b = orderService.deleteOrder(order);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public Map<String, Object> selectPic(String orderId) {
        String StuUrl= null;
        String MasUrl = null;
        String[] StuUrls = new String[0];
        String[] MasUrls = new String[0];
        Order order = orderService.getOne(new QueryWrapper<Order>().eq("order_id", orderId));
        StuUrl=order.getPictureUser();
        MasUrl = order.getPictureMaster();
        Map<String,Object> picMap = new HashMap<>();
        if(StuUrl!=null&&!StuUrl.equals("")){
            StuUrls = StuUrl.split(";");
        }
        if (MasUrl!=null&&!MasUrl.equals("")){
            MasUrls = MasUrl.split(";");
        }
        picMap.put("StuUrls",StuUrls);
        picMap.put("MasUrls",MasUrls);
        return picMap;
    }


    public final BigDecimal countAllMoney(){
        BigDecimal allMoney =new BigDecimal(0);
        List<Order> orders = orderService.list();
        for (Order order : orders){
            allMoney = allMoney.add(order.getOrderPrice());
        }
        return allMoney;
    }

    public final BigDecimal countPayMoney(){
        BigDecimal payMoney =new BigDecimal(0);
        List<Order> orders = orderService.list(new QueryWrapper<Order>().eq("pay_state",1));
        for (Order order : orders){
            payMoney = payMoney.add(order.getOrderPrice());
        }
        return payMoney;
    }

    public final QueryWrapper<Order> selectOrder(SelectOrderAccept selectOrderAccept, Integer state) {
        QueryWrapper<Order> queryWrapper = new QueryWrapper<Order>();
        if (state!=null&&state!=-1){
            queryWrapper.eq("order_state",state);
        }
        if(selectOrderAccept!=null){
            if(selectOrderAccept.getCreateTime()!=null){
                queryWrapper.between("order_create_time",new Date(selectOrderAccept.getCreateTime()[0]),new Date(selectOrderAccept.getCreateTime()[1]));
            }
            if(selectOrderAccept.getMasterAccount()!=null&&!selectOrderAccept.getMasterAccount().equals("")){
                queryWrapper.eq("master_account",selectOrderAccept.getMasterAccount());
            }
            if(selectOrderAccept.getOrderId()!=null&&!selectOrderAccept.getOrderId().equals("")){
                queryWrapper.eq("order_id",selectOrderAccept.getOrderId());
            }
            if(selectOrderAccept.getPayState()!=null&&!selectOrderAccept.getPayState().equals("")){
                if (selectOrderAccept.getPayState().equals("已支付")){
                    queryWrapper.eq("pay_state",1);
                }
                if(selectOrderAccept.getPayState().equals("未支付")){
                    queryWrapper.eq("pay_state",2);
                }
            }
            if(selectOrderAccept.getRepairCommunity()!=null&&!selectOrderAccept.getRepairCommunity().equals("")){
                queryWrapper.eq("user_community",selectOrderAccept.getRepairCommunity());
            }
            if(selectOrderAccept.getFinishTime()!=null){
                queryWrapper.between("order_finish_time",new Date(selectOrderAccept.getFinishTime()[0]),new Date(selectOrderAccept.getFinishTime()[1]));
            }
            if(selectOrderAccept.getRepairType()!=null&&!selectOrderAccept.getRepairType().equals("")){
                queryWrapper.eq("repair_type",selectOrderAccept.getRepairType());
            }
            if(selectOrderAccept.getStudentName()!=null&&!selectOrderAccept.getStudentName().equals("")){
                queryWrapper.eq("user_name",selectOrderAccept.getStudentName());
            }
            if (selectOrderAccept.getRoomId()!=null&&!selectOrderAccept.getRoomId().equals("")){
                queryWrapper.eq("user_apartment",selectOrderAccept.getRoomId());
            }
            if(selectOrderAccept.getOrderType()!=null&&!selectOrderAccept.getOrderType().equals("")){
                queryWrapper.eq("order_type",selectOrderAccept.getOrderType());
            }
            if(selectOrderAccept.getRoomId()!=null&&!selectOrderAccept.getRoomId().equals("")){
                queryWrapper.eq("user_apartment",selectOrderAccept.getRoomId());
            }
        }
        return queryWrapper;
    }
    @Override
    public Map<String, Object> getOrder(Long current, Long limit) {
        Page<Order> orderPage = new Page<>(current,limit);

        Page<Order> resultPage = orderService.page(orderPage, null);
        Map<String, Object> map = new HashMap<>();
        map.put("total",resultPage.getTotal());
        map.put("records",resultPage.getRecords());
        return map;
    }

    @Override
    public Map<String, Object> selectAcceptOrder(long current, long limit) {
        Page<Order> orderPage = new Page<>(current,limit);
        orderService.page(orderPage,new QueryWrapper<Order>().eq("order_state",2));
        long orderPageTotal = orderPage.getTotal();
        List<Order> records = orderPage.getRecords();//数据list集合
        List<ReturnOrderAccept> returnOrderAccepts = getReturnOrderAccepts(records);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", orderPageTotal);
        map.put("records", returnOrderAccepts);
        return map;
    }


    @Override
    public Map<String, Object> selectUnAcceptOrder(long current, Long limit) {
        Page<Order> orderPage = new Page<>(current,limit);
        orderService.page(orderPage,new QueryWrapper<Order>().eq("order_state",1));
        long orderPageTotal = orderPage.getTotal();
        List<Order> records = orderPage.getRecords();//数据list集合
        List<ReturnOrderAccept> returnOrderAccepts = getReturnOrderAccepts(records);
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", orderPageTotal);
        map.put("records", returnOrderAccepts);
        return map;
    }

    @Override
    public Order selectOrderById(String order_id) {
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.eq("order_id",order_id);
        Order order = orderService.getOne(wrapper);
        return order;
    }

    @Override
    public List<String> getAllCommunity() {
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.select("distinct user_community");
        List<String> communityList = new ArrayList<>();
        for (Order order : orderService.list(wrapper)) {
            communityList.add(order.getUserCommunity());
        }
        return communityList;
    }

    @Override
    public List<String> getAcceptCommunity() {
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.select("distinct user_community")
                .eq("order_state",1);
        List<String> communityList = new ArrayList<>();
        for (Order order : orderService.list(wrapper)) {
            communityList.add(order.getUserCommunity());
        }
        return communityList;
    }

    @Override
    public List<String> getUnAcceptCommunity() {
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.select("distinct user_community")
                .eq("order_state",2);
        List<String> communityList = new ArrayList<>();
        for (Order order : orderService.list(wrapper)) {
            communityList.add(order.getUserCommunity());
        }
        return communityList;
    }

    @Override
    public Order selectByOrderId (String orderId){
        QueryWrapper<Order> queryWrapper1 = new QueryWrapper();
        queryWrapper1.eq("order_id", orderId);
        Order repairOrder = orderService.getOne(queryWrapper1);
        return repairOrder;
    }

    @Override
    public Map<String,Object> showMasterCommunity(String account) {
        List<Building> buildings = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        Map<String,Object> map = new HashMap<>();
        map.put("community",buildings);
        return map;
    }

    @Override
    public Map<String, Object> orderScreeningToBuildingS(int id, int state) {
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        if (id==0){
            queryWrapper.eq("order_state",state);
        }
        queryWrapper.eq("user_community", id).eq("order_state",state);
        List<Order> user_community = orderService.list(queryWrapper);
        List<ReturnOrderAccept> list = getReturnOrderAccepts(user_community);
        Map<String,Object> map = new HashMap<>();
        map.put("orders",list);
        return map;
    }

    @Override
    public Map<String, Object> showMasterOrder(String account,String state) {
        List<Building> master_account = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        List<Order> order_state = orderService.list(new QueryWrapper<Order>().eq("order_state", state));
        Map<String, Object> map = getStringObjectMap(master_account, order_state);
        return map;
    }

    private Map<String, Object> getStringObjectMap(List<Building> master_account, List<Order> order_state) {
        List<Order> orderList = new ArrayList<>();
        for(Building building : master_account){
            for(Order order: order_state){
                if(order.getUserCommunity().equals(String.valueOf(building.getId()))){
                    orderList.add(order);
                    selectByOrder(order.getOrderId());
                }
            }
        }
        List<ReturnOrderAccept> returnOrderAccepts = getReturnOrderAccepts(orderList);
        Map<String,Object> map = new HashMap<>();
        map.put("orders",returnOrderAccepts);
        return map;
    }


    @Override
    public boolean cancelOrder(CancelOrderAccept cancelOrderAccept) {
        MasterInfo masterInfo = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", cancelOrderAccept.getAccount()));
        Order order = orderService.getOne(new QueryWrapper<Order>().eq("order_id", cancelOrderAccept.getOrderId()));
        if(order.getOrderState()==2){
            return false;
        }
        AbnormalOrder abnormalOrder  =new AbnormalOrder();
        abnormalOrder.setOrderId(IDUtils.getId());
        abnormalOrder.setCreateTime(order.getOrderCreateTime());
        abnormalOrder.setReturnTime(new Date());
        abnormalOrder.setReturnName(masterInfo.getAccount());
        abnormalOrder.setRequestName(order.getUserName());
        abnormalOrder.setReason(cancelOrderAccept.getReason());
        abnormalOrder.setImage("");
        abnormalOrder.setAbnType("1");
        abnormalOrder.setPictureStu(order.getPictureUser());
        abnormalOrder.setState("");
        abnormalOrder.setRequestPhone(order.getUserPhone());
        abnormalOrder.setReturnPhone(masterInfo.getMasterPhone());
        abnormalOrder.setRequestAddress(order.getUserCommunity());
        abnormalOrder.setStudentId(order.getUserId());
        abnormalOrder.setStuDesc(order.getUserDesc());
        abnormalOrderService.save(abnormalOrder);
        orderService.remove(new QueryWrapper<Order>().eq("order_id", cancelOrderAccept.getOrderId()));
        return true;
    }

    @Override
    public boolean finishOrder(FinishOrderAccept finishOrderAccept) {
        if (finishOrderAccept.getPictures().size() == 0){
            return false;
        }
        Order order = orderService.getOne(new QueryWrapper<Order>().eq("order_id", finishOrderAccept.getOrderId()));
        StringBuffer buf = new StringBuffer();
        for(String str:finishOrderAccept.getPictures()){
            buf.append(str).append(";");
        }
        order.setOrderFinishTime(new Date());
        //图片地址最后一个不放分号
        order.setPictureMaster(buf.substring(0, buf.length()-1));
        MaterialOrder materialOrder = new MaterialOrder();
        BigDecimal materialPrice = new BigDecimal(0);
        if(finishOrderAccept.getMaterialId().size()!=0){
            Repository master_account = repositoryService.getOne(new QueryWrapper<Repository>().eq("master_account", finishOrderAccept.getAccount()));
            RepositoryMaterial repositoryMaterial = new RepositoryMaterial();
            for(int i=0; i<finishOrderAccept.getMaterialId().size();i++){
                materialOrder.setOrderId(order.getOrderId());
                materialOrder.setMaterialId(finishOrderAccept.getMaterialId().get(i).getMaterialId());
                materialOrder.setMaterialName(finishOrderAccept.getMaterialId().get(i).getMaterialName());
                materialOrder.setMaterialPrice(finishOrderAccept.getMaterialId().get(i).getMaterialPrice());
                materialOrder.setMaterialCount(Integer.valueOf(String.valueOf(finishOrderAccept.getMaterialId().get(i).getMaterialAmount())));
                materialOrder.setMaterialMertic(finishOrderAccept.getMaterialId().get(i).getMaterialMetric());
                materialOrder.setMaterialBrand(finishOrderAccept.getMaterialId().get(i).getMaterialBrand());
                RepositoryMaterial repo_id = repositoryMaterialService.getOne(new QueryWrapper<RepositoryMaterial>().eq("repo_id", master_account.getRepoId()).eq("material_id",finishOrderAccept.getMaterialId().get(i).getMaterialId()));
                repositoryMaterial.setId(repo_id.getId());
                repositoryMaterial.setMaterialAmount(repo_id.getMaterialAmount()-finishOrderAccept.getMaterialId().get(i).getMaterialAmount());
                repositoryMaterialService.updateById(repositoryMaterial);
                materialOrder.setMaterialType(String.valueOf(repo_id.getMaterialType()));
                BigDecimal materialPrice1 = finishOrderAccept.getMaterialId().get(i).getMaterialPrice();
                materialPrice1 = materialPrice1.multiply(BigDecimal.valueOf(finishOrderAccept.getMaterialId().get(i).getMaterialAmount()));
                materialPrice = materialPrice.add(materialPrice1);
                materialOrder.setId(null);
                materialOrderService.save(materialOrder);
            }
            order.setOrderPrice(materialPrice);
        }
        if (finishOrderAccept.getCharge()==1){
            order.setOrderType("1");
            order.setOrderMoney(materialPrice);
        }else {
            order.setOrderType("2");
            order.setOrderMoney(BigDecimal.ZERO);
        }
        order.setOrderState(3);
        orderService.updateById(order);
        return true;
    }

    @Override
    public Map<String, Object> TaskQuery(SelectTaskQueryAccept selectTaskQueryAccept) {
        Map<String,Object> map = new HashMap<>();
        if (selectTaskQueryAccept==null){
            return map;
        }
        List<Building> buildings = buildingService.list(new QueryWrapper<Building>().eq("master_account", selectTaskQueryAccept.getAccount()));
        QueryWrapper<Order> queryWrapper = new QueryWrapper<Order>();
        showMasterOrder(selectTaskQueryAccept.getAccount(),selectTaskQueryAccept.getOrderState());
        if(selectTaskQueryAccept.getOrderState()!=null&&!selectTaskQueryAccept.getOrderState().equals("")){
            if(selectTaskQueryAccept.getOrderState().equals("2")){
                queryWrapper.eq("order_state",2);
            }
            if(selectTaskQueryAccept.getOrderState().equals("3")){
                queryWrapper.eq("order_state",3);
            }
            if(selectTaskQueryAccept.getOrderState().equals("4")){
                queryWrapper.eq("order_state",4);
            }
            if(selectTaskQueryAccept.getOrderState().equals("已完成")){
                queryWrapper.eq("order_state",4);
            }
        }
        if(selectTaskQueryAccept.getUserApartment()!=null&&!selectTaskQueryAccept.getUserApartment().equals("")){
            queryWrapper.eq("user_apartment",selectTaskQueryAccept.getUserApartment());
        }
        if(selectTaskQueryAccept.getUserCommunity()!=null&&!selectTaskQueryAccept.getUserCommunity().equals("")){
            queryWrapper.eq("user_community",selectTaskQueryAccept.getUserCommunity());
        }
        if(selectTaskQueryAccept.getUserName()!=null&&!selectTaskQueryAccept.getUserName().equals("")){
            queryWrapper.eq("user_name",selectTaskQueryAccept.getUserName());
        }
        if(selectTaskQueryAccept.getOrderCreateTimeStart()!=null&&selectTaskQueryAccept.getOrderCreateTimeEnd()!=null&&!selectTaskQueryAccept.getOrderCreateTimeEnd().equals("")&&!selectTaskQueryAccept.getOrderCreateTimeStart().equals("")){
            queryWrapper.between("order_create_time",selectTaskQueryAccept.getOrderCreateTimeStart(),selectTaskQueryAccept.getOrderCreateTimeEnd());
        }
        if(selectTaskQueryAccept.getOrderFinishTimeStart()!=null&&selectTaskQueryAccept.getOrderFinishTimeEnd()!=null&&!selectTaskQueryAccept.getOrderFinishTimeStart().equals("")&&!selectTaskQueryAccept.getOrderFinishTimeEnd().equals("")){
            queryWrapper.between("order_create_time",selectTaskQueryAccept.getOrderFinishTimeStart(),selectTaskQueryAccept.getOrderFinishTimeEnd());
        }
        if(selectTaskQueryAccept.getRepairType()!=null&&!selectTaskQueryAccept.getRepairType().equals("")){
            queryWrapper.eq("repair_type",selectTaskQueryAccept.getRepairType());
        }
        List<Order> list = orderService.list(queryWrapper);

        map = getStringObjectMap(buildings, list);
        return map;
    }

    @Override
    public Map<String, Object> showMasterRepairType(String account) {
        List<Details> details = detailsService.list(new QueryWrapper<Details>().eq("master_account", account));
        Map<String,Object> map = new HashMap<>();
        map.put("community",details);
        return map;
    }

    @Override
    public Map<String, Object> showAbnormalOrder(String account) {
        List<AbnormalOrder> return_name = abnormalOrderService.list(new QueryWrapper<AbnormalOrder>().eq("return_name", account));
        List<Building> buildings = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        List<AbnormalOrder> list = new ArrayList<>();
        for(int i=0;i<return_name.size();i++){
            for(int j=0;j<buildings.size();j++){
                if (return_name.get(i).getRequestAddress().equals(String.valueOf(buildings.get(j).getId()))){
                    AbnormalOrder abnormalOrder = new AbnormalOrder();
                    BeanUtils.copyProperties(return_name.get(i),abnormalOrder);
                    abnormalOrder.setAbnType(StaticCode.state1ToString2(return_name.get(i).getAbnType()));
                    abnormalOrder.setState(StaticCode.state1ToString2(return_name.get(i).getState()));
                    list.add(abnormalOrder);
                }
            }
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("abnormal", list);
        return map;
    }

    @Override
    public Map<String, Object> showAbnormalOrderByBuilding(String account, String community) {
        List<Building> buildings = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        List<AbnormalOrder> return_name = abnormalOrderService.list(new QueryWrapper<AbnormalOrder>().eq("return_name", account));
        List<AbnormalOrder> list = new ArrayList<>();
        for(int i=0;i<buildings.size();i++){
            for(int j=0;j<return_name.size();j++){
                if(return_name.get(j).getRequestAddress().equals(String.valueOf(buildings.get(i).getId()))){
                    AbnormalOrder abnormalOrder = new AbnormalOrder();
                    BeanUtils.copyProperties(return_name.get(j),abnormalOrder);
                    abnormalOrder.setAbnType(StaticCode.state1ToString2(return_name.get(j).getAbnType()));
                    abnormalOrder.setState(StaticCode.state1ToString2(return_name.get(j).getState()));
                    list.add(abnormalOrder);
                }
            }
        }
        List<AbnormalOrder> abnormalOrders = new ArrayList<>();
        if (community!=null&&!community.equals("")){
            for(AbnormalOrder abnormalOrder : list){
                if(abnormalOrder.getRequestAddress().equals(community)){
                    abnormalOrders.add(abnormalOrder);
                }
            }
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("abnormal", abnormalOrders);
        return map;
    }

    @Override
    public Map<String, Object> showOneAbnormalOrder(String orderId) {
        Map<String, Object> map = abnormalOrderService.selectOneAbnormal(orderId);
        return map;
    }

    @Override
    public Map<String, Object> selectByOrder(String orderId) {
        Map<String,Object> map = new HashMap<>();
        List<MaterialOrder> order_id = materialOrderService.list(new QueryWrapper<MaterialOrder>().eq("order_id", orderId));
        if(order_id==null){
            return map;
        }
        if(order_id.size()==0){
            return map;
        }
        for(MaterialOrder materialOrder:order_id){
            Details id = detailsService.getOne(new QueryWrapper<Details>().eq("id", materialOrder.getMaterialType()));
            materialOrder.setMaterialType(id.getRepairDetails());
        }
        map.put("materialOrder",order_id);
        return map;
    }

    /**
     *  将订单中的数字转换成字符串
     * @param user_community
     * @return
     */
    private List<ReturnOrderAccept> getReturnOrderAccepts(List<Order> user_community) {
        List<ReturnOrderAccept> list = new ArrayList<>();
        for(int i = 0; i< user_community.size(); i++){
            ReturnOrderAccept returnOrderAccept = new ReturnOrderAccept();
            BeanUtils.copyProperties(user_community.get(i),returnOrderAccept);
            returnOrderAccept.setOrderState(StaticCode.ToReturnOrderState(user_community.get(i).getOrderState()));
            Details details = detailsService.getOne(new QueryWrapper<Details>().eq("id", user_community.get(i).getRepairType()));
            returnOrderAccept.setRepairType(details.getRepairDetails());
            Building community = buildingService.getOne(new QueryWrapper<Building>().eq("id", user_community.get(i).getUserCommunity()));
            returnOrderAccept.setUserCommunity(community.getBuildingName());
            returnOrderAccept.setPayState(StaticCode.ToPayState(user_community.get(i).getPayState()));
            returnOrderAccept.setOrderType(StaticCode.state1ToString(user_community.get(i).getOrderType()));
            list.add(returnOrderAccept);
        }
        return list;
    }

}
