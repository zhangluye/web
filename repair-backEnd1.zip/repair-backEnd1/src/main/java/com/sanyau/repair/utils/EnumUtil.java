package com.sanyau.repair.utils;

public class EnumUtil {
    public static String getOrderState(Integer state){
        if(state==1){
            return "未接工单";
        }
        if(state==2){
            return "已接工单";
        }
        if(state==3){
            return "待评价工单";
        }
        if(state==4) {
            return "已完成工单";
        }
        return "";
    }

    public static String getOrderType(Integer orderType){
        if(orderType==1){
            return "收费订单";
        }
        if(orderType==2){
            return "不收费订单";
        }
        return "";
    }

    public static String getAbnormalOrder(Integer state){
        if(state==1){
            return "退回";
        }
        if(state==2){
            return "取消";
        }
        return "";
    }

    public static String getReturnOrderState(Integer state){
        if(state==1){
            return "正在出库";
        }
        if(state==2){
            return "拒绝出库";
        }
        if(state==3){
            return "完成出库";
        }
        return "";
    }

    public static String getDeliverOrderState(Integer state){
        if(state==1){
            return "正在返库";
        }
        if(state==2){
            return "拒绝返库";
        }
        if(state==3){
            return "完成返库";
        }
        return "";
    }
}
