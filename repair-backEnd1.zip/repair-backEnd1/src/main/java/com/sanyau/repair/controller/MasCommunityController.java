package com.sanyau.repair.controller;


import com.sanyau.repair.entity.Community;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.ICommunityService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/community")
public class MasCommunityController {
    @Autowired
    private ICommunityService iCommunityService;

    @ApiOperation(value = "展示社区")
    @RequestMapping(value = "/showCommunity",method = RequestMethod.GET)
    @ResponseBody
    public Result showCommunity(){
        List<Community> communities = iCommunityService.list();
        return Result.ok().data("所有社区", communities);
    }
}

