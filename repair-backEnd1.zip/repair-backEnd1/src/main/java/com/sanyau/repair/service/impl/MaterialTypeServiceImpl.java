package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.MaterialTypeAccept;
import com.sanyau.repair.accept.UpdateMaterialTypeAccept;
import com.sanyau.repair.entity.MaterialGroup;
import com.sanyau.repair.entity.MaterialType;
import com.sanyau.repair.mapper.MaterialTypeMapper;
import com.sanyau.repair.service.IMaterialGroupService;
import com.sanyau.repair.service.IMaterialTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import javafx.scene.paint.Material;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class
MaterialTypeServiceImpl extends ServiceImpl<MaterialTypeMapper, MaterialType> implements IMaterialTypeService {
    @Autowired
    private IMaterialTypeService materialTypeService;

    @Autowired
    private IMaterialGroupService materialGroupService;
    @Override
    public boolean insertMaterialType(MaterialTypeAccept materialTypeAccept) {
        MaterialType material_type = materialTypeService.getOne(new QueryWrapper<MaterialType>().eq("material_type", materialTypeAccept.getMaterialType()));
        MaterialGroup material_group_name = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("material_group_name", materialTypeAccept.getMaterialGroup()));
        MaterialType materialType = new MaterialType();
        MaterialGroup materialGroup =new MaterialGroup();
        if(material_type==null&&materialTypeAccept.getMaterialType()!=null){
            materialType.setMaterialType(materialTypeAccept.getMaterialType());
            materialTypeService.save(materialType);
        }
        if(materialType.getId()!=null&&material_group_name==null&&materialTypeAccept.getMaterialGroup()!=null){
            materialGroup.setMaterialGroupName(materialTypeAccept.getMaterialGroup());
            materialGroup.setMaterialType(materialType.getId());
            materialGroupService.save(materialGroup);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean deleteMaterialType(MaterialTypeAccept materialTypeAccept) {
        MaterialType material_type = materialTypeService.getOne(new QueryWrapper<MaterialType>().eq("material_type", materialTypeAccept.getMaterialType()));
        if(materialTypeAccept.getMaterialGroup()==null&&materialTypeAccept.getMaterialType()!=null){
            List<MaterialGroup> material_type1 = materialGroupService.list(new QueryWrapper<MaterialGroup>().eq("material_type", material_type.getId()));
            if(material_type1.size() != 0){
                return false;
            }else {
                materialTypeService.removeById(material_type.getId());
            }
        }else if(materialTypeAccept.getMaterialType()==null){
            MaterialGroup material_group_name = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("material_group_name", materialTypeAccept.getMaterialGroup()));
            materialGroupService.removeById(material_group_name.getId());
        }else {
            return false;
        }
        return true;
    }

    @Override
    public Map<String, Object> selectMaterialType() {
        List<MaterialType> materialTypes = materialTypeService.list();
        Map<String,Object> map = new HashMap<>();
        for (MaterialType materialType : materialTypes) {
            List<MaterialGroup> material_type = materialGroupService.list(new QueryWrapper<MaterialGroup>().eq("material_type", materialType.getId()));
            map.put(materialType.getMaterialType(), material_type);
        }
        return map;
    }

    @Override
    public boolean updateMaterialType(UpdateMaterialTypeAccept materialAccept) {
        MaterialType material_type = materialTypeService.getOne(new QueryWrapper<MaterialType>().eq("id", materialAccept.getMaterialTypeId()));
        MaterialGroup material_group_name = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("id", materialAccept.getMaterialGroupId()));
        if(material_type!=null){
            material_type.setMaterialType(materialAccept.getMaterialType());
            materialTypeService.updateById(material_type);
        }
        if(material_group_name!=null){
            material_group_name.setMaterialGroupName(materialAccept.getMaterialGroup());
            material_group_name.setMaterialType(material_type.getId());
            materialGroupService.updateById(material_group_name);
        }
        if(material_group_name==null&&material_type==null){
            return false;
        }
        return true;
    }
}
