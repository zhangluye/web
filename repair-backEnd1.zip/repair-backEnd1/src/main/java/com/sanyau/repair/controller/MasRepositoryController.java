package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.MasterInfo;
import com.sanyau.repair.entity.Repository;
import com.sanyau.repair.entity.RepositoryMaterial;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IRepositoryMaterialService;
import com.sanyau.repair.service.IRepositoryService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/repository")
public class MasRepositoryController {

    @Autowired
    public IRepositoryService iRepositoryService;
    @Autowired
    public IRepositoryMaterialService iRepositoryMaterialService;

    @ApiOperation(value = "展示师傅仓库信息")
    @PostMapping("showInfo")
    public Result showInfo(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        QueryWrapper<Repository> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("master_account", account);
        Repository repository = iRepositoryService.getOne(queryWrapper1);

        if(repository == null){
            return Result.error("您的仓库还未配置，请等待仓库配置完成");
        }
        String repoId = repository.getRepoId();

        QueryWrapper<RepositoryMaterial> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("repo_id", repoId);
        List<RepositoryMaterial> repositoryMaterials = iRepositoryMaterialService.list(queryWrapper2);
        List<RepositoryMaterial> repositoryMaterialList = new ArrayList<>();
        for(RepositoryMaterial repositoryMaterial:repositoryMaterials){
            if (repositoryMaterial.getMaterialAmount() !=Long.parseLong("0")){
                repositoryMaterialList.add(repositoryMaterial);
            }
        }
        return Result.ok().data("师傅个人仓库材料数据", repositoryMaterialList);
    }

    @ApiOperation(value = "按类型筛选师傅仓库信息")
    @PostMapping("selectTypeInfo")
    public Result showTypeInfo(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        Integer Type = jsonObject.getInteger("type");
        QueryWrapper<Repository> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("master_account", account);
        Repository repository = iRepositoryService.getOne(queryWrapper1);

        if(repository == null){
            return Result.error("您的仓库还未配置，请等待仓库配置完成");
        }
        String repoId = repository.getRepoId();

        QueryWrapper<RepositoryMaterial> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("repo_id", repoId);
        queryWrapper2.eq("material_type", Type);
        List<RepositoryMaterial> repositoryMaterials = iRepositoryMaterialService.list(queryWrapper2);

        return Result.ok().data("师傅个人仓库材料数据", repositoryMaterials);
    }

    @ApiOperation(value = "按材料名筛选师傅仓库信息")
    @PostMapping("selectNameInfo")
    public Result showLikeInfo(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        String Name = jsonObject.getString("name");
        QueryWrapper<Repository> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("master_account", account);
        Repository repository = iRepositoryService.getOne(queryWrapper1);

        if(repository == null){
            return Result.error("您的仓库还未配置，请等待仓库配置完成");
        }
        String repoId = repository.getRepoId();

        QueryWrapper<RepositoryMaterial> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("repo_id", repoId);
        queryWrapper2.like("material_name", Name);
        List<RepositoryMaterial> repositoryMaterials = iRepositoryMaterialService.list(queryWrapper2);
        repositoryMaterials.removeIf(repositoryMaterial -> repositoryMaterial.getMaterialAmount() == 0);
        return Result.ok().data("师傅个人仓库材料数据", repositoryMaterials);
    }
}

