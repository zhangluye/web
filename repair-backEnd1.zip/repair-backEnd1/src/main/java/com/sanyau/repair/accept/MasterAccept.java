package com.sanyau.repair.accept;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Data
public class MasterAccept {
    @ApiModelProperty(value = "师傅姓名")
    private String masterName;

    @ApiModelProperty(value = "师傅手机号")
    private String masterPhone;

    @ApiModelProperty(value = "师傅维修类型")
    private List<String> masterRepairType;

    @ApiModelProperty(value = "师傅维修区域")
    private List<String> masterCommunity;

    private String account;

    private String password;
}
