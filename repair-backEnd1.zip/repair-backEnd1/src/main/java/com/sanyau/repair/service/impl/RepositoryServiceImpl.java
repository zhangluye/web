package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.ReturnMasterAccept;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.Repository;
import com.sanyau.repair.entity.RepositoryMaterial;
import com.sanyau.repair.mapper.RepositoryMapper;
import com.sanyau.repair.service.IMasterInfoService;
import com.sanyau.repair.service.IRepositoryMaterialService;
import com.sanyau.repair.service.IRepositoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-23
 */
@Service
public class RepositoryServiceImpl extends ServiceImpl<RepositoryMapper, Repository> implements IRepositoryService {

    @Autowired
    private IRepositoryService repositoryService;

    @Autowired
    private IRepositoryMaterialService repositoryMaterialService;

    @Autowired
    private IMasterInfoService masterInfoService;
    @Override
    public Map<String, Object> selectAllRepository(Long current,Long limit,String repoId) {
        Page<Repository> repositoryPage = new Page<>(current,limit);
        QueryWrapper<Repository> queryWrapper = new QueryWrapper<>();
        if(repoId!=null&&!repoId.equals("")){
            queryWrapper.eq("repo_id",repoId);
        }
        repositoryService.page(repositoryPage,queryWrapper.orderByDesc("create_time"));
        long adminTotal = repositoryPage.getTotal();
        List<Repository> records = repositoryPage.getRecords();//数据list集合
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", adminTotal);
        map.put("admins", records);
        return map;
    }

    @Override
    public Map<String, Object> selectOneRepository(String repoId) {
        Repository repository = repositoryService.getOne(new QueryWrapper<Repository>().eq("repo_id", repoId));
        List<RepositoryMaterial> repositoryMaterials = repositoryMaterialService.list(new QueryWrapper<RepositoryMaterial>().eq("repo_id", repoId));
        ReturnMasterAccept masterAccept = masterInfoService.selectOneMaster(repository.getMasterAccount());
        Map<String,Object> map = new HashMap<>();
        map.put("repository",repository);
        map.put("repositoryMaterials",repositoryMaterials);
        map.put("masterAccept",masterAccept);
        return map;
    }
}
