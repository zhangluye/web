package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class CancelOrderAccept {

    private String orderId;
    private String account;
    private String reason;
}
