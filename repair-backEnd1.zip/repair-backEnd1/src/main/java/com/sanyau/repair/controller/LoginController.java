package com.sanyau.repair.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.AdminLoginParam;
import com.sanyau.repair.accept.ReturnLoginAccept;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.AdminRole;
import com.sanyau.repair.entity.Role;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.impl.AdminRoleServiceImpl;
import com.sanyau.repair.service.impl.AdminServiceImpl;
import com.sanyau.repair.service.impl.RoleServiceImpl;
import com.sanyau.repair.utils.JwtUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;

@RestController
//@RequestMapping("/prod-api")
@Api(tags = "LoginController")
public class LoginController {
    @Autowired
    private AdminServiceImpl adminService;

    @Autowired
    private AdminRoleServiceImpl adminRoleService;

    @Autowired
    private RoleServiceImpl roleService;
    @ApiOperation(value = "登录之后返回token")
    @PostMapping("/login")
    public Result login(@RequestBody AdminLoginParam adminLoginParam, HttpServletRequest request) {
        return adminService.login(adminLoginParam.getAccount(), adminLoginParam.getPassword(), request);
    }


    @ApiOperation(value = "获取当前用户信息")
    @GetMapping("/info")
    public Result getAdminInfo(HttpServletRequest request, @RequestParam("token") String token) {
        HashMap<String, String> map;
        try {
            map = JwtUtils.getMapByJwtToken(request);
        } catch (Exception e) {
            return Result.error("token校验失败！");
        }
        String username = map.get("username");
        Admin admin = adminService.getAdminByUserName(username);
        AdminRole adminRole = adminRoleService.getOne(new QueryWrapper<AdminRole>().eq("user_id", admin.getId()));
        Role role = roleService.getOne(new QueryWrapper<Role>().eq("id", adminRole.getRoleId()));
        ReturnLoginAccept loginAccept = new ReturnLoginAccept();
        loginAccept.setRoles(new String[]{role.getCode()});
        BeanUtils.copyProperties(admin,loginAccept);
        return Result.ok().data(loginAccept);
    }



    @ApiOperation(value = "退出登录")
    @PostMapping("/logout")
    public Result logout() {
        return Result.ok().data("success","注销成功！");
    }


}
