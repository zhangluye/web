package com.sanyau.repair.utils.qiniuyun;

public class VariableNames {
    //七牛AK
    public static final String accessKey = "S7HhzhFoM6Keyrc8irGTXIKdWvspWsHWV-39d2mL";
    //七牛SK
    public static final String secretKey ="AC8IpiEN9tgmmfEb0TCLMi90U5cL5D6HdMgqewaD";
    //七牛的云存储空间名
    public static final String bucket ="repairs";
    //对外访问的域名
    public static final String pubdomain ="http://cdn.sx66888.cn/";

}
