package com.sanyau.repair.mapper;

import com.sanyau.repair.entity.Type;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
public interface TypeMapper extends BaseMapper<Type> {

}
