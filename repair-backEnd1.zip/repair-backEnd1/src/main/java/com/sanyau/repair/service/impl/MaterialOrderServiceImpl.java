package com.sanyau.repair.service.impl;

import com.sanyau.repair.entity.MaterialOrder;
import com.sanyau.repair.mapper.MaterialOrderMapper;
import com.sanyau.repair.service.IMaterialOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-21
 */
@Service
public class MaterialOrderServiceImpl extends ServiceImpl<MaterialOrderMapper, MaterialOrder> implements IMaterialOrderService {

}
