package com.sanyau.repair.service;

import com.sanyau.repair.accept.SelectWorkersAccept;
import com.sanyau.repair.accept.UpdateWorkersAccept;
import com.sanyau.repair.entity.WorkersInfo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IWorkersInfoService extends IService<WorkersInfo> {

    boolean updateWorkers(UpdateWorkersAccept updateWorkersAccept);

    boolean deleteWorkers(Integer id);

    Map<String,Object> selectWorkers(Long current,Long limit, SelectWorkersAccept selectWorkersAccept);

    Map<String, Object> deleteWorkersTo(List<Integer> workers);

}
