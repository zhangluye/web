package com.sanyau.repair.service;

import com.sanyau.repair.accept.AbnormalAccept;
import com.sanyau.repair.accept.SelectOrderAccept;
import com.sanyau.repair.entity.AbnormalOrder;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IAbnormalOrderService extends IService<AbnormalOrder> {
    /**
     *查看全部异常订单
     */
    Map<String,Object> selectAllAbnormal(Long current, Long limit, AbnormalAccept abnormalAccept);

    /**
     * 查询单个异常订单
     */
    Map<String,Object> selectOneAbnormal(String orderId);

    /**
     * 批量删除订单
     *
     * @param abnormalOrders
     * @return
     */
    Map<String, Object> deleteAbnormalOrders(List<String> abnormalOrders);

    /**
     * 删除单个订单
     */
    boolean deleteAbnormalOrder(String id);
}
