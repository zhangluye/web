package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.MaterialAccept;
import com.sanyau.repair.accept.ReturnMaterialAccept;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.MaterialInfoMapper;
import com.sanyau.repair.service.IAddMaterialInfoService;
import com.sanyau.repair.service.IAddMaterialOrderService;
import com.sanyau.repair.service.IMaterialGroupService;
import com.sanyau.repair.service.IMaterialInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.utils.IDUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class MaterialInfoServiceImpl extends ServiceImpl<MaterialInfoMapper, MaterialInfo> implements IMaterialInfoService {
    @Autowired
    private IMaterialInfoService materialInfoService;

    @Autowired
    private IMaterialGroupService materialGroupService;

    @Autowired
    private IAddMaterialInfoService addMaterialInfoService;

    @Autowired
    private IAddMaterialOrderService addMaterialOrderService;

    @Override
    public Map<String, Object> selectMaterial(Long current,Long limit,String materialId) {
        Page<MaterialInfo> materialInfoPage = new Page<>(current,limit);
        materialInfoService.page(materialInfoPage,selectMaterials(materialId));
        long materialTotal = materialInfoPage.getTotal();
        List<MaterialInfo> records = materialInfoPage.getRecords();
        List<ReturnMaterialAccept> list = new ArrayList<>();
        for(int i=0;i<records.size();i++){
            ReturnMaterialAccept returnMaterialAccept = new ReturnMaterialAccept();
            BeanUtils.copyProperties(records.get(i),returnMaterialAccept);
            MaterialGroup id = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("id", records.get(i).getMaterialType()));
            returnMaterialAccept.setMaterialType(id.getMaterialGroupName());
            list.add(returnMaterialAccept);
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", materialTotal);
        map.put("material", list);
        return map;
    }

    @Override
    public boolean updateMaterial(MaterialInfo materialInfo) {
        return materialInfoService.update(materialInfo,new QueryWrapper<MaterialInfo>().eq("material_id", materialInfo.getMaterialId()));
    }

    @Override
    public boolean insertMaterial(List<MaterialAccept> materialAccepts) {
        List<AddMaterialInfo> materialInfos = new ArrayList<>();
        Long count = 0L;
        String account = null;
        for (MaterialAccept materialAccept:materialAccepts) {
            MaterialInfo materialInfo = new MaterialInfo();
            BeanUtils.copyProperties(materialAccept,materialInfo);
            materialInfo.setMaterialId(IDUtils.getId());
            materialInfo.setCreateTime(new Date());
            materialInfo.setMaterialType(materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("material_group_name",materialAccept.getMaterialType())).getId());
            //获取用户信息
            materialInfo.setMaterialTotal(materialAccept.getMaterialTotal());
            materialInfo.setAddPeople(SecurityContextHolder.getContext().getAuthentication().getName());
            materialInfo.setMaterialDeliveryAmount(0L);
            materialInfo.setMaterialReturnAmount(0L);
            materialInfos.add(new AddMaterialInfo(null,
                    materialInfo.getMaterialId(),
                    materialInfo.getMaterialName(),
                    materialInfo.getMaterialTotal(),
                    materialInfo.getMaterialMetric(),
                    materialInfo.getMaterialType(),
                    materialInfo.getMaterialPrice(),
                    materialInfo.getMaterialBrand(),
                    materialInfo.getAddPeople()));
            count+=materialAccept.getMaterialTotal();
            account = materialInfo.getAddPeople();
            materialInfoService.save(materialInfo);
        }
        addMaterialOrderService.save(new AddMaterialOrder(null,IDUtils.getId(),new Date(),count,account));
        addMaterialInfoService.saveBatch(materialInfos);
        return true;
    }

    @Override
    public boolean deleteMaterial(String materialId) {
        MaterialInfo material_id = materialInfoService.getOne(new QueryWrapper<MaterialInfo>().eq("id", materialId));
        if (material_id==null){
            return false;
        }else {
            materialInfoService.remove(new QueryWrapper<MaterialInfo>().eq("id", materialId));
            return true;
        }
    }

    @Override
    public Map<String, Object> deleteMaterials(List<String> materialInfos) {
        int success = 0;
        int error = 0;
        if(materialInfos.size()!=0){
            for(String materialInfo:materialInfos){
                boolean b = materialInfoService.deleteMaterial(materialInfo);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public Map<String, Object> selectAllMaterial() {
        List<MaterialInfo> materialInfos = materialInfoService.list();
        List<ReturnMaterialAccept> list = new ArrayList<>();
        for(int i=0;i<materialInfos.size();i++){
            ReturnMaterialAccept returnMaterialAccept = new ReturnMaterialAccept();
            BeanUtils.copyProperties(materialInfos.get(i),returnMaterialAccept);
            MaterialGroup id = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("id", materialInfos.get(i).getMaterialType()));
            returnMaterialAccept.setMaterialType(id.getMaterialGroupName());
            list.add(returnMaterialAccept);
        }
        Map<String,Object> map = new HashMap<>();
        map.put("materials",list);
        return map;
    }

    public QueryWrapper<MaterialInfo> selectMaterials(String id){
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<MaterialInfo>();
        if (id!=null&&!id.equals("")&&!id.equals("null")){
            queryWrapper.eq("material_id",id);
            return queryWrapper;
        }
        return null;
    }
}
