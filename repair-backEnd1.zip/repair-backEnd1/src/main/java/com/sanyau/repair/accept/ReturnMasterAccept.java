package com.sanyau.repair.accept;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;


@Data
public class ReturnMasterAccept {

    @ApiModelProperty(value = "师傅姓名")
    private String masterName;

    @ApiModelProperty(value = "师傅手机号")
    private String masterPhone;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "师傅维修类型")
    private List<String> masterRepairType;

    @ApiModelProperty(value = "师傅维修区域")
    private List<String> masterCommunity;

    @ApiModelProperty(value = "师傅仓库号")
    private String masterRepository;

    private String account;

    private String password;
}
