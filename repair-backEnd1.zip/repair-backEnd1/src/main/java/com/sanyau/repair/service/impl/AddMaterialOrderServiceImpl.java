package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.AddMaterialOrderMapper;
import com.sanyau.repair.service.IAddMaterialInfoService;
import com.sanyau.repair.service.IAddMaterialOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.service.IMaterialGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class AddMaterialOrderServiceImpl extends ServiceImpl<AddMaterialOrderMapper, AddMaterialOrder> implements IAddMaterialOrderService {

    @Autowired
    private IAddMaterialOrderService addMaterialOrder;
    @Autowired
    private IAddMaterialInfoService addMaterialInfoService;
    @Autowired
    private IMaterialGroupService materialGroupService;

    @Override
    public Map<String,Object> selectAddMaterialOrder(Long current, Long limit,String orderId,String materialId) {
        Page<AddMaterialOrder> addMaterialOrderPage = new Page<>(current,limit);
        QueryWrapper<AddMaterialOrder> queryWrapper = new QueryWrapper<AddMaterialOrder>();
        queryWrapper.orderByDesc("create_time");
        if (orderId!=null&&!orderId.equals("")&&!orderId.equals("null")){
            queryWrapper.eq("add_material_order_id",orderId);
        }
        if(materialId!=null&&!materialId.equals("")&&!materialId.equals("null")){
            AddMaterialInfo add_material_id = addMaterialInfoService.getOne(new QueryWrapper<AddMaterialInfo>().eq("add_material_id", materialId));
            queryWrapper.eq("add_material_order_id",add_material_id.getAddMaterialInfoOrderId());
        }
        addMaterialOrder.page(addMaterialOrderPage,queryWrapper);
        long addMaterialOrderPageTotal = addMaterialOrderPage.getTotal();
        List<AddMaterialOrder> records = addMaterialOrderPage.getRecords();//数据list集合
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", addMaterialOrderPageTotal);
        map.put("addMaterialOrders", records);
        return map;
    }

    @Override
    public Map<String,Object> selectAddMaterialInfo(String addMaterialOrderId) {
        List<AddMaterialInfo> add_material_info_order_id = addMaterialInfoService.list(new QueryWrapper<AddMaterialInfo>().eq("add_material_info_order_id", addMaterialOrderId));
        List<AddMaterialInfo> addMaterialInfos = new ArrayList<>();
        for(AddMaterialInfo addMaterialInfo:add_material_info_order_id){
            MaterialGroup id = materialGroupService.getOne(new QueryWrapper<MaterialGroup>().eq("id", addMaterialInfo.getAddMaterialType()));
            addMaterialInfo.setAddMaterialType(id.getMaterialGroupName());
            addMaterialInfos.add(addMaterialInfo);
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("addMaterials", addMaterialInfos);
        return map;
    }

    @Override
    public boolean deleteMaterialOrder(String addMaterialOrderId) {
        boolean add_material_order_id = addMaterialOrder.remove(new QueryWrapper<AddMaterialOrder>().eq("add_material_order_id", addMaterialOrderId));
        boolean add_material_info_order_id = addMaterialInfoService.remove(new QueryWrapper<AddMaterialInfo>().eq("add_material_info_order_id", add_material_order_id));
        if(add_material_info_order_id&&add_material_order_id){
            return true;
        }
        return false;
    }

    @Override
    public Map<String, Object> deleteMaterialOrders(List<String> addMaterialOrders) {
        int success = 0;
        int error = 0;
        if(addMaterialOrders.size()!=0){
            for(String addMaterialOrder:addMaterialOrders){
                boolean b = deleteMaterialOrder(addMaterialOrder);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }
}
