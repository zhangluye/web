package com.sanyau.repair.service;

import com.sanyau.repair.accept.InsertDeliveryOrderAccept;
import com.sanyau.repair.accept.SelectDeliveryOrderAccept;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.DeliveryMaterialInfo;
import com.sanyau.repair.entity.DeliveryOrder;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IDeliveryOrderService extends IService<DeliveryOrder> {

    /**
     * 查看全部出库申请订单
     * @return
     */
    Map<String, Object> selectAllDeliveryOrder(Long current, Long limit,SelectDeliveryOrderAccept selectDeliveryOrderAccept);

    /**
     * 审批订单是否同意出库
     * @param opinion
     * @return
     */
    boolean updateDeliveryOrder(String orderId,String opinion);

    /**
     * 删除订单
     * @param DeliveryOrderId
     * @return
     */
    boolean deleteDeliveryOrder(String deliveryOrderId);

    /**
     * 查看订单材料
     */
    Map<String,Object> selectMaterial(String orderId);

    /**
     * 批量删除订单信息
     * @param deliveryOrders
     * @return
     */
    Map<String, Object> deleteDeliveryOrders(List<String> deliveryOrders);
    /**
     * 师傅端出库订单
     */
    boolean insertDeliverOrder(InsertDeliveryOrderAccept insertDeliveryOrderAccept);

}
