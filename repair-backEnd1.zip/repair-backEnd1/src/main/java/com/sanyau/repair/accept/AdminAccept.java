package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class AdminAccept {

    private String account;

    private String password;

    private String mobile;

    private String department;

    private String name;

    private String role;
}
