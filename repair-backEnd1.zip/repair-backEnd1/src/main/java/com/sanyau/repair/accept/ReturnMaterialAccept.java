package com.sanyau.repair.accept;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class ReturnMaterialAccept {
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty(value = "材料ID")
    private String materialId;

    @ApiModelProperty(value = "材料名")
    private String materialName;

    @ApiModelProperty(value = "材料总数量")
    private Long materialTotal;

    @ApiModelProperty(value = "单位")
    private String materialMetric;

    @ApiModelProperty(value = "材料价格")
    private BigDecimal materialPrice;

    @ApiModelProperty(value = "材料品牌")
    private String materialBrand;

    @ApiModelProperty(value = "材料类型")
    private String materialType;

    private String remarks;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "添加人")
    private String addPeople;

    @ApiModelProperty(value = "材料出库数量")
    private Long materialDeliveryAmount;

    @ApiModelProperty(value = "材料返库数量")
    private Long materialReturnAmount;
}
