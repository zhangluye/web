package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class SelectManyAccept {

    private String account;

    private String department;

    private String name;

    private String mobile;
}
