package com.sanyau.repair.controller;


import com.sanyau.repair.entity.AddMaterialOrder;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IAddMaterialOrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/add-material-order")
public class AddMaterialOrderController {
    @Autowired
    private IAddMaterialOrderService addMaterialOrderService;

    @ApiOperation("查看全部添加材料订单")
    @PostMapping("/selectAddMaterialOrder")
    public Result selectAddMaterialOrder(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                         @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                         @RequestParam("orderId") String orderId, @RequestParam("materialId") String materialId) {
        Map<String, Object> map = addMaterialOrderService.selectAddMaterialOrder(current, limit, orderId, materialId);
        System.out.println(orderId+"来了老弟"+materialId);
        return Result.ok().data(map);
    }

    @ApiOperation("查看订单对应材料")
    @PostMapping("/selectAddMaterial")
    public Result selectAddMaterial(@RequestParam("addMaterialOrderId") String addMaterialOrderId) {
        Map<String, Object> map = addMaterialOrderService.selectAddMaterialInfo(addMaterialOrderId);
        return Result.ok().data(map);
    }

    @ApiOperation("删除订单")
    @PostMapping("/deleteAddMaterial")
    public Result deleteAddMaterial(@RequestParam("addMaterialOrderId") String addMaterialOrderId){
        boolean b = addMaterialOrderService.deleteMaterialOrder(addMaterialOrderId);
        if (b){
            return Result.ok().message("删除订单成功");
        }else {
            return Result.error("删除订单失败");
        }
    }

    @ApiOperation("批量删除")
    @PostMapping("/deleteAddMaterials")
    public Result deleteAddMaterials(@RequestBody List<String> orders){
        Map<String, Object> map = addMaterialOrderService.deleteMaterialOrders(orders);
        return Result.ok().data(map);
    }
}

