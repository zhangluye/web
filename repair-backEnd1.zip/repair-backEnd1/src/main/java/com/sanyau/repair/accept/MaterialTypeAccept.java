package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class MaterialTypeAccept {

    private String materialType;

    private String materialGroup;
}
