package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mysql.jdbc.StringUtils;
import com.sanyau.repair.accept.SelectStudentAccept;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.entity.StudentInfo;
import com.sanyau.repair.mapper.StudentInfoMapper;
import com.sanyau.repair.response.HttpRequest;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.impl.StudentInfoServiceImpl;
import com.sanyau.repair.utils.HttpUtils;
import com.sanyau.repair.utils.JwtUtils;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import jdk.nashorn.internal.parser.Token;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.ibatis.executor.BaseExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/repair/student-info")
public class StudentInfoController {

    @Autowired
    StudentInfoServiceImpl studentInfoService;


    @Autowired
    StudentInfoMapper studentInfoMapper;

    @ApiOperation("查询全部学生信息后台")
    @PostMapping("/selectAllStudent")
    public Result selectAllStudents(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                    @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                    @RequestBody SelectStudentAccept selectStudentAccept){
        Map<String, Object> map = studentInfoService.selectStudent(current, limit, selectStudentAccept);
        return Result.ok().data(map);
    }

    @ApiOperation("修改学生信息后台")
    @PostMapping("/updateStudent")
    public Result updateStudent(@RequestParam("id")int id,@RequestBody SelectStudentAccept selectStudentAccept){
        boolean b = studentInfoService.updateStudent(id, selectStudentAccept);
        if (b){
            return Result.ok().data("修改学生信息成功");
        }else {
            return Result.error("修改学生信息失败");
        }
    }

    @ApiOperation("批量删除学生信息后台")
    @PostMapping("/deleteStudents")
    public Result deleteStudents(@RequestBody List<Integer> ids){
        Map<String, Object> map = studentInfoService.deleteStudents(ids);
        return Result.ok().data(map);
    }

}

