package com.sanyau.repair.controller;


import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IRepositoryService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-23
 */
@RestController
@RequestMapping("/repair/repository")
public class RepositoryController {
    @Autowired
    private IRepositoryService repositoryService;

    @ApiOperation("查看全部仓库")
    @PostMapping("/selectAllRepository")
    public Result selectAllRepository(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                      @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                      @RequestParam("repoId") String repoId){
        Map<String, Object> map = repositoryService.selectAllRepository(current, limit, repoId);
        return Result.ok().data(map);
    }

    @ApiOperation("查看仓库材料以及所属人")
    @PostMapping("/selectOneRepository")
    public Result selectOneRepository(@RequestParam("repoId") String repoId){
        Map<String, Object> map = repositoryService.selectOneRepository(repoId);
        return Result.ok().data(map);
    }
}

