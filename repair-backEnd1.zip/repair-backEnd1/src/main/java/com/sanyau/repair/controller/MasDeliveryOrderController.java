package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.InsertDeliveryOrderAccept;
import com.sanyau.repair.entity.DeliveryOrder;
import com.sanyau.repair.entity.ReturnOrder;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IDeliveryOrderService;
import com.sanyau.repair.service.IReturnOrderService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/delivery-order")
public class MasDeliveryOrderController {

    @Autowired
    public IDeliveryOrderService iDeliveryOrderService;

    @ApiOperation(value = "出库订单展示")
    @PostMapping("showOrder")
    public Result showOrder(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        List<DeliveryOrder> deliveryOrders = iDeliveryOrderService.list(new QueryWrapper<DeliveryOrder>().eq("master_account", account).orderByDesc("create_time"));
        return Result.ok().data("出库订单展示", deliveryOrders);
    }

    @ApiOperation(value = "添加出库订单")
    @PostMapping("/insertOrder")
    public Result insertOrder(@RequestBody InsertDeliveryOrderAccept insertDeliveryOrderAccept){
        boolean b = iDeliveryOrderService.insertDeliverOrder(insertDeliveryOrderAccept);
        if (b){
            return Result.ok().message("出库订单提交成功");
        }else {
            return Result.error("出库操作失败");
        }
    }
}

