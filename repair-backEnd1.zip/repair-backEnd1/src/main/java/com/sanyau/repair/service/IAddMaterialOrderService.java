package com.sanyau.repair.service;

import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.AddMaterialInfo;
import com.sanyau.repair.entity.AddMaterialOrder;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IAddMaterialOrderService extends IService<AddMaterialOrder> {
    /**
     * 查看添加材料订单
     */
    Map<String,Object> selectAddMaterialOrder(Long current, Long limit,String orderId,String materialId);

    /**
     * 查看添加材料订单包含材料信息
     */
    Map<String,Object> selectAddMaterialInfo(String addMaterialOrderId);

    /**
     * 删除添加材料订单及添加材料订单材料信息
     */
    boolean deleteMaterialOrder(String addMaterialOrderId);

    /**
     * 批量删除
     */
    Map<String,Object> deleteMaterialOrders(List<String> addMaterialOrders);
}
