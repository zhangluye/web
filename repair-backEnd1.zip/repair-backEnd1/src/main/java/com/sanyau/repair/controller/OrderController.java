package com.sanyau.repair.controller;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.sanyau.repair.accept.SelectOrderAccept;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IOrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/order")
public class OrderController {
    @Autowired
    private IOrderService orderService;

    @ApiOperation("查看全部订单")
    @PostMapping("/selectAllOrder")
    public Result selectAllOrder(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                 @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                 @RequestBody SelectOrderAccept selectOrderAccept,
                                 @RequestParam("sate") Integer sate){
        Map<String, Object> map = orderService.selectAllOrder(current, limit, selectOrderAccept, sate);
        return Result.ok().data(map);
    }
    @ApiOperation("用于批量导出的查看所有订单")
    @PostMapping("/selectAllOrderByE")
    public Result selectAllOrderByE(){
        Map<String, Object> map = orderService.selectAllOrderByE();
        return Result.ok().data(map);
    }

    @ApiOperation("删除订单")
    @PostMapping("/deleteOrder")
    public Result deleteOrder(@RequestParam("orderId") String orderId){
        boolean b = orderService.deleteOrder(orderId);
        if (b){
            return Result.ok().message("删除订单成功");
        }else {
            return Result.error("删除订单失败");
        }
    }

    @ApiOperation("查看订单详细信息")
    @PostMapping("/selectOneOrder")
    public Result selectOneOrder(@RequestParam("orderId") String orderId){
        Map<String, Object> map = orderService.selectOrderMaterial(orderId);
        return Result.ok().data(map);
    }

    @ApiOperation("批量删除订单")
    @PostMapping("/deleteOrders")
    public Result deleteOrders(@RequestBody List<String> orders){
        Map<String, Object> map = orderService.deleteOrders(orders);
        return Result.ok().data(map);
    }

    @ApiOperation("查看订单图片信息")
    @PostMapping("/selectPic")
    public Result selectPic(@RequestParam("orderId") String orderId){
        Map<String, Object> map = orderService.selectPic(orderId);
        return Result.ok().data(map);
    }
}

