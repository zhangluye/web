package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class SelectWorkersAccept {

    private String name;

    private String phone;
}
