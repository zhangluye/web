package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.entity.ReturnMaterialInfo;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialInfoService;
import com.sanyau.repair.service.IReturnMaterialInfoService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/return-material-info")
public class MasReturnMaterialInfoController {

    @Autowired
    public IReturnMaterialInfoService iReturnMaterialInfoService;
    @Autowired
    public IMaterialInfoService iMaterialInfoService;

    @ApiOperation(value = "返库订单材料展示")
    @PostMapping("showInfo")
    public Result showInfo(@RequestBody JSONObject jsonObject){
        String returnOrderId = jsonObject.getString("returnOrderId");
        QueryWrapper<ReturnMaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("return_order_id", returnOrderId);
        List<ReturnMaterialInfo> returnMaterialInfos = iReturnMaterialInfoService.list(queryWrapper);
        return Result.ok().data("返库订单材料展示", returnMaterialInfos);
    }

    @ApiOperation(value = "返库订单材料添加")
    @PostMapping("insertInfo")
    public Result insertInfo(@RequestBody JSONObject jsonObject){
        //获取选择的材料id，材料数量，出库ID
        JSONArray materialIds = jsonObject.getJSONArray("materialIds");
        List<String> materialIdList = JSONObject.parseArray(materialIds.toJSONString(), String.class);
        JSONArray amounts = jsonObject.getJSONArray("amounts");
        System.out.println(amounts);
        System.out.println(materialIds);
        List<String> amountList = JSONObject.parseArray(amounts.toJSONString(), String.class);
        String returnOrderId = jsonObject.getString("returnOrderId");
        //获取到所有选择的的材料信息
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("material_id", materialIdList);
        List<MaterialInfo> materialInfoList = iMaterialInfoService.list(queryWrapper);
        //构建插入选择的出库材料信息
        int i = 0;
        int materialLen = materialInfoList.size();
        List<ReturnMaterialInfo> returnMaterialInfoList = new ArrayList<>();
        while (i < materialLen){
            ReturnMaterialInfo returnMaterialInfo = new ReturnMaterialInfo();
            returnMaterialInfo.setMaterialId(materialInfoList.get(i).getMaterialId());
            returnMaterialInfo.setMaterialName(materialInfoList.get(i).getMaterialName());
            int num = materialIdList.indexOf(materialInfoList.get(i).getMaterialId());
            returnMaterialInfo.setReturnAmount(amountList.get(num));
            returnMaterialInfo.setMaterialMetric(materialInfoList.get(i).getMaterialMetric());
            returnMaterialInfo.setMaterialType(materialInfoList.get(i).getMaterialType());
            returnMaterialInfo.setMaterialUnitPrice(materialInfoList.get(i).getMaterialPrice());
            returnMaterialInfo.setMaterialBrand(materialInfoList.get(i).getMaterialBrand());
            returnMaterialInfo.setReturnOrderId(returnOrderId);
            returnMaterialInfo.setReturnOrderState(1);
            returnMaterialInfoList.add(returnMaterialInfo);
            i ++;
        }
        System.out.println(returnMaterialInfoList);
        //插入选择的出库材料信息
        iReturnMaterialInfoService.saveBatch(returnMaterialInfoList);
        return Result.ok().message("返库订单材料添加");
    }

}

