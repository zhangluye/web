package com.sanyau.repair.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.mapper.AbnormalOrderMapper;
import com.sanyau.repair.mapper.OrderMapper;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IOrderService;
import com.sanyau.repair.utils.AbnormalUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/abnormal-order")
public class MasAbnormalOrderController {
    @Autowired
    private IOrderService orderService;
    private OrderMapper orderMapper;
    private AbnormalOrderMapper abnormalOrderMapper;

    /*取消订单*/
    @PostMapping("/order/updateOrderState")
    @ResponseBody
    public Result updateOrderState(@RequestParam("order_id") Long order_id,
                                   @RequestBody Order order){
        QueryWrapper<Order> wrapper = new QueryWrapper<>();

        wrapper.eq("order_id", order_id);
        System.out.println(order_id);
        List<Order> orders = orderService.list(wrapper);

        /*查找到对应的orderId的订单*/
        Order order1 = orders.get(0);

//        String userId = order.getUserId();
//        order.setUserId(userId);//设置学生的Id

        AbnormalOrder abnormalOrder = new AbnormalOrder();
        abnormalOrder.setOrderId(order.getOrderId());
        AbnormalUtils.setOrderParam(abnormalOrder,order1);
        int resultCount = 0;
        try {
            resultCount = abnormalOrderMapper.insert(abnormalOrder);//插入
        }finally {
            if(resultCount != 1){//若影响行数不为1，则说明插入失败
                return Result.error("撤回订单失败");
            }
        }

        System.out.println(order1);
        int result = orderMapper.deleteById(order1.getId());
        if(result <1){
            System.out.println(result);
            return Result.error("撤回订单失败");
        }
        return Result.ok().data("ok","撤回订单成功");
    }
}

