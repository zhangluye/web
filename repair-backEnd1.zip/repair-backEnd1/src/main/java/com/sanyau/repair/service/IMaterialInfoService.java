package com.sanyau.repair.service;

import com.sanyau.repair.accept.MaterialAccept;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sanyau.repair.entity.DeliveryOrder;
import com.sanyau.repair.entity.MaterialInfo;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IMaterialInfoService extends IService<MaterialInfo> {
    /**
     * 查询材料信息
     */
    Map<String,Object> selectMaterial(Long current,Long limit,String materialId);
    /**
     * 修改材料信息
     */
    boolean updateMaterial(MaterialInfo materialInfo);
    /**
     * 增加材料信息
     */
    boolean insertMaterial(List<MaterialAccept> materialAccepts);
    /**
     * 删除材料信息
     */
    boolean deleteMaterial(String materialId);
    /**
     *批量删除材料信息
     */
    Map<String, Object> deleteMaterials(List<String> materialInfos);
    /**
     * 用于导出的全部查询
     */
    Map<String,Object> selectAllMaterial();

}
