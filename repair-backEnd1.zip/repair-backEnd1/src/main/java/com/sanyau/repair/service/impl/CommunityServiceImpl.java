package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.CommunityAccept;
import com.sanyau.repair.accept.UpdateCommunityAccept;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.Community;
import com.sanyau.repair.entity.Region;
import com.sanyau.repair.mapper.CommunityMapper;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.ICommunityService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.service.IRegionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-11
 */
@Service
public class CommunityServiceImpl extends ServiceImpl<CommunityMapper, Community> implements ICommunityService {
    @Autowired
    private ICommunityService communityService;
    @Autowired
    private IBuildingService buildingService;
    @Autowired
    private IRegionService regionService;


    @Override
    public boolean insertCommunity(CommunityAccept communityAccept) {
        //判断增加的类型是否存在,不存在则插入
        Community community = communityService.getOne(new QueryWrapper<Community>().eq("community_type",communityAccept.getCommunity()));
        Community community1 = new Community();
        Region region1 = new Region();
        Building building1 = new Building();
        if(community==null&&communityAccept.getCommunity()!=null){
            community1.setId(null);
            community1.setCommunityType(communityAccept.getCommunity());
            communityService.save(community1);
        }
        Region region = regionService.getOne(new QueryWrapper<Region>().eq("region_name",communityAccept.getRegion()));
        if(community.getId()!=null&&region==null&&communityAccept.getRegion()!=null){
            region1.setRegionName(communityAccept.getRegion());
            region1.setCommunityType(community.getId());
            regionService.save(region1);
        }

        Building building = buildingService.getOne(new QueryWrapper<Building>().eq("building_name",communityAccept.getBuilding()));
        if(region.getId()!=null&&building==null&&communityAccept.getBuilding()!=null){
            building1.setBuildingName(communityAccept.getBuilding());
            building1.setRegionType(region.getId());
            buildingService.save(building1);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean deleteCommunity(CommunityAccept communityAccept) {
        Building building = buildingService.getOne(new QueryWrapper<Building>().eq("building_name",communityAccept.getBuilding()));
        Region region = regionService.getOne(new QueryWrapper<Region>().eq("region_name",communityAccept.getRegion()));
        Community community = communityService.getOne(new QueryWrapper<Community>().eq("community_type",communityAccept.getCommunity()));
        if(building==null||region==null||community==null){
            return false;
        }else{
            buildingService.remove(new QueryWrapper<Building>().eq("building_name",communityAccept.getBuilding()));
            return true;
        }
    }

    @Override
    public Map<String, Object> selectCommunity() {
        List<Community> communities = communityService.list();
        List<Region> regions = regionService.list();
        Map<String,Object> communityMap = new HashMap<>();
        Map<String,Object> regionMap = new HashMap<>();
        for(int i=0;i<communities.size();i++){
            List<Region> community_type = regionService.list(new QueryWrapper<Region>().eq("community_type", communities.get(i).getId()));
            communityMap.put(communities.get(i).getCommunityType(),community_type);
        }
        for(int i=0;i<regions.size();i++){
            List<Building> region_type = buildingService.list(new QueryWrapper<Building>().eq("region_type", regions.get(i).getId()));
            regionMap.put(regions.get(i).getRegionName(),region_type);
        }
        Map<String,Object> map = new HashMap<>();
        map.put("社区对区域",communityMap);
        map.put("区域对楼号",regionMap);
        return map;
    }

    @Override
    public boolean updateCommunity(UpdateCommunityAccept communityAccept) {
        Community community = communityService.getOne(new QueryWrapper<Community>().eq("id",communityAccept.getCommunityId()));
        Region region = regionService.getOne(new QueryWrapper<Region>().eq("id",communityAccept.getRegionId()));
        Building building = buildingService.getOne(new QueryWrapper<Building>().eq("id",communityAccept.getBuildingId()));
        if(community==null && region==null && building==null){
            return false;
        }
        if(community!=null){
            community.setCommunityType(communityAccept.getCommunity());
            communityService.updateById(community);
        }
        if(region!=null&&community!=null){
            region.setRegionName(communityAccept.getRegion());
            region.setCommunityType(community.getId());
            regionService.updateById(region);
        }
        if(building!=null&&region!=null){
            building.setBuildingName(communityAccept.getBuilding());
            building.setRegionType(region.getId());
            buildingService.updateById(building);
        }
        return true;
    }
}
