package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.AdminRole;
import com.sanyau.repair.entity.Role;
import com.sanyau.repair.mapper.AdminRoleMapper;
import com.sanyau.repair.service.IAdminRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.service.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-20
 */
@Service
public class AdminRoleServiceImpl extends ServiceImpl<AdminRoleMapper, AdminRole> implements IAdminRoleService {
    @Autowired
    private IRoleService iRoleService;
    @Autowired
    private IAdminRoleService iAdminRoleService;

    @Override
    public Boolean insertRole(String roleName,Integer userId) {
        Role role = iRoleService.getOne(new QueryWrapper<Role>().eq("id", roleName));
        AdminRole adminRole = new AdminRole();
        adminRole.setRoleId(role.getId());
        adminRole.setUserId(userId);
        return iAdminRoleService.save(adminRole);
    }
}
