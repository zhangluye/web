package com.sanyau.repair.service.impl;

import com.sanyau.repair.entity.Type;
import com.sanyau.repair.mapper.TypeMapper;
import com.sanyau.repair.service.ITypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
@Service
public class TypeServiceImpl extends ServiceImpl<TypeMapper, Type> implements ITypeService {
    @Autowired
    private ITypeService typeService;

    @Override
    public List<Type> returnAllTypes() {
        return typeService.list();
    }
}
