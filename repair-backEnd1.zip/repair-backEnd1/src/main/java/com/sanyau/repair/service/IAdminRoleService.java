package com.sanyau.repair.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.sanyau.repair.entity.AdminRole;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-20
 */
public interface IAdminRoleService extends IService<AdminRole> {
    /**
     * 新增用户和权限对应关系
     */
    Boolean insertRole(String roleName,Integer userId);

}
