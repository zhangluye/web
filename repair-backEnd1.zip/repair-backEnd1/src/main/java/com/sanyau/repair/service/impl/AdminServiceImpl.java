package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.SelectAdminAccept;
import com.sanyau.repair.accept.SelectManyAccept;
import com.sanyau.repair.accept.AdminAccept;
import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.AdminRole;
import com.sanyau.repair.entity.Role;
import com.sanyau.repair.mapper.AdminMapper;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IAdminRoleService;
import com.sanyau.repair.service.IAdminService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.service.IRoleService;
import com.sanyau.repair.utils.IDUtils;
import com.sanyau.repair.utils.JwtTokenUtil;
import com.sanyau.repair.utils.JwtUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements IAdminService {
    @Autowired
    private IAdminService adminService;
    @Autowired
    private IAdminRoleService adminRoleService;
    @Autowired
    private IRoleService iRoleService;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AdminMapper adminMapper;

    @Value("${jwt.tokenHead}")
    private String tokenHead;

    @Override
    public Map<String,Object> selectAllAdmin(Long current, Long limit, SelectAdminAccept selectAdminAccept) {
        Page<Admin> adminPage = new Page<>(current,limit);
        adminService.page(adminPage,selectAdmins(selectAdminAccept).orderByDesc("create_time"));
        long adminTotal = adminPage.getTotal();
        List<Admin> records = adminPage.getRecords();//数据list集合
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", adminTotal);
        map.put("admins", records);
        return map;
    }

    @Override
    public Boolean insertAdmin(AdminAccept adminAccept) {
        Admin admin = new Admin();
        BeanUtils.copyProperties(adminAccept,admin);
        admin.setPassword(IDUtils.encodePassword(admin.getPassword()));
        admin.setCreateTime(new Date());
        try{
            adminService.save(admin);
        }catch (Exception e){
            return false;
        }
        return adminRoleService.insertRole(adminAccept.getRole(), admin.getId());
    }

    @Override
    public Boolean updateAdmin(AdminAccept adminAccept) {
        Admin admin = new Admin();
        admin.setMobile(adminAccept.getMobile());
        return adminService.update(admin, new UpdateWrapper<Admin>().eq("account", adminAccept.getAccount()));
    }

    @Override
    public Boolean deleteAdmin(String account) {
        Admin admin = adminService.getOne(new QueryWrapper<Admin>().eq("account", account));
        boolean deleteAdminRole = adminRoleService.remove(new QueryWrapper<AdminRole>().eq("user_id", admin.getId()));
        boolean deleteAdmin = adminService.remove(new QueryWrapper<Admin>().eq("account", account));
        return deleteAdmin&&deleteAdminRole;
    }

    @Override
    public Boolean updatePower(String power,String account) {
        Admin admin = adminService.getOne(new QueryWrapper<Admin>().eq("account",account));
        Role role = iRoleService.getOne(new QueryWrapper<Role>().eq("name",power));
        UpdateWrapper<AdminRole> updateWrapper = new UpdateWrapper<AdminRole>().eq("user_id",admin.getId());
        AdminRole adminRole = new AdminRole();
        adminRole.setRoleId(role.getId());
        return adminRoleService.update(adminRole,updateWrapper);
    }

    @Override
    public Map<String, Object> selectOneAdmin(String account) {
        Admin admin = adminService.getOne(new QueryWrapper<Admin>().eq("account",account));
        Map<String,Object> map = new HashMap<>();
        if(admin!=null){
            map.put("admin",admin);
        }
        return map;
    }

    @Override
    public Map<String, Object> selectManyAdmin(SelectManyAccept selectManyAccept) {
        QueryWrapper<Admin> wrapper = new QueryWrapper<Admin>();
        if(selectManyAccept.getAccount()!=null&&!selectManyAccept.getAccount().equals("")){
            wrapper.eq("account",selectManyAccept.getAccount());
        }
        if(selectManyAccept.getDepartment()!=null&&!selectManyAccept.getDepartment().equals("")){
            wrapper.eq("department",selectManyAccept.getDepartment());
        }
        if(selectManyAccept.getMobile()!=null&&!selectManyAccept.getMobile().equals("")){
            wrapper.eq("mobile",selectManyAccept.getMobile());
        }
        if(selectManyAccept.getName()!=null&&!selectManyAccept.getName().equals("")){
            wrapper.eq("name",selectManyAccept.getName());
        }
        List<Admin> adminList = adminService.list(wrapper);
        Map<String, Object> map = new HashMap<>();
        map.put("admins",adminList);
        return map;
    }

    @Override
    public boolean updatePassword(String password, String newPassword) {
        Admin admin = (Admin) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String password1 = admin.getPassword();
        BCryptPasswordEncoder bcryptPasswordEncoder = new BCryptPasswordEncoder();
        boolean pwd = bcryptPasswordEncoder.matches(password1,password);
        if(pwd){
            String account = admin.getAccount();
            Admin admin1 = adminService.getOne(new QueryWrapper<Admin>().eq("account", account));
            String encode = bcryptPasswordEncoder.encode(newPassword);
            admin1.setPassword(encode);
            adminService.save(admin1);
            return true;
        }else{
            return false;
        }
    }

    /**
     * 登录之后返回token
     * @param account
     * @param password
     * @param httpServletRequest
     * @return
     */
    @Override
    public Result login(String account, String password, HttpServletRequest httpServletRequest) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(account);
        if(null==userDetails || !passwordEncoder.matches(password,userDetails.getPassword())){
            return Result.error("用户名或密码不正确");
        }
        if(!userDetails.isEnabled()){
            return Result.error("账号被禁用，请联系管理员");
        }
        //更新登录用户对象
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);

        //生成token
        String token = JwtUtils.getJwtToken(account, password);
        Map<String,String> tokenMap = new HashMap<>();
        tokenMap.put("token",token);
        return Result.ok().data("token",token);
    }

    @Override
    public Admin getAdminByUserName(String username) {
        return adminMapper.selectOne(new QueryWrapper<Admin>().eq("account",username)
                .eq("level",true));
    }

    @Override
    public QueryWrapper<Admin> selectAdmins(SelectAdminAccept selectAdminAccept) {
        if (selectAdminAccept==null){
            return new QueryWrapper<Admin>();
        }
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<Admin>();
        if(selectAdminAccept.getAccount()!=null&&!selectAdminAccept.getAccount().equals("")){
            queryWrapper.eq("account",selectAdminAccept.getAccount());
        }
        if(selectAdminAccept.getPhone()!=null&&!selectAdminAccept.getPhone().equals("")){
            queryWrapper.eq("mobile",selectAdminAccept.getPhone());
        }
        if (selectAdminAccept.getName()!=null&&!selectAdminAccept.getName().equals("")){
            queryWrapper.eq("name",selectAdminAccept.getName());
        }
        if(selectAdminAccept.getDepartment()!=null&&!selectAdminAccept.getDepartment().equals("")){
            queryWrapper.eq("department",selectAdminAccept.getDepartment());
        }
        if (selectAdminAccept.getCreateTime()!=null){
            queryWrapper.between("create_time",new Date(selectAdminAccept.getCreateTime()[0]),new Date(selectAdminAccept.getCreateTime()[1]));
        }
        return queryWrapper;
    }

    @Override
    public Map<String, Object> deleteAdmins(List<String> admins) {
        int success = 0;
        int error = 0;
        if (admins.size()!=0){
            for(String admin:admins){
                boolean b = deleteAdmin(admin);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public Map<String, Object> selectPower() {
        List<Role> list = iRoleService.list();
        Map<String,Object> map = new HashMap<>();
        map.put("roles",list);
        return map;
    }
}
