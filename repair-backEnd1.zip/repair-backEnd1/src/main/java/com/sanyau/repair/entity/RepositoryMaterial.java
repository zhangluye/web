package com.sanyau.repair.entity;

import java.math.BigDecimal;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author WildSky
 * @since 2021-03-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="RepositoryMaterial对象", description="")
public class RepositoryMaterial implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "仓库ID")
    private String repoId;

    @ApiModelProperty(value = "材料ID")
    private String materialId;

    @ApiModelProperty(value = "材料名")
    private String materialName;

    @ApiModelProperty(value = "材料价格")
    private BigDecimal materialPrice;

    @ApiModelProperty(value = "实时材料数量")
    private Long materialAmount;

    @ApiModelProperty(value = "材料品牌")
    private String materialBrand;

    @TableId(type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "单位")
    private String materialMetric;

    private Integer materialType;

    @ApiModelProperty(value = "总数")
    private Long repoMaterialTotal;

    @ApiModelProperty(value = "返库数量")
    private Long returnMaterialAmout;

}
