package com.sanyau.repair.accept;


import lombok.Data;

@Data
public class UpdateMasterPW {
    private String account;

    private String password;

    private String newPassword;
}
