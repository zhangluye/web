package com.sanyau.repair.accept;

import lombok.Data;

import java.util.List;

@Data
public class SelectMasterAccept {
    private String account;

    private String name;

    private String phone;

    private Long[] createTime;

//    private List<Integer> repairType;
//
//    private List<Integer> repairCommunity;

}
