package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.WorkersInfo;
import com.sanyau.repair.mapper.WorkersInfoMapper;
import com.sanyau.repair.response.HttpRequest;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.impl.WorkersInfoServiceImpl;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/stu/repair/workers-info")
public class StuWorkersInfoController {

    @Autowired
    WorkersInfoMapper workersInfoMapper;

    @Autowired
    WorkersInfoServiceImpl workersInfoService;

    /*所有职工信息查询*/
    @ApiOperation(value = "查询所有职工信息")
    @PostMapping("/selectAllWorkers")
    public Result selectAllWorkers() {
        List<WorkersInfo> workersInfos =workersInfoMapper .selectList(null);
        if (workersInfos.isEmpty()) {
            return Result.error("查询结果为空");
        }
        return Result.ok().data("workersList", workersInfos);
    }


    /*职工信息查询-根据微信号查询*/
    @ApiOperation(value = "根据open_id查找学生")
    @PostMapping("/findByOpen_id")
    public Result findById(@RequestParam("open_id") String open_id) {
        /* 创建StudentInfo的条件查询类 */
        QueryWrapper<WorkersInfo> wrapper = new QueryWrapper<>();
        /* column为数据库表的字段名,eq为equal的意思，即相等
         * wrapper更多的条件查询，请看Mybatis-plus官网：条件构造器
         * Address：https://mp.baomidou.com/guide/wrapper.html */
        wrapper.eq("open_id", open_id);
        List<WorkersInfo> workersInfos = workersInfoService.list(wrapper);
        if (workersInfos.size() != 1) {
            return Result.error("查询失败");
        }
        WorkersInfo info = workersInfos.get(0);
        return Result.ok().data("info", info);
    }

    /*职工注册*/
    @ApiOperation(value = "添加职工")
    @PostMapping("/inset")
    public Result WorkersInsert(WorkersInfo workersInfo,
                                @RequestParam("code")  String code
    ) {
        Map<String,Object> map = new HashMap<String,Object>();
        //登录凭证不能为空
        if (code == null || code.length() == 0) {
            map.put("status", 0);
            map.put("msg", "code 不能为空");
            System.out.println("map1:" + map);
            return Result.error("code不能为空");
        }

        //小程序唯一标识
        String wxspAppid = "wx3d2375ece34b7285";
        //小程序的 app secret
        String wxspSecret = "6d56ae530c8901c3a462e8e44c017cba";
        //授权
        String grant_type = "authorization_code";
//      向微信服务器 使用登录凭证 code 获取 session_key 和 openid
        //请求参数
        String params = "appid=" + wxspAppid + "&secret=" + wxspSecret + "&js_code=" + code + "&grant_type=" + grant_type;
        //发送请求
        String sr = HttpRequest.sendGet("https://api.weixin.qq.com/sns/jscode2session", params);
        //解析相应内容（转换成json对象）
        JSONObject json = JSONObject.parseObject(sr);
        //获取会话密钥（session_key）
        String session_key = json.get("session_key").toString();
        //用户的唯一标识（openid）
        String openid = (String) json.get("openid");
        System.out.println("openid:" + openid);

        workersInfo.setId(null);
        workersInfo.setOpenId(openid);
        System.out.println(workersInfo.toString());

        if(workersInfo.getWorkersName() == null ||
                workersInfo.getWorkersApartment() == null
        ){
            return Result.error("注册信息填充不完整");
        }

        boolean save = workersInfoService.save(workersInfo);
        if(save){
            return Result.ok().data("inset","成功");
        }
        else {
            return Result.error("添加失败");
        }
    }

    /*职工信息更改*/
    @ApiOperation(value =  "修改职工信息")
    @PostMapping("update")
    public Result WorkersUpdate(@RequestParam (name ="workers_name", required = false) String workers_name,
                                @RequestParam(name ="workers_apartment", required = false) String workers_apartment,
                                @RequestParam(name = "workers_phone", required = false) String workers_phone,
                                @RequestParam("openId") String openid
    ) {
        QueryWrapper<WorkersInfo> queryWrapper = new QueryWrapper<>();

        queryWrapper.eq("openid",openid);

        WorkersInfo workersInfo = new WorkersInfo();
        workersInfo.setWorkersName(workers_name);
        workersInfo.setWorkersApartment(workers_apartment);
        workersInfo.setWorkersPhone(workers_phone);

        workersInfoMapper.update(workersInfo,queryWrapper);
        return  Result.ok().data("update","更新成功");
    }

    /*职工登录*/
    @ApiOperation(value = "职工登录")
    @PostMapping("/login")
    public Result WorkersLogin(@RequestParam("code")  String code) {

        Map<String, Object> map = new HashMap<String, Object>();
        //登录凭证不能为空
        if (code == null || code.length() == 0) {
            map.put("status", 0);
            map.put("msg", "code 不能为空");
            System.out.println("map1:" + map);
            return Result.error("code不能为空");
        }

        //小程序唯一标识
        String wxspAppid = "wx3d2375ece34b7285";
        //小程序的 app secret
        String wxspSecret = "6d56ae530c8901c3a462e8e44c017cba";
        //授权
        String grant_type = "authorization_code";
//      向微信服务器 使用登录凭证 code 获取 session_key 和 openid
        //请求参数
        String params = "appid=" + wxspAppid + "&secret=" + wxspSecret + "&js_code=" + code + "&grant_type=" + grant_type;
        //发送请求
        String sr = HttpRequest.sendGet("https://api.weixin.qq.com/sns/jscode2session", params);
        //解析相应内容（转换成json对象）
        JSONObject json = JSONObject.parseObject(sr);
        //获取会话密钥（session_key）
        String session_key = json.get("session_key").toString();
        //用户的唯一标识（openid）
        String openid = (String) json.get("openid");
        System.out.println("openid:" + openid);

        WorkersInfo workersInfo = new WorkersInfo();
        workersInfo.setOpenId(openid);
        System.out.println(openid);
        try {
            WorkersInfo workersInfo1 = workersInfoService.getOne(new QueryWrapper<WorkersInfo>()
                    .eq("openid", workersInfo.getOpenId()));
            System.out.println(workersInfo1);
            if (workersInfo1 != null) {
                return Result.ok().data("true", "登陆成功");
            } else {
                return Result.error("登录失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("");
        }
    }
}

