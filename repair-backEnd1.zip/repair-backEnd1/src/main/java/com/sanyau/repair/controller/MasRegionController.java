package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.Community;
import com.sanyau.repair.entity.Order;
import com.sanyau.repair.entity.Region;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IRegionService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/region")
public class MasRegionController {

    @Autowired
    private IRegionService iRegionService;

    @ApiOperation(value = "筛选区域")
    @RequestMapping(value = "/selectRegion",method = RequestMethod.GET)
    @ResponseBody
    public Result selectRegion(@RequestBody JSONObject jsonObject){
        Integer communityType = jsonObject.getInteger("communityType");
        QueryWrapper<Region> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("community_type", communityType);
        List<Region> regions = iRegionService.list(queryWrapper);
        return Result.ok().data("筛选区域", regions);
    }

}

