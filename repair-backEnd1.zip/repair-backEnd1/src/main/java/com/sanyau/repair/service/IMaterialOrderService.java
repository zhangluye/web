package com.sanyau.repair.service;

import com.sanyau.repair.entity.MaterialOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-21
 */
public interface IMaterialOrderService extends IService<MaterialOrder> {

}
