package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.SelectWorkersAccept;
import com.sanyau.repair.accept.UpdateWorkersAccept;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.WorkersInfo;
import com.sanyau.repair.mapper.WorkersInfoMapper;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.IWorkersInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class WorkersInfoServiceImpl extends ServiceImpl<WorkersInfoMapper, WorkersInfo> implements IWorkersInfoService {

    @Autowired
    private IWorkersInfoService workersInfoService;
    @Autowired

    private IBuildingService buildingService;

    @Override
    public boolean updateWorkers(UpdateWorkersAccept workersAccept) {
        WorkersInfo workersInfo = new WorkersInfo();
        BeanUtils.copyProperties(workersAccept,workersInfo);
        return workersInfoService.updateById(workersInfo);
    }

    @Override
    public boolean deleteWorkers(Integer id) {
        return workersInfoService.removeById(id);
    }

    @Override
    public Map<String, Object> selectWorkers(Long current, Long limit, SelectWorkersAccept selectWorkersAccept) {
        Page<WorkersInfo> workersInfoPage = new Page<>(current,limit);
        QueryWrapper<WorkersInfo> queryWrapper = new QueryWrapper<WorkersInfo>();
        if (selectWorkersAccept.getName()!=null&&!selectWorkersAccept.getName().equals("")){
            queryWrapper.eq("workers_name",selectWorkersAccept.getName());
        }
        if (selectWorkersAccept.getPhone()!=null&&!selectWorkersAccept.getPhone().equals("")){
            queryWrapper.eq("workers_phone",selectWorkersAccept.getPhone());
        }
        workersInfoService.page(workersInfoPage,queryWrapper);
        HashMap<String, Object> map = new HashMap<>();
        long adminTotal = workersInfoPage.getTotal();
        List<WorkersInfo> workersInfos = workersInfoService.list();
        for(WorkersInfo workersInfo :workersInfos){
            Building id = buildingService.getOne(new QueryWrapper<Building>().eq("id", workersInfo.getWorkersApartment()));
            workersInfo.setWorkersApartment(id.getBuildingName());
        }
        map.put("total", adminTotal);
        map.put("workers", workersInfos);
        return map;
    }

    @Override
    public Map<String, Object> deleteWorkersTo(List<Integer> workers) {
        int success = 0;
        int error = 0;
        if(workers.size()!=0){
            for(Integer returnOrder:workers){
                boolean b = workersInfoService.deleteWorkers(returnOrder);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }
}
