package com.sanyau.repair.controller;


import com.sanyau.repair.accept.SelectDeliveryOrderAccept;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.entity.DeliveryOrder;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IDeliveryMaterialInfoService;
import com.sanyau.repair.service.IDeliveryOrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/delivery-order")
public class DeliveryOrderController {
    @Autowired
    private IDeliveryOrderService deliveryOrderService;

    @ApiOperation("查看所有出库订单")
    @PostMapping("/selectDeliverOrder")
    public Result selectDeliverOrder(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                     @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                     @RequestBody SelectDeliveryOrderAccept selectDeliveryOrderAccept) {
        Map<String, Object> map = deliveryOrderService.selectAllDeliveryOrder(current, limit, selectDeliveryOrderAccept);
        return Result.ok().data(map);
    }

    @ApiOperation("查询单个订单详细信息")
    @PostMapping("/selectOneDeliverOrder")
    public Result selectOneDeliverOrder(@RequestParam("orderId") String orderId) {
        Map<String, Object> map = deliveryOrderService.selectMaterial(orderId);
        return Result.ok().data(map);
    }

    @ApiOperation("删除出库订单")
    @PostMapping("/deleteDeliverOrder")
    public Result deleteDeliverOrder(@RequestParam("orderId") String orderId) {
        boolean b = deliveryOrderService.deleteDeliveryOrder(orderId);
        if (b) {
            return Result.ok().message("删除订单成功");
        } else {
            return Result.error("删除订单失败");
        }
    }

    @ApiOperation("审批订单")
    @PostMapping("/updateDeliverOrder")
    public Result updateDeliverOrder(@RequestParam("orderId") String orderId,@RequestParam("opinion") String opinion){
        boolean b = deliveryOrderService.updateDeliveryOrder(orderId, opinion);
        if(b){
            return Result.ok().message("操作成功");
        }else{
            return Result.error("操作失败");
        }
    }

    @ApiOperation("批量删除返库订单")
    @PostMapping("/deleteDeliveryOrders")
    public Result deleteDeliveryOrders(@RequestBody  List<String> deliveryOrders){
        Map<String, Object> map = deliveryOrderService.deleteDeliveryOrders(deliveryOrders);
        return Result.ok().data(map);
    }
}

