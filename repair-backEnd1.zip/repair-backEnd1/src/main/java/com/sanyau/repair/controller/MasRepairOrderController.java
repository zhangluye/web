package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.*;
import com.sanyau.repair.utils.qiniuyun.QiniuUpload;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-20
 */
@RestController
@RequestMapping("/mas/repair/repair-order")
public class MasRepairOrderController {
    @Autowired
    public IOrderService iRepairOrderService;
    @Autowired
    public IMasterInfoService iMasterInfoService;
    @Autowired
    private IOrderService orderService;
    @Autowired
    private IBuildingService buildingService;
    private IDetailsService detailsService;
    @Autowired
    private IMaterialOrderService iMaterialOrderService;
    @Autowired
    private IRepositoryService repositoryService;


    @ApiOperation(value = "多层筛选订单")
    @PostMapping("selectOrder")
    public Result selectOrder(@RequestBody JSONObject jsonObject){
        String repairType = jsonObject.getString("repairType");
        String userCommunity = jsonObject.getString("userCommunity");
        Integer orderState = jsonObject.getInteger("orderState");
        String userName = jsonObject.getString("userName");
        String userApartment = jsonObject.getString("userApartment");
        Date orderCreateTimeStart = jsonObject.getDate("orderCreateTimeStart");
        Date orderCreateTimeEnd = jsonObject.getDate("orderCreateTimeEnd");
        Date orderFinishTimeStart = jsonObject.getDate("orderFinishTimeStart");
        Date orderFinishTimeEnd = jsonObject.getDate("orderFinishTimeEnd");

        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        if (repairType != null){
            queryWrapper.eq("repair_type", repairType);
        }
        if(userCommunity != null){
            queryWrapper.eq("user_community", userCommunity);
        }
        if (orderState != null){
            queryWrapper.eq("order_state", orderState);
        }
        if (userName != null){
            queryWrapper.eq("user_name", userName);
        }
        if (userApartment != null){
            queryWrapper.eq("user_apartment", userApartment);
        }
        if (orderCreateTimeStart != null && orderCreateTimeEnd != null){
            queryWrapper.between("order_create_time", orderCreateTimeStart, orderCreateTimeEnd);
        }
        if (orderFinishTimeStart != null && orderFinishTimeEnd != null){
            queryWrapper.between("order_finish_time", orderFinishTimeStart, orderFinishTimeEnd);
        }

        List<Order> orders = iRepairOrderService.list(queryWrapper);
        for (Order order:orders){
            exchange(order);
        }
        return Result.ok().data("筛选出的订单", orders);
    }

    @ApiOperation("展示所有维修区域的未接单")
    @PostMapping("showState1")
    public Result showState1(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        List<Details> details = iMasterInfoService.selectDetails(account);
        List<String> repairDetails = new ArrayList<>();
        for (Details detail:details){
            repairDetails.add(detail.getId().toString());
        }
        List<Building> buildings = iMasterInfoService.selectBuilding(account);
        List<String> repairBuildings = new ArrayList<>();
        for (Building building:buildings){
            repairBuildings.add(building.getId().toString());
        }
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("user_community", repairBuildings);
        queryWrapper.eq("order_state", 1);
        queryWrapper.in("repair_type",repairDetails);
        List<Order> orders = iRepairOrderService.list(queryWrapper);
        for (Order order:orders){
            exchange(order);
        }
        return Result.ok().data("筛选出的订单", orders);
    }

    @ApiOperation("按维修区域筛选/未接单")
    @PostMapping("selectByBuilding1")
    public Result selectByBuilding1(@RequestBody JSONObject jsonObject){
        String community = jsonObject.getString("community");
        String account = jsonObject.getString("account");
        List<Details> details = iMasterInfoService.selectDetails(account);
        List<String> repairDetails = new ArrayList<>();
        for (Details detail:details){
            repairDetails.add(detail.getId().toString());
        }
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_community", community);
        queryWrapper.eq("order_state", 1);
        queryWrapper.in("repair_type",repairDetails);
        List<Order> orders = iRepairOrderService.list(queryWrapper);
        for (Order order:orders){
            exchange(order);
        }
        return Result.ok().data("筛选出的订单", orders);
    }

    @ApiOperation("展示所有维修区域的已接单")
    @PostMapping("showState2")
    public Result showState2(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        List<Details> details = iMasterInfoService.selectDetails(account);
        List<String> repairDetails = new ArrayList<>();
        for (Details detail:details){
            repairDetails.add(detail.getId().toString());
        }
        List<Building> buildings = iMasterInfoService.selectBuilding(account);
        List<String> repairBuildings = new ArrayList<>();
        for (Building building:buildings){
            repairBuildings.add(building.getId().toString());
        }
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("user_community", repairBuildings);
        queryWrapper.eq("order_state", 2);
        queryWrapper.in("repair_type",repairDetails);
        List<Order> orders = iRepairOrderService.list(queryWrapper);
        for (Order order:orders){
            exchange(order);
        }
        return Result.ok().data("筛选出的订单", orders);
    }

    @ApiOperation("按维修区域筛选/已接单")
    @PostMapping("selectByBuilding2")
    public Result selectBuilding2(@RequestBody JSONObject jsonObject){
        String community = jsonObject.getString("community");
        String account = jsonObject.getString("account");
        List<Details> details = iMasterInfoService.selectDetails(account);
        List<String> repairDetails = new ArrayList<>();
        for (Details detail:details){
            repairDetails.add(detail.getId().toString());
        }
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_community", community);
        queryWrapper.eq("order_state", 2);
        queryWrapper.in("repair_type",repairDetails);
        List<Order> orders = iRepairOrderService.list(queryWrapper);
        for (Order order:orders){
            exchange(order);
        }
        return Result.ok().data("筛选出的订单", orders);
    }

    @ApiOperation("接单")
    @PostMapping("updateOrder")
    public Result updateOrder(@RequestBody JSONObject jsonObject){
        String masterAccount = jsonObject.getString("masterAccount");
        String orderId = jsonObject.getString("orderId");

        Order repairOrder = iRepairOrderService.selectByOrderId(orderId);
        MasterInfo masterInfo = iMasterInfoService.selectByAccount(masterAccount);

        repairOrder.setMasterAccount(masterAccount);
        repairOrder.setMasterPhone(masterInfo.getMasterPhone());
        repairOrder.setOrderState(2);

        QueryWrapper<Order> queryWrapper1 = new QueryWrapper();
        queryWrapper1.eq("order_id", orderId);
        iRepairOrderService.update(repairOrder, queryWrapper1);

        return Result.ok().message("接单成功");
    }

    @ApiOperation(value = "是否收费")
    @PostMapping("isOrder")
    public Result isOrder(@RequestBody JSONObject jsonObject){
        String orderId = jsonObject.getString("orderId");
        String orderType = jsonObject.getString("orderType");

        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("order_id", orderId);
        Order repairOrder = iRepairOrderService.selectByOrderId(orderId);
        repairOrder.setOrderType(orderType);
        iRepairOrderService.update(repairOrder, queryWrapper);

        return  Result.ok().message("是否收费更新完成");
    }

    @ApiOperation(value = "完成订单")
    @PostMapping("isEnd")
    public Result isEnd(@RequestBody JSONObject jsonObject){
        String orderId = jsonObject.getString("orderId");
        String url = jsonObject.getString("url");
        QueryWrapper<MaterialOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("order_id", orderId);
        List<MaterialOrder> materialOrders = iMaterialOrderService.list(queryWrapper);
        Order order_id = orderService.getOne(new QueryWrapper<Order>().eq("order_id", orderId));
        Repository master_account = repositoryService.getOne(new QueryWrapper<Repository>().eq("master_account", order_id.getMasterAccount()));
        List<MaterialOrder> repo_id = iMaterialOrderService.list(new QueryWrapper<MaterialOrder>().eq("repo_id", master_account.getRepoId()));
        for(int i=0;i<materialOrders.size();i++){
            for(int j=0;j<repo_id.size();j++){
                if(materialOrders.get(i).getMaterialId().equals(repo_id.get(j).getMaterialId())){
                    repo_id.get(j).setMaterialCount(repo_id.get(j).getMaterialCount()- materialOrders.get(i).getMaterialCount());
                }
            }
        }
        order_id.setOrderFinishTime(new Date());
        order_id.setOrderState(3);
        order_id.setPictureMaster(url);
        orderService.update(order_id,new QueryWrapper<Order>().eq("order_id", orderId));
        return  Result.ok().message("完成订单");
    }

//    @ApiOperation(value = "接收图片")
//    @RequestMapping(value = "/upload",method = RequestMethod.POST)
//    @ResponseBody
//    public Result uploadFile(@RequestParam("file") MultipartFile file){
////        上传文件
//        String url = QiniuUpload.uploadFile(file);
//        HashMap<String, Object> imgDataMap = new HashMap<>();
//        imgDataMap.put("url",url);
//        System.out.println(imgDataMap);
//        Result result = Result.ok().data("ok","上传图片成功");
//        result.setData(imgDataMap);
//
//        System.out.println(url);
//        return Result.ok().data("ok",imgDataMap);
//    }

    public Map<String,Object> selectBuildingAll(String account){
        List<Building> master_account = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        List<Order> order_state = orderService.list(new QueryWrapper<Order>().eq("order_state", 1));
        List<ReturnOrder> returnOrderList = new ArrayList<>();
        for(int i=0;i<master_account.size();i++){
            for(int j=0;j<order_state.size();j++){
                if(String.valueOf(master_account.get(i).getId()).equals(order_state.get(i).getUserCommunity())){
                    ReturnOrder returnOrder = new ReturnOrder();
                    BeanUtils.copyProperties(order_state.get(j),returnOrder);
                    returnOrderList.add(returnOrder);
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("orders",returnOrderList);
        return map;
    }

    public Order exchange(Order repairOrder){
        String repairType= buildingService.getById(Integer.valueOf(repairOrder.getRepairType())).getBuildingName();
        String userCommunity = detailsService.getById(Integer.valueOf(repairOrder.getUserCommunity())).getRepairDetails();
        repairOrder.setRepairType(repairType);
        repairOrder.setUserCommunity(userCommunity);

        return repairOrder;
    }
}

