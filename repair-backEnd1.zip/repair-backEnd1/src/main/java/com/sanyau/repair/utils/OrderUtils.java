package com.sanyau.repair.utils;

import com.sanyau.repair.entity.StudentInfo;
import com.sanyau.repair.mapper.StudentInfoMapper;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class OrderUtils {
    public static String getId() {
        String substring = String.valueOf(new Date().getTime()).substring(4,13);
        try {
            TimeUnit.MILLISECONDS.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return substring;
    }


}
