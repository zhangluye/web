package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.entity.MaterialOrder;
import com.sanyau.repair.entity.ReturnMaterialInfo;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialInfoService;
import com.sanyau.repair.service.IMaterialOrderService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-21
 */
@RestController
@RequestMapping("/mas/repair/material-order")
public class MasMaterialOrderController {

    @Autowired
    public IMaterialOrderService iMaterialOrderService;
    @Autowired
    public IMaterialInfoService iMaterialInfoService;

    @ApiOperation(value = "计费")
    @PostMapping("charging")
    public Result charging(@RequestBody JSONObject jsonObject){
        String orderId = jsonObject.getString("orderId");

        QueryWrapper<MaterialOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("order_id", orderId);
        List<MaterialOrder> materialOrders = iMaterialOrderService.list(queryWrapper);

        BigDecimal money = new BigDecimal("0");
        for(MaterialOrder i: materialOrders){
            Integer count1 = i.getMaterialCount();
            BigDecimal price = i.getMaterialPrice();
            BigDecimal count = new BigDecimal(count1.toString());
            money.add(price.multiply(count));
        }

        return  Result.ok().data("应缴费", money);
    }

    @ApiOperation(value = "订单材料添加")
    @PostMapping("insertInfo")
    public Result insertInfo(@RequestBody JSONObject jsonObject){
        //获取选择的材料id，材料数量，出库ID
        JSONArray materialIds = jsonObject.getJSONArray("materialIds");
        List<String> materialIdList = JSONObject.parseArray(materialIds.toJSONString(), String.class);
        JSONArray amounts = jsonObject.getJSONArray("amounts");
        List<String> amountList = JSONObject.parseArray(amounts.toJSONString(), String.class);

        String orderId = jsonObject.getString("orderId");
        //获取到所有选择的的材料信息
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("material_id", materialIdList);
        List<MaterialInfo> materialInfoList = iMaterialInfoService.list(queryWrapper);
        //构建插入选择的出库材料信息
        int i = 0;
        int materialLen = materialInfoList.size();
        List<MaterialOrder> materialOrders = new ArrayList<>();
        while (i < materialLen){
            MaterialOrder materialOrder = new MaterialOrder();
            materialOrder.setMaterialId(materialInfoList.get(i).getMaterialId());
            materialOrder.setMaterialName(materialInfoList.get(i).getMaterialName());
            materialOrder.setMaterialPrice(materialInfoList.get(i).getMaterialPrice());
            materialOrder.setMaterialMertic(materialInfoList.get(i).getMaterialMetric());
            int num = materialIdList.indexOf(materialInfoList.get(i).getMaterialId());
            materialOrder.setMaterialCount(Integer.valueOf(amountList.get(num)));
            materialOrder.setOrderId(orderId);
            materialOrder.setMaterialType(materialInfoList.get(i).getMaterialType().toString());
            materialOrder.setMaterialBrand(materialInfoList.get(i).getMaterialBrand());
            materialOrders.add(materialOrder);
            i ++;
        }
        System.out.println(materialOrders);
        //插入选择的出库材料信息
        iMaterialOrderService.saveBatch(materialOrders);
        return Result.ok().message("返库订单材料添加");
    }
}

