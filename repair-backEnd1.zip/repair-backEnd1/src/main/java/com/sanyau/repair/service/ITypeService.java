package com.sanyau.repair.service;

import com.sanyau.repair.entity.Type;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
public interface ITypeService extends IService<Type> {
    List<Type> returnAllTypes();
}
