package com.sanyau.repair.utils;


import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.Order;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class AbnormalUtils {
    public static String KEY_SHA = "repair";

    /*
     * 生成订单Id的函数
     * 具体实现看后序标准
     *
     * */
    public static Long getOrderIdByTime() {
        Long aLong = Long.valueOf(String.valueOf(new Date().getTime()).substring(4, 13));
        try {
            TimeUnit.MILLISECONDS.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return aLong;
    }

    /*
     * 将请求参数中获取到的值赋值到需要提交的order上
     * */
    public static void setOrderParam(AbnormalOrder abnormal, Order order) {
        Random random = new Random();
        abnormal.setOrderId(order.getOrderId());//订单id编号
        abnormal.setCreateTime(order.getOrderCreateTime());//创建时间
        abnormal.setReturnTime(new Date());//返回时间
        abnormal.setReturnName(order.getUserName());//撤回订单姓名
        abnormal.setRequestName(order.getUserName());
        abnormal.setReason("撤回");//撤回理由
        abnormal.setImage(order.getPictureUser());//撤回图片
        abnormal.setAbnType(order.getRepairType());//订单类型
        abnormal.setPictureStu(order.getPictureUser());//撤回图片
        abnormal.setState("1");
        abnormal.setRequestPhone("");
        abnormal.setReturnPhone(order.getUserPhone());
        abnormal.setStudentId(order.getUserId());
        abnormal.setRequestAddress(order.getUserCommunity());
        abnormal.setStuDesc(order.getUserDesc());//描述信息

    }


}
