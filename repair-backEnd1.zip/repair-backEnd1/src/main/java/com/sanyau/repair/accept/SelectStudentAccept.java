package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class SelectStudentAccept {

    private String building;

    private String apartment;

    private String college;

    private String classRoom;

    private Long[] createTime;

    private String studentId;

    private String StudentName;

    private String phone;

}
