package com.sanyau.repair.controller;


import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.ITypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/type")
public class MasTypeController {
    @Autowired
    private ITypeService typeService;

    @RequestMapping("/selectAllOrderType")
    public Result getAllOrderType(){
        return Result.ok().data("typeList",typeService.returnAllTypes());
    }

}

