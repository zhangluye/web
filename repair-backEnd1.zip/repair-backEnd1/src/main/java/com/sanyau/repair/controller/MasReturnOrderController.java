package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.InsertReturnOrderAccept;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IReturnOrderService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/return-order")
public class MasReturnOrderController {

    @Autowired
    public IReturnOrderService iReturnOrderService;


    @ApiOperation(value = "返库订单展示")
    @PostMapping("showOrder")
    public Result showOrder(@RequestBody JSONObject jsonObject){
        String account = jsonObject.getString("account");
        QueryWrapper<ReturnOrder> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("master_account", account).orderByDesc("create_time");
        List<ReturnOrder> returnOrders = iReturnOrderService.list(queryWrapper);
        return Result.ok().data("返库订单展示", returnOrders);
    }

    @ApiOperation(value = "添加返库订单")
    @PostMapping("/insertOrder")
    public Result insertOrder(@RequestBody InsertReturnOrderAccept insertReturnOrderAccept) {
        boolean b = iReturnOrderService.insertReturnOrder(insertReturnOrderAccept);
        if (b){
            return Result.ok().message("返库订单提交成功");
        }else {
            return Result.error("返库操作失败");
        }
    }


}

