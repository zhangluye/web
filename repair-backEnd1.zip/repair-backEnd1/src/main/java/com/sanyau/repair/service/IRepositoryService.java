package com.sanyau.repair.service;

import com.sanyau.repair.entity.Repository;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-23
 */
public interface IRepositoryService extends IService<Repository> {
    /**
     * 查看全部仓库
     */
    Map<String,Object> selectAllRepository(Long current,Long limit,String repoId);

    /**
     * 查看单个仓库
     * @return
     */
    Map<String,Object> selectOneRepository(String repoId);
}
