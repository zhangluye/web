package com.sanyau.repair.controller;


import com.sanyau.repair.accept.AdminAccept;
import com.sanyau.repair.accept.SelectAdminAccept;
import com.sanyau.repair.accept.SelectManyAccept;
import com.sanyau.repair.entity.AbnormalOrder;
import com.sanyau.repair.entity.Admin;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.impl.AdminRoleServiceImpl;
import com.sanyau.repair.service.impl.AdminServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/repair/admin")
public class AdminController {
    @Autowired
    private AdminServiceImpl adminService;


    @ApiOperation("查询所有用户信息")
    @PostMapping("/selectAllAdmin")
    public Result selectAllAdmin(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                 @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                 @RequestBody SelectAdminAccept selectAdminAccept){
        Map<String, Object> map = adminService.selectAllAdmin(current, limit,selectAdminAccept);
        return Result.ok().data(map);
    }

    @ApiOperation("新增管理员信息")
    @PostMapping("/insertAdmin")
    @Transactional
    public Result insertAdmin(@RequestBody AdminAccept adminAccept){
        Boolean aBoolean = adminService.insertAdmin(adminAccept);
        if(aBoolean){
            return Result.ok();
        }
        return Result.error("添加管理员失败");
    }

    @ApiOperation("更新用户信息")
    @PostMapping("/updateAdmin")
    public Result updateAdmin(@RequestBody AdminAccept adminAccept){
        Boolean aBoolean = adminService.updateAdmin(adminAccept);
        if (aBoolean){
            return Result.ok();
        }else{
            return Result.error("更新用户失败");
        }
    }

    @ApiOperation("删除管理员信息")
    @PostMapping("/deleteAdmin")
    public Result deleteAdmin(@RequestParam("account") String account){
        Boolean deleteAdmin = adminService.deleteAdmin(account);
        if (deleteAdmin){
            return Result.ok();
        }else {
            return Result.error("删除用户失败");
        }
    }

    @ApiOperation("修改管理员权限")
    @PostMapping("/updatePower")
    public Result updatePower(@RequestParam("power") String power,@RequestParam("account") String account){
        Boolean updatePower = adminService.updatePower(power, account);
        if(updatePower){
            return Result.ok();
        }else{
            return Result.error("更新用户权限失败");
        }
    }

    @ApiOperation("查询单个管理员信息")
    @PostMapping("/selectOneAdmin")
    public Result selectOneAdmin(@RequestParam("account") String account){
        Map<String, Object> map = adminService.selectOneAdmin(account);
        return Result.ok().data(map);
    }

    @ApiOperation("多条件查询管理员信息")
    @PostMapping("selectManyAdmin")
    public Result selectManyAdmin(@RequestBody SelectManyAccept selectManyAccept){
        Map<String, Object> map = adminService.selectManyAdmin(selectManyAccept);
        return Result.ok().data(map);
    }

    @ApiOperation("修改密码")
    @PostMapping("/updatePassword")
    public Result updatePassword(@RequestParam("password") String password,@RequestParam("newPassword") String newPassword){
        boolean b = adminService.updatePassword(password, newPassword);
        if(b){
            return Result.ok().message("密码修改成功");
        }else {
            return Result.error("密码修改失败，请确认原密码");
        }
    }
    @ApiOperation("/批量删除管理员信息")
    @PostMapping("/deleteAdmins")
    public Result deleteAdmins(@RequestBody List<String> admins){
        Map<String, Object> map = adminService.deleteAdmins(admins);
        return Result.ok().data(map);
    }
    @ApiOperation("查看管理员权限")
    @PostMapping("/selectPower")
    public Result selectPower(){
        Map<String, Object> map = adminService.selectPower();
        return Result.ok().data(map);
    }
}

