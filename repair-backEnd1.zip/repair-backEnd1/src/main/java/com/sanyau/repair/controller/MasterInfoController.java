package com.sanyau.repair.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.*;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.IMasterInfoService;
import com.sanyau.repair.service.IOrderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-20
 */
@RestController
@RequestMapping("/repair/master-info")
public class MasterInfoController {

    @Autowired
    private IMasterInfoService masterInfoService;

    @Autowired
    private IBuildingService buildingService;

    @Autowired
    private IOrderService orderService;

    @ApiOperation("查询全部师傅信息")
    @PostMapping("/selectAllMaster")
    public Result selectAllMaster(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                  @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                  @RequestBody SelectMasterAccept selectMasterAccept) {
        return Result.ok().data(masterInfoService.selectMaster(current, limit,selectMasterAccept));
    }

    @ApiOperation("增加师傅信息")
    @PostMapping("/insertMaster")
    public Result insertMaster(@RequestBody MasterAccept masterAccept) {
        boolean b = masterInfoService.insertMaster(masterAccept);
        if (b) {
            return Result.ok().message("添加师傅信息成功");
        } else {
            return Result.error("添加信息失败，请重试");
        }
    }

    @ApiOperation("删除师傅信息")
    @PostMapping("/deleteMaster")
    public Result deleteMaster(@RequestParam("account") String account){
        boolean b = masterInfoService.deleteMaster(account);
        if (b) {
            return Result.ok().message("删除师傅信息成功");
        } else {
            return Result.error("删除信息失败，请重试");
        }
    }

    @ApiOperation("修改师傅信息")
    @PostMapping("/updateMaster")
    public Result updateMaster(@RequestBody UpdateMasterAccept updateMasterAccept){
        boolean b = masterInfoService.updateMaster(updateMasterAccept);
        if (b) {
            return Result.ok().message("修改师傅信息成功");
        } else {
            return Result.error("修改信息失败，请重试");
        }
    }

    @ApiOperation("添加师傅负责区域")
    @PostMapping("/addMasterCommunity")
    public Result addMasterCommunity(@RequestParam("account") String account, @RequestParam("communities") List<Integer> communities){
        boolean b = masterInfoService.addMasterCommunity(account, communities);
        if (b) {
            return Result.ok().message("添加师傅负责区域成功");
        } else {
            return Result.error("添加师傅负责区域失败！！！！！");
        }
    }

    @ApiOperation("添加师傅维修类型")
    @PostMapping("/addMasterRepair")
    public Result addMasterRepair(@RequestParam("account") String account, @RequestParam("repairs") List<Integer> repairs){
        boolean b = masterInfoService.addMasterRepair(account, repairs);
        if (b) {
            return Result.ok().message("添加师傅维修类型成功");
        } else {
            return Result.error("添加师傅维修类型失败！！！！！");
        }
    }
    @ApiOperation("删除师傅维修类型")
    @PostMapping("/deleteRepair")
    public Result deleteRepairs(@RequestParam("account") String account, @RequestParam("repairs") List<Integer> repairs){
        boolean b = masterInfoService.deleteMaterialRepair(account, repairs);
        if (b) {
            return Result.ok().message("删除师傅维修类型成功");
        } else {
            return Result.error("删除师傅维修类型失败！！！！！");
        }
    }
    @ApiOperation("删除师傅负责区域")
    @PostMapping("/deleteCommunity")
    public Result deleteCommunity(@RequestParam("account") String account, @RequestParam("repairs") List<Integer> community){
        boolean b = masterInfoService.deleteMaterialCommunity(account, community);
        if (b) {
            return Result.ok().message("删除师傅负责区域成功");
        } else {
            return Result.error("删除师傅负责区域失败！！！！！");
        }
    }


    @ApiOperation("查看单个师傅信息")
    @PostMapping("/selectOneMaster")
    public Result selectOneMaster(@RequestParam("account") String account){
        ReturnMasterAccept masterAccept = masterInfoService.selectOneMaster(account);
        Map<String,Object> map = new HashMap<>();
        map.put("master",masterAccept);
        return Result.ok().data(map);
    }
    @ApiOperation("查看师傅负责区域")
    @PostMapping("/selectMasterCommunity")
    public Result selectMasterCommunity(@RequestParam("account")String account){
        List<Building> buildings = masterInfoService.selectBuilding(account);
        Map<String,Object> map = new HashMap<>();
        map.put("buildings",buildings);
        return Result.ok().data(map);
    }
    @ApiOperation("查看师傅负责类型")
    @PostMapping("/selectMasterRepair")
    public Result selectMasterRepair(@RequestParam("account")String account){
        List<Details> details = masterInfoService.selectDetails(account);
        Map<String,Object> map = new HashMap<>();
        map.put("details",details);
        return Result.ok().data(map);
    }

    @ApiOperation("更新师傅全部负责区域")
    @PostMapping("/updateRepairCommunity")
    public Result updateRepairCommunity(@RequestParam("account") String account, @RequestBody List<String> communities){
        boolean b = masterInfoService.updateRepairCommunity(account, communities);
        if (b) {
            return Result.ok().message("师傅负责区域全部更新");
        } else {
            return Result.error("更新师傅负责区域失败！！！！！");
        }
    }

    @ApiOperation("更新师傅全部维修类型")
    @PostMapping("/updateRepairType")
    public Result updateRepairType(@RequestParam("account") String account, @RequestBody List<String> repair){
        boolean b = masterInfoService.updateRepairType(account, repair);
        if (b) {
            return Result.ok().message("师傅维修类型全部更新");
        } else {
            return Result.error("更新师傅维修类型失败！！！！！");
        }
    }

    @ApiOperation("批量删除师傅信息")
    @PostMapping("/deleteMasters")
    public Result deleteMasters(@RequestBody  List<String> masterInfos){
        Map<String, Object> map = masterInfoService.deleteMasters(masterInfos);
        return Result.ok().data(map);
    }

    @ApiOperation("/查询全部师傅账号展示")
    @PostMapping("/selectAllAccount")
    public Result selectAllAccount(){
        List<MasterInfo> list = masterInfoService.list();
        List<String> masterNames = new ArrayList<>();
        for(MasterInfo masterInfo:list){
            masterNames.add(masterInfo.getAccount());
        }
        return Result.ok().data(masterNames);
    }
    @ApiOperation("修改师傅密码")
    @PostMapping("/updatePassword")
    public Result updatePassword(@RequestBody UpdateMasterPW updateMasterPW){
        boolean b = masterInfoService.updateMasterPassword(updateMasterPW);
        if(b){
            return Result.ok().message("修改师傅密码成功");
        }else {
            return Result.error("修改师傅密码失败");
        }
    }

}

