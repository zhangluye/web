package com.sanyau.repair.service;

import com.sanyau.repair.accept.*;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.DeliveryOrder;
import com.sanyau.repair.entity.Details;
import com.sanyau.repair.entity.MasterInfo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IMasterInfoService extends IService<MasterInfo> {
    /**
     * 查看去全部师傅信息
     */
    Map<String,Object> selectMaster(Long current, Long limit, SelectMasterAccept selectMasterAccept);
    /**
     * 更新师傅信息
     */
    boolean updateMaster(UpdateMasterAccept updateMasterAccept);
    /**
     * 添加师傅信息
     */
    boolean insertMaster(MasterAccept masterAccept);
    /**
     * 删除师傅信息
     */
    boolean deleteMaster(String account);

    /**
     * 查看单个师傅信息
     */
    ReturnMasterAccept selectOneMaster(String account);
    /**
     * 增加师傅维修区域
     */
    boolean addMasterCommunity(String account,List<Integer> community);
    /**
     * 增加师傅维修类型
     */
    boolean addMasterRepair(String account,List<Integer> repairs);
    /**
     * 删除师傅负责区域
     */
    boolean deleteMaterialCommunity(String account,List<Integer> community);
    /**
     * 删除师傅负责类型
     */
    boolean deleteMaterialRepair(String account,List<Integer> repair);
    /**
     * 修改师傅维修区域信息
     */
    boolean updateRepairCommunity(String account,List<String> community);
    /**
     * 修改师傅维修类型
     */
    boolean updateRepairType(String account,List<String> repairs);
    /**
     * 批量删除师傅信息
     */
    Map<String, Object> deleteMasters(List<String> masterInfos);

    /**
     * 按account筛选师傅信息
     * @return
     */
    MasterInfo selectByAccount(String account);

    /**
     * 按account展示师傅维修区域
     * @return
     */
    List<Building> selectBuilding(String account);

    /**
     * 按account展示师傅维修类型
     * @return
     */
    List<Details> selectDetails(String account);
    /**
     * 更改师傅密码
     */
    boolean updateMasterPassword(UpdateMasterPW updateMasterPW);

}
