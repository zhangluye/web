package com.sanyau.repair.controller;


import com.sanyau.repair.entity.MaterialType;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialTypeService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-06
 */
@RestController
@RequestMapping("/mas/repair/material-type")
public class MasMaterialTypeController {

    @Autowired
    public IMaterialTypeService iMaterialTypeService;

    @ApiOperation(value = "材料类型展示")
    @PostMapping("showType")
    public Result showType(){
        List<MaterialType> materialTypes = iMaterialTypeService.list();
        return Result.ok().data("MaterialType", materialTypes);
    }

}

