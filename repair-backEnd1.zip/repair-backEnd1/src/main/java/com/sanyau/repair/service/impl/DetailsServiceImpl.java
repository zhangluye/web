package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.accept.DetailsAccept;
import com.sanyau.repair.accept.UpdateDetailsAccept;
import com.sanyau.repair.entity.Details;
import com.sanyau.repair.entity.Type;
import com.sanyau.repair.mapper.DetailsMapper;
import com.sanyau.repair.service.IDetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.service.ITypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
@Service
public class DetailsServiceImpl extends ServiceImpl<DetailsMapper, Details> implements IDetailsService {

    @Autowired
    private IDetailsService detailsService;
    @Autowired
    private ITypeService typeService;
    @Override
    public boolean insertDetails(DetailsAccept detailsAccept) {
        Type repair_type = typeService.getOne(new QueryWrapper<Type>().eq("repair_type", detailsAccept.getRepairType()));
        Details repair_details = detailsService.getOne(new QueryWrapper<Details>().eq("repair_details", detailsAccept.getRepairDetails()));
        Type type = new Type();
        Details details = new Details();
        if(repair_type==null&&detailsAccept.getRepairType()!=null){
            type.setRepairType(detailsAccept.getRepairType());
            typeService.save(type);
        }
        if(repair_details==null&&detailsAccept.getRepairDetails()!=null){
            details.setRepairDetails(detailsAccept.getRepairDetails());
            details.setRepairType(type.getId());
            detailsService.save(details);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean updateDetails(UpdateDetailsAccept detailsAccept) {
        Type type = typeService.getOne(new QueryWrapper<Type>().eq("id", detailsAccept.getRepairId()));
        Details details = detailsService.getOne(new QueryWrapper<Details>().eq("id",detailsAccept.getDetailsId()));
        if(type!=null){
            type.setRepairType(detailsAccept.getRepairType());
            typeService.updateById(type);
        }
        if(details!=null){
            details.setRepairDetails(detailsAccept.getRepairDetails());
            details.setRepairType(type.getId());
            detailsService.updateById(details);
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean deleteDetails(Integer ids) {
        return detailsService.removeById(ids);
    }

    @Override
    public Map<String, Object> selectDetails() {
        List<Type> list = typeService.list();
        List<Details> details = new ArrayList<>();
        Map<String,Object> map = new HashMap<>();
        for(Type type :list){
            List<Details> repair_type = detailsService.list(new QueryWrapper<Details>().eq("repair_type", type.getId()));
            map.put(type.getRepairType(),repair_type);
        }
        return map;
    }
}
