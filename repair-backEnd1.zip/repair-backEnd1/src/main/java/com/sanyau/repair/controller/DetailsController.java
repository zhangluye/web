package com.sanyau.repair.controller;


import com.sanyau.repair.accept.DetailsAccept;
import com.sanyau.repair.accept.UpdateDetailsAccept;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IDetailsService;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-19
 */
@RestController
@RequestMapping("/repair/details")
public class DetailsController {

    @Autowired
    private IDetailsService detailsService;
    @ApiOperation("添加维修类型")
    @PostMapping("/insertDetails")
    public Result insertDetails(@RequestBody DetailsAccept detailsAccept){
        boolean b = detailsService.insertDetails(detailsAccept);
        if(b){
            return Result.ok().message("添加维修类型成功");
        }else {
            return Result.error("添加材料失败");
        }
    }

    @ApiOperation("修改材料类型")
    @PostMapping("/updateDetails")
    public Result updateDetails(@RequestBody UpdateDetailsAccept updateDetailsAccept){
        boolean b = detailsService.updateDetails(updateDetailsAccept);
        if(b){
            return Result.ok().message("修改维修类型成功");
        }else {
            return Result.error("修改材料失败");
        }
    }

    @ApiOperation("删除维修类型")
    @PostMapping("/deleteDetails")
    public Result deleteDetails(@RequestParam("id") Integer id){
        boolean b = detailsService.deleteDetails(id);
        if(b){
            return Result.ok().message("删除维修类型成功");
        }else {
            return Result.error("删除材料失败");
        }
    }

    @ApiOperation("查询全部维修类型")
    @PostMapping("/selectDetails")
    public Result selectDetails(){
        return Result.ok().data(detailsService.selectDetails());
    }

}

