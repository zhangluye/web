package com.sanyau.repair.service;

import com.sanyau.repair.accept.CancelOrderAccept;
import com.sanyau.repair.accept.FinishOrderAccept;
import com.sanyau.repair.accept.SelectOrderAccept;
import com.sanyau.repair.accept.SelectTaskQueryAccept;
import com.sanyau.repair.entity.DeliveryOrder;
import com.sanyau.repair.entity.Order;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-21
 */
public interface IOrderService extends IService<Order> {
    /**
     * 查看所有订单
     * @return
     */
    Map<String,Object> selectAllOrder(Long current, Long limit, SelectOrderAccept selectOrderAccept, Integer sate);
    /**
     * 用于批量导出的查看全部订单
     */
    Map<String,Object> selectAllOrderByE();

    /**
     * 删除订单
     * @param oderId
     * @return
     */
    boolean deleteOrder(String oderId);

    /**
     * 查看订单附带材料信息
     * @param oderId
     * @return
     */
    Map<String,Object> selectOrderMaterial(String oderId);

    /**
     * 批量删除总订单信息
     * @return
     */
    Map<String, Object> deleteOrders(List<String> orders);

    /**
     * 查看订单学生上传图片
     */
    Map<String,Object> selectPic(String orderId);

    /*
        分页查询报修单
     */
    Map<String,Object> getOrder(Long current,Long limit);
    /*
        查询已接单订单
     */
    Map<String,Object> selectAcceptOrder(long current,long limit);

    /*
    查询未接单订单
 */
    Map<String,Object> selectUnAcceptOrder(long current,Long limit);
    /*
        根据id获取order订单对象
     */
    Order selectOrderById(String order_id);

    /*
        返回去重的订单楼号
     */
    List<String> getAllCommunity();
    /*
        返回去重的已接单订单楼号
    */
    List<String> getAcceptCommunity();
    /*
        返回去重的未接单订单楼号
    */
    List<String> getUnAcceptCommunity();
    /**
     * 按orderId筛选订单
     * @return
     */
    Order selectByOrderId (String orderId);

    /**
     * 按orderId筛选订单
     * @return
     */


    /**
     * suixin
     * 展示师傅
     */
    Map<String,Object> showMasterCommunity(String account);
    /**
     * suixin
     * 根据楼号筛选订单
     */
    Map<String,Object> orderScreeningToBuildingS(int id,int state);
    /**
     * suixin
     * 展示师傅负责区域信息
     */
    Map<String,Object> showMasterOrder(String account,String state);
    /**
     * suixin
     * 取消订单
     */
    boolean cancelOrder(CancelOrderAccept cancelOrderAccept);
    /**
     * suixin
     * 完成订单
     */
    boolean finishOrder(FinishOrderAccept finishOrderAccept);
    /**
     * suixin
     * 订单任务查询
     */
    Map<String,Object> TaskQuery(SelectTaskQueryAccept selectTaskQueryAccept);
    /**
     * suixin
     * 展示师傅负责的维修类型
     */
    Map<String,Object> showMasterRepairType(String account);
    /**
     * 展示师傅异常订单
     */
    Map<String,Object> showAbnormalOrder(String account);
    /**
     * 根据负责楼号查询师傅负责的异常订单
     */
    Map<String,Object> showAbnormalOrderByBuilding(String account,String community);
    /**
     * 展示单个异常订单
     */
    Map<String,Object> showOneAbnormalOrder(String orderId);
    /**
     * 根据订单查看材料
     */
    Map<String,Object> selectByOrder(String orderId);

}
