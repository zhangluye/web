package com.sanyau.repair.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.MaterialGroup;
import com.sanyau.repair.mapper.MaterialGroupMapper;
import com.sanyau.repair.response.Result;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-20
 */
@RestController
@RequestMapping("/repair/material-group")
public class MaterialGroupController {
    @Autowired
    private MaterialGroupMapper materialGroupMapper;

    @ApiOperation("返回材料小类")
    @PostMapping("materialgroups.all")
    public Result getMaterialGroup(){
        QueryWrapper<MaterialGroup> wrapper = new QueryWrapper<>();
        wrapper.select("material_group_name");
        List<MaterialGroup> materialGroups = materialGroupMapper.selectList(wrapper);
        if (materialGroups.isEmpty()){
            return Result.error("材料小类结果为空");
        }
        return Result.ok().data("materialGroups",materialGroups);
    }
}

