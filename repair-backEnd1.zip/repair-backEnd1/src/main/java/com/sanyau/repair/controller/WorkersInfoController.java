package com.sanyau.repair.controller;


import com.sanyau.repair.accept.SelectWorkersAccept;
import com.sanyau.repair.accept.UpdateWorkersAccept;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IWorkersInfoService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/workers-info")
public class WorkersInfoController {

    @Autowired
    private IWorkersInfoService workersInfoService;

    @ApiOperation("查询职工信息")
    @PostMapping("/selectWorkers")
    public Result selectWorkers(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                @RequestBody SelectWorkersAccept selectWorkersAccept){
        Map<String, Object> map = workersInfoService.selectWorkers(current, limit,selectWorkersAccept);
        return Result.ok().data(map);
    }
    @ApiOperation("更新职工信息")
    @PostMapping("/updateWorkers")
    public Result updateWorkers(@RequestBody UpdateWorkersAccept updateWorkersAccept){
        boolean b = workersInfoService.updateWorkers(updateWorkersAccept);
        if (b){
            return Result.ok().message("更新职工信息成功");
        }else {
            return Result.error("更新职工信息失败");
        }
    }

    @ApiOperation("删除职工信息")
    @PostMapping("/deleteWorkers")
    public Result deleteWorkers(@RequestParam("workersId") int workersId){
        boolean b = workersInfoService.deleteWorkers(workersId);
        if (b){
            return Result.ok().message("删除职工信息成功");
        }else {
            return Result.error("删除职工信息失败");
        }
    }

    @ApiOperation("批量删除职工信息")
    @PostMapping("/deleteWorkersTo")
    public Result deleteReturnOrders(@RequestBody List<Integer> workersId){
        Map<String, Object> map = workersInfoService.deleteWorkersTo(workersId);
        return Result.ok().data(map);
    }

}

