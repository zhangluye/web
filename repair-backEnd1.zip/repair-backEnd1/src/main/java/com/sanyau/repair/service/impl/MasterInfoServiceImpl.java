package com.sanyau.repair.service.impl;

import ch.qos.logback.core.joran.util.beans.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.*;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.MasterInfoMapper;
import com.sanyau.repair.service.*;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sanyau.repair.utils.IDUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class MasterInfoServiceImpl extends ServiceImpl<MasterInfoMapper, MasterInfo> implements IMasterInfoService {
    @Autowired
    private IMasterInfoService masterInfoService;

    @Autowired
    private IBuildingService buildingService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private IDetailsService detailsService;

    @Autowired
    private IRepositoryService repositoryService;

    @Override
    public Map<String, Object> selectMaster(Long current, Long limit, SelectMasterAccept selectMasterAccept) {
        Page<MasterInfo> masterInfoPage = new Page<>(current,limit);
        masterInfoService.page(masterInfoPage,selectMasters(selectMasterAccept).orderByDesc("create_time"));
        long adminTotal = masterInfoPage.getTotal();
        List<MasterInfo> records = masterInfoPage.getRecords();//数据list集合
        List<ReturnMasterInfoAccept> returnMasterInfoAccepts = new ArrayList<>();
        List<String> communities = new ArrayList<>();
        List<String> repairs = new ArrayList<>();
        for(MasterInfo masterInfo:records){
            ReturnMasterInfoAccept returnMasterInfoAccept = new ReturnMasterInfoAccept();
            BeanUtils.copyProperties(masterInfo,returnMasterInfoAccept);
            List<Details> repairType = detailsService.list(new QueryWrapper<Details>().eq("master_account", masterInfo.getAccount()));
            for (Details details : repairType) {
                communities.add(details.getRepairDetails());
            }
            List<Building> community = buildingService.list(new QueryWrapper<Building>().eq("master_account", masterInfo.getAccount()));
            for (Building building : community) {
                repairs.add(building.getBuildingName());
            }
            returnMasterInfoAccept.setRepairType(communities);
            returnMasterInfoAccept.setCommunity(repairs);
            returnMasterInfoAccepts.add(returnMasterInfoAccept);
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", adminTotal);
        map.put("master", returnMasterInfoAccepts);
        return map;
    }

    @Override
    public boolean updateMaster(UpdateMasterAccept updateMasterAccept) {
        MasterInfo masterInfo = new MasterInfo();
        masterInfo.setMasterName(updateMasterAccept.getMasterName());
        masterInfo.setMasterPhone(updateMasterAccept.getMasterPhone());
        return masterInfoService.update(masterInfo,new QueryWrapper<MasterInfo>().eq("account",updateMasterAccept.getAccount()));
    }

    @Override
    public boolean insertMaster(MasterAccept masterAccept) {
        MasterInfo account = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", masterAccept.getAccount()));
        if(account!=null){
            return false;
        }
        MasterInfo masterInfo = new MasterInfo();
        BeanUtils.copyProperties(masterAccept,masterInfo);
        masterInfo.setMasterRepository(IDUtils.getId());
        if(masterAccept.getMasterCommunity()!=null){
            for(String s:masterAccept.getMasterCommunity()){
                Building building_name = buildingService.getOne(new QueryWrapper<Building>().eq("building_name", s));
                building_name.setMasterAccount(masterInfo.getAccount());
                buildingService.updateById(building_name);
            }
        }
        if(masterAccept.getMasterRepairType()!=null){
            for(String s:masterAccept.getMasterRepairType()){
                Details repair_details = detailsService.getOne(new QueryWrapper<Details>().eq("repair_details", s));
                repair_details.setMasterAccount(masterInfo.getAccount());
                detailsService.updateById(repair_details);
            }
        }
        masterInfo.setPassword(IDUtils.encodePassword(masterInfo.getPassword()));
        masterInfo.setCreateTime(new Date());
        Repository repository = new Repository();
        repository.setRepoId(IDUtils.getId());
        repository.setMasterAccount(masterInfo.getAccount());
        repository.setCreateTime(new Date());
        repository.setId(null);
        repositoryService.save(repository);
        return masterInfoService.save(masterInfo);
    }

    @Override
    public boolean deleteMaster(String account) {
        List<Details> master_account = detailsService.list(new QueryWrapper<Details>().eq("master_account", account));
        List<Building> master_account1 = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        if(master_account!=null||master_account1!=null){
            return false;
        }else {
            return masterInfoService.remove(new QueryWrapper<MasterInfo>().eq("account",account));
        }
    }

    @Override
    public ReturnMasterAccept selectOneMaster(String account) {
        ReturnMasterAccept masterAccept = new ReturnMasterAccept();
        MasterInfo masterInfo = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", account));
        BeanUtils.copyProperties(masterInfo,masterAccept);
        List<Building> master_account = buildingService.list(new QueryWrapper<Building>().eq("master_account", masterInfo.getAccount()));
        List<String> community = new ArrayList<>();
        for (Building building : master_account) {
            community.add(building.getBuildingName());
        }
        masterAccept.setMasterCommunity(community);
        List<Details> master_account1 = detailsService.list(new QueryWrapper<Details>().eq("master_account", masterInfo.getAccount()));
        List<String> repair = new ArrayList<>();
        for (Details details : master_account1) {
            repair.add(details.getRepairDetails());
        }
        masterAccept.setMasterRepairType(repair);
        return masterAccept;
    }

    @Override
    public boolean addMasterCommunity(String account, List<Integer> communities) {
        MasterInfo masterInfo = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", account));
        for(int s :communities){
            Building building_name = buildingService.getOne(new QueryWrapper<Building>().eq("id", s));
            if(building_name.getMasterAccount()!=null||!building_name.getMasterAccount().equals("")){
                return false;
            }
            building_name.setMasterAccount(masterInfo.getAccount());
            buildingService.updateById(building_name);
        }
        return true;
    }

    @Override
    public boolean addMasterRepair(String account, List<Integer> repairs) {
        MasterInfo masterInfo = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", account));
        for(int s :repairs){
            Details details = detailsService.getOne(new QueryWrapper<Details>().eq("id", s));
            if(details.getMasterAccount()!=null||!details.getMasterAccount().equals("")){
                return false;
            }else {
                details.setMasterAccount(masterInfo.getAccount());
                detailsService.updateById(details);
            }
        }
        return true;
    }

    @Override
    public boolean deleteMaterialCommunity(String account, List<Integer> community) {
        List<Building> master_account = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        for(Building building :master_account){
            for(int buildingId:community){
                if(building.getId()==buildingId){
                    building.setMasterAccount("");
                    buildingService.updateById(building);
                }
            }
        }
        return true;
    }

    @Override
    public boolean deleteMaterialRepair(String account, List<Integer> repair) {
        List<Details> master_account = detailsService.list(new QueryWrapper<Details>().eq("master_account", account));
        for(Details details :master_account){
            for(int buildingId:repair){
                if(details.getId()==buildingId){
                    details.setMasterAccount("");
                    detailsService.updateById(details);
                }
            }
        }
        return true;
    }

    @Override
    public boolean updateRepairCommunity(String account, List<String> communities) {
        List<Building> master_account = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        if (master_account.size()!=0){
            for (Building building : master_account) {
                building.setMasterAccount("");
                buildingService.updateById(building);
            }
        }
        for(String s :communities){
            Building building_name = buildingService.getOne(new QueryWrapper<Building>().eq("id", s));
            building_name.setMasterAccount(account);
            buildingService.updateById(building_name);
        }
        return true;
    }

    @Override
    public boolean updateRepairType(String account, List<String> repairs) {
        List<Details> details = detailsService.list(new QueryWrapper<Details>().eq("master_account", account));
        if (details.size()!=0){
            for (Details details1 : details) {
                details1.setMasterAccount("");
                detailsService.updateById(details1);
            }
        }
        for(String s :repairs){
            Details details2 = detailsService.getOne(new QueryWrapper<Details>().eq("id", s));
            details2.setMasterAccount(account);
            detailsService.updateById(details2);
        }
        return true;
    }

    @Override
    public Map<String, Object> deleteMasters(List<String> masterInfos) {
        int success = 0;
        int error = 0;
        if(masterInfos.size()!=0){
            for(String masterInfo:masterInfos){
                boolean b = masterInfoService.deleteMaster(masterInfo);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    public QueryWrapper<MasterInfo> selectMasters(SelectMasterAccept selectMasterAccept){
        if (selectMasterAccept==null){
            return new QueryWrapper<MasterInfo>();
        }
        QueryWrapper<MasterInfo> queryWrapper = new QueryWrapper<MasterInfo>();
        if(selectMasterAccept.getAccount()!=null&&!selectMasterAccept.getAccount().equals("")){
            queryWrapper.eq("account",selectMasterAccept.getAccount());
        }
        if(selectMasterAccept.getName()!=null&&!selectMasterAccept.getName().equals("")){
            queryWrapper.eq("master_name",selectMasterAccept.getName());
        }
        if(selectMasterAccept.getCreateTime()!=null){
            queryWrapper.between("create_time",new Date(selectMasterAccept.getCreateTime()[0]),new Date(selectMasterAccept.getCreateTime()[1]));
        }
        if(selectMasterAccept.getPhone()!=null&&!selectMasterAccept.getPhone().equals("")){
            queryWrapper.eq("master_phone",selectMasterAccept.getPhone());
        }
        return queryWrapper;
    }

    @Override
    public MasterInfo selectByAccount(String account){
        MasterInfo masterInfo = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", account));
        return masterInfo;
    }

    @Override
    public List<Building> selectBuilding(String account){
        List<Building> buildings = buildingService.list(new QueryWrapper<Building>().eq("master_account", account));
        return buildings;
    }

    @Override
    public List<Details> selectDetails(String account){
        List<Details> details = detailsService.list(new QueryWrapper<Details>().eq("master_account", account));
        return details;
    }

    @Override
    public boolean updateMasterPassword(UpdateMasterPW updateMasterPW) {
        MasterInfo account = masterInfoService.getOne(new QueryWrapper<MasterInfo>().eq("account", updateMasterPW.getAccount()));
//        boolean matches = bcryptPasswordEncoder.matches(account.getPassword(), updateMasterPW.getPassword());
        boolean matches = passwordEncoder.matches(updateMasterPW.getPassword(), account.getPassword());
        System.out.println(matches);
        if (matches){
            account.setPassword(IDUtils.encodePassword(updateMasterPW.getNewPassword()));
            return masterInfoService.updateById(account);
        }
        return false;
    }

}
