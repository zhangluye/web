package com.sanyau.repair.accept;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class ReturnAbnormalAccept {
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty(value = "异常订单ID")
    private String orderId;

    @ApiModelProperty(value = "异常订单创建时间")
    private Date createTime;

    @ApiModelProperty(value = "异常订单退回时间")
    private Date returnTime;

    @ApiModelProperty(value = "退回订单人")
    private String returnName;

    @ApiModelProperty(value = "报修人")
    private String requestName;

    @ApiModelProperty(value = "问题")
    private String reason;

    @ApiModelProperty(value = "图片")
    private String image;

    @ApiModelProperty(value = "异常订单类型")
    private String abnType;

    @ApiModelProperty(value = "学生报修照片")
    private String pictureStu;

    @ApiModelProperty(value = "异常订单状态")
    private String state;

    @ApiModelProperty(value = "师傅手机号")
    private String returnPhone;

    @ApiModelProperty(value = "报修人手机号")
    private String requestPhone;

    @ApiModelProperty(value = "报修人地址")
    private String requestAddress;

    @ApiModelProperty(value = "学号")
    private String studentId;

    private String stuDesc;

}
