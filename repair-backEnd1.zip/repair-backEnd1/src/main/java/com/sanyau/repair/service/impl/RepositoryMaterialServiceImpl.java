package com.sanyau.repair.service.impl;

import com.sanyau.repair.entity.RepositoryMaterial;
import com.sanyau.repair.mapper.RepositoryMaterialMapper;
import com.sanyau.repair.service.IRepositoryMaterialService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-23
 */
@Service
public class RepositoryMaterialServiceImpl extends ServiceImpl<RepositoryMaterialMapper, RepositoryMaterial> implements IRepositoryMaterialService {

}
