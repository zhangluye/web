package com.sanyau.repair.service;

import com.sanyau.repair.accept.SelectStudentAccept;
import com.sanyau.repair.entity.StudentInfo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
public interface IStudentInfoService extends IService<StudentInfo> {

    /**
     * 查询学生信息
     */
    Map<String,Object> selectStudent(Long current,Long limit, SelectStudentAccept selectStudentAccept);

    /**
     * 修改学生信息
     */
    boolean updateStudent(int id,SelectStudentAccept selectStudentAccept);

    /**
     * 批量删除学生信息
     */
    Map<String, Object> deleteStudents(List<Integer> ids);

    /**
     * 删除学生信息
     */
    boolean deleteStudent(int id);

}
