package com.sanyau.repair.controller;


import com.sanyau.repair.accept.MaterialAccept;
import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IMaterialInfoService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@RestController
@RequestMapping("/repair/material-info")
public class MaterialInfoController {
    @Autowired
    private IMaterialInfoService materialInfoService;

    @ApiOperation("增加材料")
    @PostMapping("/insertMaterial")
    public Result insertMaterial(@RequestBody List<MaterialAccept> materialAccepts) {
        boolean b = materialInfoService.insertMaterial(materialAccepts);
        if(b){
            return Result.ok().message("添加材料信息成功");
        }else {
            return Result.error("添加材料失败");
        }
    }

    @ApiOperation("修改材料信息")
    @PostMapping("/updateMaterial")
    public Result updateMaterial(@RequestBody MaterialInfo materialInfo){
        boolean b = materialInfoService.updateMaterial(materialInfo);
        if(b){
            return Result.ok().message("更新材料信息成功");
        }else {
            return Result.error("更新材料失败");
        }
    }
    @ApiOperation("删除材料")
    @PostMapping("/deleteMaterial")
    public Result deleteMaterial(@RequestParam("materialId") String materialId){
        boolean b = materialInfoService.deleteMaterial(materialId);
        if(b){
            return Result.ok().message("删除材料信息成功");
        }else {
            return Result.error("删除材料失败");
        }
    }

    @ApiOperation("查看材料信息")
    @PostMapping("/selectMaterial")
    public Result selectMaterial(@ApiParam(name = "current", value = "当前页", required = true) @RequestParam("current") Long current,
                                 @ApiParam(name = "limit", value = "每页数据量", required = true) @RequestParam("limit") Long limit,
                                 @RequestParam("materialId") String materialId){
        Map<String, Object> map = materialInfoService.selectMaterial(current, limit,materialId);
        return Result.ok().data(map);
    }

    @ApiOperation("用于批量导出的")
    @PostMapping("/selectAllMaterial")
    public Result selectAllMaterial(){
        Map<String, Object> map = materialInfoService.selectAllMaterial();
        return Result.ok().data(map);
    }


    @ApiOperation("批量删除材料信息")
    @PostMapping("/deleteMaterialS")
    public Result deleteMaterials(@RequestBody  List<String> materialInfos){
        Map<String, Object> map = materialInfoService.deleteMaterials(materialInfos);
        return Result.ok().data(map);
    }
}

