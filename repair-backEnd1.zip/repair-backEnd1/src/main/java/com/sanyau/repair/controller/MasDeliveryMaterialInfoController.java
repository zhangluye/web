package com.sanyau.repair.controller;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.DeliveryMaterialInfo;
import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.entity.ReturnMaterialInfo;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IDeliveryMaterialInfoService;
import com.sanyau.repair.service.IMaterialInfoService;
import com.sanyau.repair.service.IReturnMaterialInfoService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author WildSky
 * @since 2021-03-04
 */
@RestController
@RequestMapping("/mas/repair/delivery-material-info")
public class MasDeliveryMaterialInfoController {

    @Autowired
    public IDeliveryMaterialInfoService iDeliveryMaterialInfoService;
    @Autowired
    public IMaterialInfoService iMaterialInfoService;

    @ApiOperation(value = "出库订单材料展示")
    @PostMapping("showInfo")
    public Result showInfo(@RequestBody JSONObject jsonObject){
        String deliveryOrderId = jsonObject.getString("deliveryOrderId");
        QueryWrapper<DeliveryMaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("delivery_order_id", deliveryOrderId);
        List<DeliveryMaterialInfo> deliveryMaterialInfos = iDeliveryMaterialInfoService.list(queryWrapper);
        return Result.ok().data("出库订单材料展示", deliveryMaterialInfos);
    }

    @ApiOperation(value = "出库订单材料添加")
    @PostMapping("insertInfo")
    public Result insertInfo(@RequestBody JSONObject jsonObject){
        //获取选择的材料id，材料数量，出库ID
        JSONArray materialIds = jsonObject.getJSONArray("materialIds");
        List<String> materialIdList = JSONObject.parseArray(materialIds.toJSONString(), String.class);
        JSONArray amounts = jsonObject.getJSONArray("amounts");
        List<String> amountList = JSONObject.parseArray(amounts.toJSONString(), String.class);
        String deliveryOrderId = jsonObject.getString("deliveryOrderId");
        //获取到所有选择的的材料信息
        QueryWrapper<MaterialInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.in("material_id", materialIdList);
        List<MaterialInfo> materialInfoList = iMaterialInfoService.list(queryWrapper);
        //构建插入选择的出库材料信息
        int i = 0;
        int materialLen = materialInfoList.size();
        List<DeliveryMaterialInfo> deliveryMaterialInfoList = new ArrayList<>();
        while (i < materialLen){
            DeliveryMaterialInfo deliveryMaterialInfo = new DeliveryMaterialInfo();
            deliveryMaterialInfo.setMaterialId(materialInfoList.get(i).getMaterialId());
            deliveryMaterialInfo.setMaterialName(materialInfoList.get(i).getMaterialName());
            int num = materialIdList.indexOf(materialInfoList.get(i).getMaterialId());
            deliveryMaterialInfo.setDeliveryAmount(Integer.valueOf(amountList.get(num)));
            deliveryMaterialInfo.setMaterialMetric(materialInfoList.get(i).getMaterialMetric());
            deliveryMaterialInfo.setMaterialType(materialInfoList.get(i).getMaterialType());
            deliveryMaterialInfo.setMaterialUnitPrice(materialInfoList.get(i).getMaterialPrice());
            deliveryMaterialInfo.setMaterialBrand(materialInfoList.get(i).getMaterialBrand());
            deliveryMaterialInfo.setDeliveryOrderId(deliveryOrderId);
            deliveryMaterialInfo.setDeliveryOrderState(1);
            deliveryMaterialInfoList.add(deliveryMaterialInfo);
            i += 1;
        }

        //插入选择的出库材料信息
        iDeliveryMaterialInfoService.saveBatch(deliveryMaterialInfoList);
        return Result.ok().message("出库订单材料添加");
    }
}

