package com.sanyau.repair.service;

import com.sanyau.repair.accept.CommunityAccept;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sanyau.repair.accept.UpdateCommunityAccept;
import com.sanyau.repair.entity.Community;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-11
 */
public interface ICommunityService extends IService<Community> {

    /**
     * 增加社区信息
     */
    boolean insertCommunity(CommunityAccept communityAccept);

    /**
     * 删除社区信息
     */
    boolean deleteCommunity(CommunityAccept communityAccept);
    /**
     * 查询社区信息
     */
    Map<String,Object> selectCommunity();
    /**
     * 修改社区信息
     */
    boolean updateCommunity(UpdateCommunityAccept communityAccept);
}
