package com.sanyau.repair.accept;

import lombok.Data;

@Data
public class DetailsAccept {

    private String repairType;

    private String repairDetails;
}
