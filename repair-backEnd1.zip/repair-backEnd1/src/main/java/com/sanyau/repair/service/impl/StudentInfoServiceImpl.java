package com.sanyau.repair.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.accept.SelectStudentAccept;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.MaterialInfo;
import com.sanyau.repair.entity.StudentInfo;
import com.sanyau.repair.mapper.StudentInfoMapper;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.IStudentInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author WildSky
 * @since 2021-03-14
 */
@Service
public class StudentInfoServiceImpl extends ServiceImpl<StudentInfoMapper, StudentInfo> implements IStudentInfoService {

    @Autowired
    private IStudentInfoService studentInfoService;
    @Autowired
    private IBuildingService buildingService;

    @Override
    public Map<String, Object> selectStudent(Long current, Long limit, SelectStudentAccept selectStudentAccept) {
        Page<StudentInfo> studentInfoPage = new Page<StudentInfo>(current,limit);
        studentInfoService.page(studentInfoPage,selectStudents(selectStudentAccept).orderByDesc("create_time"));
        long materialTotal = studentInfoPage.getTotal();
        List<StudentInfo> records = studentInfoPage.getRecords();
        for(StudentInfo studentInfo:records){
            Building id = buildingService.getOne(new QueryWrapper<Building>().eq("id", studentInfo.getStudentApartment()));
            studentInfo.setStudentApartment(id.getBuildingName());
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("total", materialTotal);
        map.put("student", records);
        return map;
    }

    @Override
    public boolean updateStudent(int id,SelectStudentAccept selectStudentAccept) {
        StudentInfo studentInfo = new StudentInfo();
        BeanUtils.copyProperties(selectStudentAccept,studentInfo);
        return studentInfoService.update(studentInfo,new QueryWrapper<StudentInfo>().eq("id",id));
    }

    @Override
    public Map<String, Object> deleteStudents(List<Integer> ids) {
        int success = 0;
        int error = 0;
        if(ids.size()!=0){
            for(int id:ids){
                boolean b = studentInfoService.deleteStudent(id);
                if(b){
                    success++;
                }else {
                    error++;
                }
            }
        }
        Map<String,Object> map = new HashMap<>();
        map.put("success",success+"条数据");
        map.put("error",error+"条数据");
        return map;
    }

    @Override
    public boolean deleteStudent(int id) {
        return studentInfoService.remove(new QueryWrapper<StudentInfo>().eq("id",id));
    }

    private QueryWrapper<StudentInfo> selectStudents(SelectStudentAccept selectStudentAccept) {
        QueryWrapper<StudentInfo> queryWrapper = new QueryWrapper<StudentInfo>();
        if (selectStudentAccept==null){
            return queryWrapper;
        }
        if (selectStudentAccept.getStudentId() != null && !selectStudentAccept.getStudentId().equals("")) {
            queryWrapper.eq("student_id",selectStudentAccept.getStudentId());
        }
        if (selectStudentAccept.getStudentName() != null && !selectStudentAccept.getStudentName().equals("")) {
            queryWrapper.eq("student_name",selectStudentAccept.getStudentName());
        }
        if (selectStudentAccept.getApartment() != null && !selectStudentAccept.getApartment().equals("")) {
            queryWrapper.eq("student_dormitory_id",selectStudentAccept.getApartment());
        }
        if (selectStudentAccept.getBuilding() != null && !selectStudentAccept.getBuilding().equals("")) {
            queryWrapper.eq("student_apartment",selectStudentAccept.getBuilding());
        }
        if (selectStudentAccept.getClassRoom() != null && !selectStudentAccept.getClassRoom().equals("")) {
            queryWrapper.eq("student_class",selectStudentAccept.getClassRoom());
        }
        if (selectStudentAccept.getPhone() != null && !selectStudentAccept.getPhone().equals("")) {
            queryWrapper.eq("student_phone",selectStudentAccept.getPhone());
        }
        if (selectStudentAccept.getCollege() != null && !selectStudentAccept.getCollege().equals("")) {
            queryWrapper.eq("student_college",selectStudentAccept.getCollege());
        }
        if(selectStudentAccept.getCreateTime()!=null){
            queryWrapper.between("create_time",new Date(selectStudentAccept.getCreateTime()[0]),new Date(selectStudentAccept.getCreateTime()[1]));
        }
        return queryWrapper;
    }
}
