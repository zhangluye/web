package com.sanyau.repair;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.sanyau.repair.entity.*;
import com.sanyau.repair.mapper.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@SpringBootTest
class RepairApplicationTests {
    @Autowired
    private AdminMapper adminMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private ReturnOrderMapper returnOrderMapper;
    @Autowired
    private MaterialGroupMapper materialGroupMapper;
    @Autowired
    private MaterialOrderMapper materialOrderMapper;

    @Test
    void contextLoads() {
    }


    @Test
    public void AdminSelectTest(){
        List<Admin> adminList = adminMapper.selectList(null);
        adminList.forEach(System.out::println);
    }

    @Test
    public void getAllOrder(){
//        List<Order> orderList = orderService.getBaseMapper().selectList(null);
        List<Order> orderList = orderMapper.selectList(null);
        orderList.forEach(System.out::println);
    }

    @Test
    public void addOrder(){

        Order order = new Order();
        order.setOrderId("orderId");        // 订单id
        order.setOrderCreateTime(new Date());   // 订单创建时间
        order.setOrderPrice(new BigDecimal(0));
        order.setOrderState(0);           // 设置订单状态为1，未接单
        order.setUserDesc("userDesc");
        order.setUserName("userName");
        order.setOrderType("repairType");
        order.setPictureUser("pictureUser");
        order.setGrade(100);
        order.setOrderMoney(new BigDecimal(0));
        order.setUserPhone("userPhone");
        order.setUserCommunity("userCommunity");
        order.setUserId("userId");
        order.setUserApartment("userApartment");
        order.setPayState(0);

        int flag = orderMapper.insert(order);
        if (flag == 0){
            System.out.println("error, 添加订单错误!");
            return;
        }
        System.out.println("success, 添加订单成功!");
    }

    @Test
    public void addReturnOrder(){
            QueryWrapper<Order> wrapper = new QueryWrapper<>();
            wrapper.eq("order_id","orderId");
            Order order = orderMapper.selectOne(wrapper);       // 先根据id获取order订单对象
            order.setMasterAccount("Master_Account");
            HashMap<String, Object> map = new HashMap<>();
            map.put("order_id",order.getOrderId());
            // 插入返库订单数据
            ReturnOrder returnOrder = new ReturnOrder();
            returnOrder.setReturnOrderId(order.getOrderId());   // 设置返库单号为当前订单号
            returnOrder.setMasterAccount(order.getMasterAccount()); // 获取师傅账号
            int flag_2 = returnOrderMapper.insert(returnOrder); // 添加返库订单
            int flag_1 = orderMapper.deleteByMap(map);      // 删除原先订单

            if (flag_1==0){
                System.out.println("error, 订单删除错误!");
            }
            if (flag_2==0){
                System.out.println("error, 订单返库错误!");
            }

            System.out.println("success, 操作成功!");
    }


    @Test
    void getOrderByPage(){
        // mybatis-plus 分页测试
        Long current = 1L;
        Long limit = 5L;
        // order 分页查询
        Page<Order> page = new Page<>(current,limit);
        Page<Order> orderPage = orderMapper.selectPage(page, null);
        List<Order> orderList = orderPage.getRecords();
        if (orderList.isEmpty()){
            System.out.println("error , 订单结果为空");
            return;
        }
        System.out.println("总页数: "+orderPage.getPages());
        System.out.println("总记录: "+orderPage.getTotal());
        orderList.forEach(System.out::println);
    }


    @Test
    void getMaterialOrderGroups(){
            QueryWrapper<MaterialGroup> wrapper = new QueryWrapper<>();
            wrapper.select("material_group_name");
            List<MaterialGroup> materialGroups = materialGroupMapper.selectList(wrapper);
            if (materialGroups.isEmpty()){
                System.out.println("error, 材料小类结果为空");
            }
        for (MaterialGroup materialGroup : materialGroups) {
            System.out.println(materialGroup.getMaterialGroupName());
        }
    }


    @Test
    void getMaterialOrder(){
        List<MaterialOrder> materialOrderList = materialOrderMapper.selectList(null);
        if (materialOrderList.isEmpty()){
            System.out.println("error, 材料列表为空");
        }
        materialOrderList.forEach(System.out::println);
    }

}
