package com.sanyau.repair;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sanyau.repair.entity.Building;
import com.sanyau.repair.entity.StudentInfo;
import com.sanyau.repair.mapper.StudentInfoMapper;
import com.sanyau.repair.response.Result;
import com.sanyau.repair.service.IBuildingService;
import com.sanyau.repair.service.impl.StudentInfoServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class StudentTest {
    @Autowired
    private StudentInfoMapper studentInfoMapper;
    @Autowired
    private IBuildingService iBuildingService;

    @Test
    public void test1(){

        QueryWrapper<StudentInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("openId", "oz2jl5JwceLkML6in8cPtuXMf1f4");

        List<StudentInfo> studentInfos = studentInfoMapper.selectList(wrapper);
        System.out.println("-------------");
        studentInfos.get(0).setStudentApartment(changeRepairType(studentInfos.get(0).getStudentApartment()));
        System.out.println(studentInfos);


    }

    public String changeRepairType(String order){//区域
        System.out.println(order);
        Building id = iBuildingService.getOne(new QueryWrapper<Building>().eq("id", order));
        return id.getBuildingName();
    }
}
